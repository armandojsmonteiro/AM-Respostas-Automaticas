AM Responder — V170

Base: V168 aprovada. A V169 falhou na compilação e não é usada como base.

Correção desta versão:
- Mantém a funcionalidade da V168 sem alterações no sistema de identificação dos IDs.
- Corrige os dois diálogos de confirmação em Configurações: Limpar fotografia de fundo e Limpar dados da aplicação.
- Cantos do diálogo arredondados.
- Espaço interno equilibrado entre o texto e os botões e depois dos botões.
- Botões Cancelar/Limpar mantidos com o mesmo estilo visual.
- Não utiliza referências inexistentes como buttonPanel.

Versão Android:
- versionCode = 170
- versionName = "170"
