package pt.am.respostasautomaticas

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class ThemesActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var background: ImageView
    private lateinit var backgroundTint: View
    private lateinit var root: View
    private lateinit var header: View
    private lateinit var bottomNav: View
    private lateinit var blueSeek: SeekBar
    private lateinit var transparencySeek: SeekBar
    private lateinit var blueValue: TextView
    private lateinit var transparencyValue: TextView
    private lateinit var peopleList: LinearLayout

    private var pendingGroupName: String? = null
    private var pendingContactRequest = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_themes)
        root = findViewById(R.id.settingsContentRoot)
        header = findViewById(R.id.settingsHeader)
        bottomNav = findViewById(R.id.settingsBottomNav)
        preview = findViewById(R.id.imgPreviewBackground)
        background = findViewById(R.id.settingsBackground)
        backgroundTint = findViewById(R.id.settingsBackgroundTint)
        blueSeek = findViewById(R.id.seekBlue)
        transparencySeek = findViewById(R.id.seekTransparency)
        blueValue = findViewById(R.id.tvBlueValue)
        transparencyValue = findViewById(R.id.tvTransparencyValue)
        peopleList = findViewById(R.id.peopleList)

        val master = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.settingsMaster)
        val status = findViewById<TextView>(R.id.settingsStatus)
        setupApplicationIdsButton()
        val ruleStore = RuleStore(this)
        master.isChecked = ruleStore.isMasterEnabled()
        status.text = if (master.isChecked) "Ativo" else "Desativado"
        master.setOnCheckedChangeListener { _, checked -> ruleStore.setMasterEnabled(checked); status.text = if (checked) "Ativo" else "Desativado" }

        blueSeek.max = 100
        blueSeek.progress = ThemeStore.getBlueIntensity(this)
        transparencySeek.max = 100
        transparencySeek.progress = ThemeStore.getMenuTransparency(this)

        blueSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                ThemeStore.setBlueIntensity(this@ThemesActivity, progress)
                blueValue.text = "$progress%"
                refreshVisuals()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        transparencySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                ThemeStore.setMenuTransparency(this@ThemesActivity, progress)
                transparencyValue.text = "$progress%"
                refreshVisuals()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        findViewById<MaterialButton>(R.id.btnChooseBackground).setOnClickListener { chooseBackground() }
        findViewById<MaterialButton>(R.id.btnClearBackground).setOnClickListener { confirmClearBackground() }
        findViewById<MaterialButton>(R.id.btnAddPerson).setOnClickListener { startContactSelection(null) }
        findViewById<MaterialButton>(R.id.btnAddGroup).setOnClickListener { addGroup() }
        findViewById<MaterialButton>(R.id.btnBackup).setOnClickListener { backup() }
        findViewById<MaterialButton>(R.id.btnRestore).setOnClickListener { restore() }
        findViewById<MaterialButton>(R.id.btnClearAppData).setOnClickListener { confirmClearAppData() }
        findViewById<MaterialButton>(R.id.btnNotificationAccess).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        findViewById<TextView>(R.id.navRulesSettings).setOnClickListener { finish() }
        findViewById<TextView>(R.id.navHistorySettings).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).putExtra("screen", "history")); finish()
        }

        syncContactsAndRefresh()
        refreshVisuals()
    }

    override fun onResume() {
        super.onResume()
        syncContactsAndRefresh()
        refreshVisuals()
    }

    private fun setupApplicationIdsButton() {
        val settingsRoot = findViewById<LinearLayout>(R.id.themesRoot)
        if (settingsRoot.findViewWithTag<View>("application_ids_button") != null) return
        val button = MaterialButton(this)
        button.tag = "application_ids_button"
        button.text = "Identificação das aplicações / IDs"
        button.setAllCaps(false)
        button.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dp(46)
        ).apply { topMargin = dp(8) }
        button.setPadding(dp(18), 0, dp(18), 0)
        button.minWidth = 0
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(ThemeStore.palette(this).accent)
        button.cornerRadius = dp(14)
        button.setOnClickListener { showApplicationIdsDialog() }
        settingsRoot.addView(button, 1)
    }

    private fun showApplicationIdsDialog() {
        val palette = ThemeStore.palette(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        val fields = linkedMapOf<String, EditText>()
        val initialValues = linkedMapOf<String, Int>()

        fun idCircleBackground(color: Int): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(color)
            }

        fun applyIdStyle(edit: EditText, color: Int) {
            edit.background = idCircleBackground(color)
            edit.setTextColor(Color.WHITE)
            edit.textSize = 16f
            edit.gravity = Gravity.CENTER
            edit.setPadding(0, 0, 0, 0)
        }

        AppIdsStore.instances.forEach { name ->
            val current = AppIdsStore.get(this, name)
            initialValues[name] = current

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(palette.text)
                setPadding(dp(2), 0, dp(8), 0)
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(56), 1f))

            val edit = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(current.toString())
                setSelectAllOnFocus(true)
                setSingleLine(true)
                gravity = Gravity.CENTER
                background = idCircleBackground(palette.accent)
                setTextColor(Color.WHITE)
                textSize = 16f
                setPadding(0, 0, 0, 0)
            }
            row.addView(edit, LinearLayout.LayoutParams(dp(52), dp(52)).apply {
                marginStart = dp(8)
                marginEnd = dp(2)
            })
            container.addView(row)
            fields[name] = edit
        }

        val scroll = ScrollView(this).apply {
            addView(container)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(360)
            )
        }

        val status = TextView(this).apply {
            text = "IDs encontrados: 0"
            textSize = 14f
            setTextColor(palette.muted)
            setPadding(dp(18), dp(8), dp(18), dp(4))
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(8))
        }

        fun dialogButton(text: String): MaterialButton = MaterialButton(this).apply {
            this.text = text
            setAllCaps(false)
            minWidth = 0
            minimumWidth = 0
            minHeight = dp(42)
            minimumHeight = dp(42)
            cornerRadius = dp(14)
            setPadding(dp(8), 0, dp(8), 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(palette.accent)
            setTextColor(Color.WHITE)
            textSize = 14f
        }

        val cancelButton = dialogButton("Cancelar")
        // Keep the middle button on one line by using the shorter label requested.
        val searchButton = dialogButton("Procurar")
        val saveButton = dialogButton("Guardar")
        buttons.addView(cancelButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(2); marginEnd = dp(3)
        })
        buttons.addView(searchButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(3); marginEnd = dp(3)
        })
        buttons.addView(saveButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(3); marginEnd = dp(2)
        })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(scroll)
            addView(status)
            addView(buttons)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Identificação das aplicações")
            .setMessage("Confirma os IDs detetados automaticamente ou altera-os manualmente. Usa Procurar para fazer uma nova deteção.")
            .setView(content)
            .create()

        cancelButton.setOnClickListener { dialog.dismiss() }
        searchButton.setOnClickListener {
            status.text = "A procurar nas notificações ativas…"
            NotificationDiagnosticService.scanCurrentNotifications()
            window.decorView.postDelayed({
                val found = mutableListOf<String>()
                fields.forEach { (name, edit) ->
                    AppIdsStore.observed(this, name)?.let { observedId ->
                        val oldValue = initialValues[name] ?: AppIdsStore.get(this, name)
                        edit.setText(observedId.toString())
                        // Green means an ID is confirmed by an observed notification.
                        // Blue means the search found a new/different ID for this app.
                        val color = if (observedId != oldValue) palette.accent else Color.rgb(22, 163, 74)
                        applyIdStyle(edit, color)
                        found.add("$name = $observedId")
                    }
                }
                status.text = if (found.isNotEmpty()) {
                    "Encontrados: ${found.joinToString(" • ")}"
                } else {
                    "IDs encontrados: 0 — abre as aplicações e deixa uma notificação visível, depois procura novamente."
                }
            }, 350)
        }
        saveButton.setOnClickListener {
            fields.forEach { (name, edit) ->
                edit.text.toString().toIntOrNull()?.let { if (it >= 0) AppIdsStore.set(this, name, it) }
            }
            dialog.dismiss()
            Toast.makeText(this, "IDs das aplicações guardados.", Toast.LENGTH_SHORT).show()
        }

        dialog.setOnShowListener {
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.94f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            dialog.window?.decorView?.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                setColor(Color.WHITE)
                cornerRadius = dp(18).toFloat()
            }
        }
        dialog.show()
    }

    private fun syncContactsAndRefresh() {
        refreshPeople()
        ContactSync.syncAsync(this, force = false) { removed ->
            if (!isFinishing && !isDestroyed) {
                refreshPeople()
                if (removed > 0) {
                    Toast.makeText(this, "$removed contacto(s) removido(s) porque já não existem nos Contactos.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshVisuals() {
        val p = ThemeStore.palette(this)
        val alpha = (255f * (1f - ThemeStore.getMenuTransparency(this) / 100f)).toInt().coerceIn(0, 255)
        root.setBackgroundColor(Color.argb(alpha, Color.red(p.surface), Color.green(p.surface), Color.blue(p.surface)))
        header.setBackgroundColor(Color.TRANSPARENT)
        bottomNav.setBackgroundColor(Color.argb((alpha + 255) / 2, 255, 255, 255))
        findViewById<TextView>(R.id.tvSettingsTitle).setTextColor(p.text)
        blueValue.setTextColor(p.accent); transparencyValue.setTextColor(p.accent)
        blueValue.text = "${ThemeStore.getBlueIntensity(this)}%"
        transparencyValue.text = "${ThemeStore.getMenuTransparency(this)}%"
        val uri = ThemeStore.getBackgroundUri(this)
        if (uri != null) {
            runCatching {
                background.setImageURI(uri); background.visibility = View.VISIBLE
                preview.setImageURI(uri); preview.visibility = View.VISIBLE
            }.onFailure {
                ThemeStore.setBackgroundUri(this, null); background.visibility = View.GONE; preview.setImageDrawable(null)
            }
        } else {
            background.visibility = View.GONE; preview.setImageDrawable(null); preview.setBackgroundColor(p.surfaceAlt)
        }
        backgroundTint.visibility = View.GONE
        window.statusBarColor = Color.argb(alpha, 255, 255, 255)
        window.navigationBarColor = p.background
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    private fun chooseBackground() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 2001)
    }

    private fun backup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "AM_Respostas_Automaticas_backup.json")
        }
        startActivityForResult(intent, 3001)
    }

    private fun restore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
        startActivityForResult(intent, 3002)
    }

    private fun confirmClearBackground() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Limpar fotografia de fundo?")
            .setMessage("A fotografia de fundo será removida e a aplicação voltará a usar o fundo padrão. As restantes configurações, regras, pessoas e grupos não serão alteradas.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar") { _, _ ->
                ThemeStore.setBackgroundUri(this, null)
                refreshVisuals()
            }
            .create()

        dialog.show()
        styleConfirmationDialog(dialog)
    }

    private fun confirmClearAppData() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Limpar dados da aplicação?")
            .setMessage("Esta ação vai apagar todas as regras, pessoas e grupos, histórico/diagnóstico, configurações visuais e a fotografia de fundo. A aplicação ficará como uma instalação nova. As cópias de segurança guardadas fora da aplicação não serão apagadas.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar dados") { _, _ -> clearAppData() }
            .create()

        dialog.show()
        styleConfirmationDialog(dialog)
    }

    private fun styleConfirmationDialog(dialog: AlertDialog) {
        val blue = ThemeStore.palette(this).accent

        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                setColor(Color.WHITE)
                cornerRadius = dp(18).toFloat()
            })
            setLayout(
                (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        listOf(AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_POSITIVE).forEach { which ->
            dialog.getButton(which)?.let { button ->
                button.setTextColor(Color.WHITE)
                button.backgroundTintList = null
                button.background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(blue)
                }
                button.minWidth = 0
                button.minimumWidth = 0
                button.minHeight = dp(40)
                button.minimumHeight = dp(40)
                button.setPadding(dp(12), 0, dp(12), 0)
                (button.layoutParams as? android.widget.LinearLayout.LayoutParams)?.let { lp ->
                    lp.width = android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                    lp.weight = 0f
                    lp.marginStart = dp(6)
                    lp.marginEnd = dp(6)
                    button.layoutParams = lp
                }
            }
        }

        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.parent?.let { parent ->
            if (parent is ViewGroup) {
                parent.setPadding(parent.paddingLeft, dp(12), parent.paddingRight, dp(12))
            }
        }
    }

    private fun clearAppData() {
        // Clear every preference store used by the application.
        listOf("am_reply", "am_people", "am_theme", "am_diagnostics", "am_contact_sync", "whatsapp_reply_gate")
            .forEach { name -> getSharedPreferences(name, MODE_PRIVATE).edit().clear().commit() }

        // Remove application-private files, including the saved wallpaper copy.
        filesDir.listFiles()?.forEach { file -> file.deleteRecursively() }
        cacheDir.listFiles()?.forEach { file -> file.deleteRecursively() }

        Toast.makeText(this, "Dados da aplicação limpos.", Toast.LENGTH_SHORT).show()
        recreate()
    }

    private fun startContactSelection(groupName: String?) {
        pendingGroupName = groupName
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingContactRequest = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 4001)
            return
        }
        pendingContactRequest = false
        val intent = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI).apply {
            type = ContactsContract.Contacts.CONTENT_TYPE
        }
        startActivityForResult(intent, 4002)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 4001 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && pendingContactRequest) {
            startContactSelection(pendingGroupName)
        } else if (requestCode == 4001) {
            Toast.makeText(this, "É necessário permitir o acesso aos contactos para escolher uma pessoa.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            2001 -> {
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                ThemeStore.setBackgroundUri(this, uri); refreshVisuals(); Toast.makeText(this, "Fundo atualizado.", Toast.LENGTH_SHORT).show()
            }
            3001 -> runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(BackupStore.export(this).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "Cópia de segurança guardada.", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this, "Não foi possível guardar a cópia de segurança.", Toast.LENGTH_SHORT).show() }
            3002 -> runCatching {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Ficheiro vazio")
                BackupStore.import(this, raw)
                // Reload every restored setting from the stores instead of trusting the
                // previous widget state. This makes rules, people/groups, master state,
                // colours, transparency and background all come back together.
                blueSeek.progress = ThemeStore.getBlueIntensity(this)
                transparencySeek.progress = ThemeStore.getMenuTransparency(this)
                val restoredMaster = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.settingsMaster)
                val restoredStatus = findViewById<TextView>(R.id.settingsStatus)
                restoredMaster.setOnCheckedChangeListener(null)
                restoredMaster.isChecked = RuleStore(this).isMasterEnabled()
                restoredStatus.text = if (restoredMaster.isChecked) "Ativo" else "Desativado"
                restoredMaster.setOnCheckedChangeListener { _, checked ->
                    RuleStore(this).setMasterEnabled(checked)
                    restoredStatus.text = if (checked) "Ativo" else "Desativado"
                }
                refreshPeople(); refreshVisuals()
                Toast.makeText(this, "Cópia de segurança reposta.", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this, "Cópia de segurança inválida ou impossível de ler.", Toast.LENGTH_SHORT).show() }
            4002 -> handleContactPicked(uri)
        }
    }

    private fun handleContactPicked(uri: Uri) {
        runCatching {
            contentResolver.query(uri, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.LOOKUP_KEY), null, null, null)?.use { c ->
                if (!c.moveToFirst()) error("Contacto não encontrado")
                val id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
                val name = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)).orEmpty().ifBlank { "Contacto" }
                val lookup = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.LOOKUP_KEY))
                val phone = queryFirstPhone(id)
                saveSelectedContact(ContactPerson(name, id, lookup, phone), pendingGroupName)
            } ?: error("Não foi possível ler o contacto")
        }.onFailure { Toast.makeText(this, "Não foi possível adicionar o contacto.", Toast.LENGTH_SHORT).show() }
    }

    private fun queryFirstPhone(contactId: String): String? {
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?",
            arrayOf(contactId), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun saveSelectedContact(person: ContactPerson, groupName: String?) {
        val data = PeopleStore.load(this)
        if (groupName == null) {
            val exists = data.people.any { it.contactId != null && it.contactId == person.contactId }
            if (!exists) data.people.add(person)
        } else {
            val group = data.groups.firstOrNull { it.name == groupName } ?: return
            val exists = group.people.any { it.contactId != null && it.contactId == person.contactId }
            if (!exists) group.people.add(person)
        }
        PeopleStore.save(this, data); refreshPeople()
    }

    private fun refreshPeople() {
        peopleList.removeAllViews()
        val data = PeopleStore.load(this)
        val p = ThemeStore.palette(this)

        data.people.forEach { person -> peopleList.addView(personRow(person, null), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }) }

        data.groups.forEach { group ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(10), dp(10))
                background = getDrawable(R.drawable.bg_nav_item)
            }
            val headerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val title = TextView(this).apply {
                text = "Grupo: ${group.name}"; textSize = 16f; setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(p.text); layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            headerRow.addView(title)
            headerRow.addView(iconButton("✎") { editGroup(group.name) })
            headerRow.addView(iconButton("⌫") { deleteGroup(group.name) })
            card.addView(headerRow)

            val membersTitle = TextView(this).apply {
                text = "Pessoas no grupo"; textSize = 13f; setTextColor(p.muted); setPadding(0, dp(5), 0, dp(3))
            }
            card.addView(membersTitle)
            if (group.people.isEmpty()) {
                card.addView(TextView(this).apply { text = "Sem pessoas adicionadas"; textSize = 13f; setTextColor(p.muted); setPadding(0, 0, 0, dp(6)) })
            } else {
                group.people.forEach { member -> card.addView(personRow(member, group.name, true)) }
            }
            val add = MaterialButton(this).apply {
                text = "＋ Adicionar pessoa"; isAllCaps = false; setOnClickListener { startContactSelection(group.name) }
                layoutParams = LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(7) }
            }
            card.addView(add)
            peopleList.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        if (data.people.isEmpty() && data.groups.isEmpty()) {
            peopleList.addView(TextView(this).apply { text = "Ainda não existem pessoas ou grupos."; textSize = 14f; setTextColor(p.muted); setPadding(dp(4), dp(8), dp(4), dp(8)) })
        }
    }

    private fun personRow(person: ContactPerson, group: String?, nested: Boolean = false): View {
        val p = ThemeStore.palette(this)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(if (nested) dp(8) else dp(14), dp(7), dp(4), dp(7))
        }
        val label = TextView(this).apply {
            text = if (person.phone.isNullOrBlank()) person.name else "${person.name}  ·  ${person.phone}"
            textSize = if (nested) 14f else 15f; setTextColor(p.text); layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        row.addView(label)
        row.addView(iconButton("✎") { editPerson(person, group) })
        row.addView(iconButton("⌫") { deletePerson(person, group) })
        return row
    }

    private fun iconButton(symbol: String, action: () -> Unit): TextView = TextView(this).apply {
        text = symbol; textSize = 19f; gravity = Gravity.CENTER; setTextColor(ThemeStore.palette(this@ThemesActivity).muted)
        setPadding(dp(7), 0, dp(7), 0); minWidth = dp(42); minHeight = dp(42); setOnClickListener { action() }
    }

    private fun editPerson(person: ContactPerson, groupName: String?) {
        val input = EditText(this).apply { setText(person.name); setSingleLine(true); setPadding(dp(16), 0, dp(16), 0); hint = "Nome da pessoa" }
        val box = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), 0); addView(input, LinearLayout.LayoutParams(-1, dp(58))) }
        AlertDialog.Builder(this).setTitle("Editar pessoa").setView(box)
            .setNegativeButton("Cancelar", null).setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isBlank()) return@setPositiveButton
                val data = PeopleStore.load(this)
                val target = if (groupName == null) data.people else data.groups.firstOrNull { it.name == groupName }?.people
                target?.firstOrNull { samePerson(it, person) }?.name = newName
                PeopleStore.save(this, data); refreshPeople()
            }.show()
    }

    private fun deletePerson(person: ContactPerson, groupName: String?) {
        AlertDialog.Builder(this).setMessage("Apagar \"${person.name}\"?")
            .setNegativeButton("Cancelar", null).setPositiveButton("Apagar") { _, _ ->
                val data = PeopleStore.load(this)
                val target = if (groupName == null) data.people else data.groups.firstOrNull { it.name == groupName }?.people
                val key = personKey(person)
                target?.removeAll { samePerson(it, person) }
                PeopleStore.save(this, data)
                val ruleStore = RuleStore(this)
                val rules = ruleStore.loadRules()
                rules.forEach { it.targetPeople.removeAll { selected -> selected == key } }
                ruleStore.saveRules(rules)
                refreshPeople()
            }.show()
    }

    private fun personKey(person: ContactPerson): String =
        person.contactId?.let { "id:$it" } ?: "name:${person.name}"

    private fun samePerson(a: ContactPerson, b: ContactPerson): Boolean {
        return if (a.contactId != null && b.contactId != null) a.contactId == b.contactId else a === b || (a.contactId == null && b.contactId == null && a.name == b.name)
    }

    private fun addGroup() {
        val input = EditText(this).apply { hint = "Nome do grupo"; setSingleLine(true); setPadding(dp(16), 0, dp(16), 0) }
        val box = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), 0); addView(input, LinearLayout.LayoutParams(-1, dp(58))) }
        AlertDialog.Builder(this).setTitle("Adicionar grupo").setView(box)
            .setNegativeButton("Cancelar", null).setPositiveButton("Criar") { _, _ ->
                val name = input.text.toString().trim(); if (name.isEmpty()) return@setPositiveButton
                val data = PeopleStore.load(this)
                if (data.groups.none { it.name.equals(name, true) }) {
                    data.groups.add(ContactGroup(name)); PeopleStore.save(this, data); refreshPeople()
                }
            }.show()
    }

    private fun editGroup(oldName: String) {
        val input = EditText(this).apply { setText(oldName); setSingleLine(true); setPadding(dp(16), 0, dp(16), 0); hint = "Nome do grupo" }
        val box = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), 0); addView(input, LinearLayout.LayoutParams(-1, dp(58))) }
        AlertDialog.Builder(this).setTitle("Editar grupo").setView(box)
            .setNegativeButton("Cancelar", null).setPositiveButton("Guardar") { _, _ ->
                val name = input.text.toString().trim(); if (name.isEmpty()) return@setPositiveButton
                val data = PeopleStore.load(this)
                data.groups.firstOrNull { it.name == oldName }?.name = name
                PeopleStore.save(this, data)
                val ruleStore = RuleStore(this)
                val rules = ruleStore.loadRules()
                rules.forEach { rule ->
                    for (i in rule.targetGroups.indices) {
                        if (rule.targetGroups[i] == oldName) rule.targetGroups[i] = name
                    }
                }
                ruleStore.saveRules(rules)
                refreshPeople()
            }.show()
    }

    private fun deleteGroup(name: String) {
        AlertDialog.Builder(this).setMessage("Apagar o grupo \"$name\" e as pessoas que estão dentro dele?")
            .setNegativeButton("Cancelar", null).setPositiveButton("Apagar") { _, _ ->
                val data = PeopleStore.load(this)
                data.groups.removeAll { it.name == name }
                PeopleStore.save(this, data)
                val ruleStore = RuleStore(this)
                val rules = ruleStore.loadRules()
                rules.forEach { it.targetGroups.removeAll { selected -> selected == name } }
                ruleStore.saveRules(rules)
                refreshPeople()
            }.show()
    }

    private fun dp(value: Int): Int = kotlin.math.round(value * resources.displayMetrics.density).toInt()

}
