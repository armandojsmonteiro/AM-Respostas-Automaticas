AM Respostas Automáticas — V260

Fallback de receção ativa do NotificationListenerService e diagnóstico real da entrega de notificações.
