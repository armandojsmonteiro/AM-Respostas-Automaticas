package pt.am.respostasautomaticas

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_USER_UNLOCKED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val appContext = context.applicationContext

        // The personal profile can leave the notification-listener binding in a
        // stale state after a reboot even though notification access remains
        // authorised. Do not touch the component unless Android still reports
        // that this listener is authorised.
        val authorised = runCatching {
            val raw = Settings.Secure.getString(
                appContext.contentResolver,
                "enabled_notification_listeners"
            ).orEmpty()
            val component = ComponentName(
                appContext,
                NotificationDiagnosticService::class.java
            ).flattenToString()
            raw.split(":").any { it.equals(component, ignoreCase = true) }
        }.getOrDefault(false)

        if (!authorised) {
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "Arranque detetado, mas o acesso ao listener não está autorizado; nenhuma recuperação automática foi executada."
                )
            }
            return
        }

        if (action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            // Wait for USER_UNLOCKED before touching credential-protected state or
            // forcing the component cycle. The system may still be bringing the
            // personal profile and Notification Manager online at this stage.
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "LOCKED_BOOT_COMPLETED recebido; recuperação completa adiada até USER_UNLOCKED."
                )
            }
            return
        }

        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_USER_UNLOCKED) {
            runCatching { DiagnosticsStore.markListenerUnconfirmedAfterBoot(appContext) }
        }

        runCatching {
            DiagnosticsStore.appendTechnical(
                appContext,
                "BOOT",
                "Arranque/desbloqueio detetado (${action}); recuperação do listener agendada."
            )
        }

        // Avoid doing two component cycles when BOOT_COMPLETED and USER_UNLOCKED
        // arrive close together. A reboot should trigger one deliberate cycle.
        val prefs = appContext.getSharedPreferences("listener_recovery", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastRecovery = prefs.getLong("last_recovery", 0L)
        if (now - lastRecovery < 120_000L) {
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "Recuperação ignorada: já executada há menos de 120 segundos."
                )
            }
            return
        }
        prefs.edit().putLong("last_recovery", now).apply()

        val pending = goAsync()
        Thread {
            try {
                // Give MagicOS/Android time to finish restoring the personal user
                // profile before we force the notification-listener component cycle.
                Thread.sleep(if (action == Intent.ACTION_USER_UNLOCKED) 4_000L else 12_000L)

                NotificationDiagnosticService.forceComponentCycle(appContext)

                Thread.sleep(2_000L)
                NotificationDiagnosticService.requestRebind(appContext)
                Thread.sleep(5_000L)
                NotificationDiagnosticService.requestRebind(appContext)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                pending.finish()
            }
        }.start()
    }
}
