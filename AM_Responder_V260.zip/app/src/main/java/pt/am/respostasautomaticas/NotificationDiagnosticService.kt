package pt.am.respostasautomaticas

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.content.ComponentName
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.security.MessageDigest
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class NotificationDiagnosticService : NotificationListenerService() {

    private val lifecycleHandler = Handler(Looper.getMainLooper())
    private val activeNotificationFingerprints = ConcurrentHashMap<String, String>()
    private val pollRunnable = object : Runnable {
        override fun run() {
            if (activeInstance === this@NotificationDiagnosticService) {
                pollActiveNotifications()
                lifecycleHandler.postDelayed(this, 2_000L)
            }
        }
    }

    companion object {
        private const val DEDUPE_WINDOW_MS = 2_000L
        // WhatsApp can emit the same notification more than once. After a
        // successful automatic reply, deliberately allow no second WhatsApp
        // reply for a short cooldown. A new message after this window is
        // processed normally.
        private const val WHATSAPP_REPLY_COOLDOWN_MS = 3_000L
        private const val SELF_REPLY_SUPPRESSION_MS = 10_000L

        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
        private const val TELEGRAM_PACKAGE = "org.telegram.messenger"
        private const val SIGNAL_PACKAGE = "org.thoughtcrime.securesms"

        // Confirmed on the user's HONOR Magic V3.
        private const val USER_PERSONAL = 0
        private const val USER_CLONED = 128
        private const val USER_WORK = 10

        private val executor: ExecutorService = Executors.newSingleThreadExecutor()

        /*
         * IMPORTANT:
         * Messaging apps often UPDATE ONE EXISTING NOTIFICATION instead of creating
         * a brand-new notification for every message. Therefore sbn.key alone cannot
         * be used for deduplication: the second, third, fourth... messages may keep
         * the same sbn.key.
         *
         * We dedupe only identical notification content within a very short window.
         * A genuinely new message (different text/postTime/content hash) gets a new
         * reply attempt.
         */
        private val handledEvents = ConcurrentHashMap<String, Long>()

        // WhatsApp can publish a notification for the message sent by our own
        // RemoteInput action. Without suppressing that notification, the
        // autoresponder sees its own reply as a new incoming message and replies
        // forever. Keep the last automatic reply per package/user/conversation.
        private val recentOwnReplies = ConcurrentHashMap<String, OwnReply>()

        // Last successful automatic reply per WhatsApp conversation. This is
        // intentionally separate from notification deduplication: even when
        // WhatsApp republishes the same event with different notification
        // metadata, only one automatic reply may leave the device during the
        // cooldown window.
        private val lastWhatsappReplies = ConcurrentHashMap<String, Long>()

        // Hard WhatsApp gate. It is synchronized and also persisted so the
        // protection survives a service restart and cannot be bypassed by
        // duplicated listener instances/callbacks.
        private val whatsappGateLock = Any()

        @Volatile
        private var activeInstance: NotificationDiagnosticService? = null

        fun scanCurrentNotifications() {
            activeInstance?.scanActiveNotifications()
        }

        fun requestRebind(context: android.content.Context) {
            runCatching {
                NotificationListenerService.requestRebind(
                    ComponentName(context, NotificationDiagnosticService::class.java)
                )
            }
        }

        fun recoverBinding(context: android.content.Context) {
            val component = ComponentName(context, NotificationDiagnosticService::class.java)
            val handler = Handler(Looper.getMainLooper())

            // First ask the notification framework to unbind/rebind. This is the
            // official API-level recovery mechanism.
            if (android.os.Build.VERSION.SDK_INT >= 34) {
                runCatching { NotificationListenerService.requestUnbind(component) }
            }

            handler.postDelayed({
                runCatching { NotificationListenerService.requestRebind(component) }
            }, 750L)
            handler.postDelayed({
                runCatching { NotificationListenerService.requestRebind(component) }
            }, 2500L)
            handler.postDelayed({
                runCatching { NotificationListenerService.requestRebind(component) }
            }, 6000L)
        }

        /**
         * Reproduces the system-visible component reset that has been proven to
         * recover the listener on this device when manually disabling/enabling
         * Notification Access in Android Settings. The user's notification-access
         * grant is not changed by this: the component is toggled only inside our
         * own package and then immediately re-enabled.
         */
        fun forceComponentCycle(context: android.content.Context) {
            val component = ComponentName(context, NotificationDiagnosticService::class.java)
            val pm = context.packageManager
            runCatching {
                DiagnosticsStore.appendTechnical(
                    context,
                    "RECOVERY",
                    "A iniciar ciclo do componente do listener (desativar → ativar)."
                )

                pm.setComponentEnabledSetting(
                    component,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )

                Thread.sleep(1_500L)

                pm.setComponentEnabledSetting(
                    component,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )

                DiagnosticsStore.appendTechnical(
                    context,
                    "RECOVERY",
                    "Ciclo do componente concluído; pedido de rebind preparado."
                )
            }.onFailure { error ->
                DiagnosticsStore.appendTechnical(
                    context,
                    "RECOVERY",
                    "⚠ Falha no ciclo do componente: ${error.javaClass.simpleName}: ${error.message ?: "sem mensagem"}"
                )
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        // Creation alone is not proof that Android is delivering notifications.
        // Only onListenerConnected() confirms the binding; only real notification
        // delivery updates the reception timestamp.
        DiagnosticsStore.appendTechnical(
            applicationContext,
            "LISTENER",
            "NotificationListenerService criado; ligação ainda não confirmada."
        )
        lifecycleHandler.post(pollRunnable)
    }

    override fun onDestroy() {
        lifecycleHandler.removeCallbacksAndMessages(null)
        activeNotificationFingerprints.clear()
        if (activeInstance === this) {
            activeInstance = null
            DiagnosticsStore.setListenerServiceState(applicationContext, false)
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "LISTENER",
                "NotificationListenerService destruído."
            )
        }
        super.onDestroy()
    }

    /**
     * Fallback for OEMs that keep the NotificationListenerService connected after
     * reboot but stop delivering onNotificationPosted() callbacks. We poll the
     * active notification list and feed only genuinely changed notifications into
     * the same processing path. The normal callback remains the primary path.
     */
    private fun pollActiveNotifications() {
        if (!DiagnosticsStore.isListenerServiceConnected(applicationContext)) return
        try {
            val current = activeNotifications.orEmpty()
            val currentKeys = HashSet<String>()
            current.forEach { sbn ->
                if (!isSupportedPackage(sbn.packageName)) return@forEach
                val key = sbn.key
                currentKeys += key
                val fingerprint = notificationFingerprint(sbn)
                val previous = activeNotificationFingerprints.put(key, fingerprint)
                if (previous == null) {
                    // Baseline only. Existing notifications were already present when
                    // the listener connected and must not trigger an automatic reply.
                    return@forEach
                }
                if (previous != fingerprint) {
                    DiagnosticsStore.recordNotificationPolled(applicationContext)
                    DiagnosticsStore.appendTechnical(
                        applicationContext,
                        "POLL",
                        "📡 Alteração detetada por verificação ativa | pacote=${sbn.packageName} | UserHandle=${parseUserHandleId(sbn.user?.toString().orEmpty())}"
                    )
                    processPostedNotification(sbn, fromPoll = true)
                }
            }

            activeNotificationFingerprints.keys.removeIf { it !in currentKeys }
        } catch (error: Exception) {
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "POLL",
                "⚠ Falha na verificação ativa: ${error.javaClass.simpleName}: ${error.message ?: "sem mensagem"}"
            )
        }
    }

    private fun notificationFingerprint(sbn: StatusBarNotification): String {
        val notification = sbn.notification
        val title = notification.extras
            .getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text = notificationMessageText(notification).trim()
        val messagingIdentity = extractMessagingStyleIdentity(notification).orEmpty()
        return listOf(sbn.key, title, text, messagingIdentity).joinToString("|")
    }

    private fun processPostedNotification(sbn: StatusBarNotification, fromPoll: Boolean = false) {
        if (!isSupportedPackage(sbn.packageName)) return

        if (!fromPoll) {
            DiagnosticsStore.recordNotificationReceived(applicationContext)
        }

        // Keep exactly the same filtering and responder pipeline for both paths.
        val userHandleText = sbn.user?.toString().orEmpty()
        val userHandleId = parseUserHandleId(userHandleText)
        if (userHandleId < 0) {
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "USER",
                "⚠ Não foi possível obter o ID do UserHandle | representação=$userHandleText | pacote=${sbn.packageName}"
            )
        }
        val title = sbn.notification.extras
            .getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val isGroup = isGroupOrChannelNotification(sbn.notification)
        DiagnosticsStore.appendTechnical(
            applicationContext,
            if (fromPoll) "RECEIVED-POLL" else "RECEIVED",
            "📩 ${if (fromPoll) "Notificação detetada por verificação ativa" else "Notificação recebida"} | pacote=${sbn.packageName} | UserHandle=$userHandleId | título=${title.ifBlank { "(sem título)" }}"
        )

        if (isGroup) {
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "FILTER",
                "↪ Notificação ignorada: grupo/canal/comunidade | pacote=${sbn.packageName} | UserHandle=$userHandleId | título=${title.ifBlank { "(sem título)" }}"
            )
            return
        }
        if (sbn.isOngoing) {
            DiagnosticsStore.appendTechnical(applicationContext, "FILTER", "↪ Notificação descartada: ongoing.")
            return
        }
        if ((sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) {
            DiagnosticsStore.appendTechnical(applicationContext, "FILTER", "↪ Notificação descartada: group summary.")
            return
        }

        executor.execute { processNotification(sbn) }
    }

    private fun scanActiveNotifications() {
        try {
            activeNotifications?.forEach { sbn ->
                val userHandleId = parseUserHandleId(sbn.user?.toString().orEmpty())
                if (userHandleId >= 0) {
                    detectedInstanceFor(sbn.packageName, userHandleId)?.let {
                        // Detection is recorded for display/diagnostics only.
                        // Do not change the active configuration automatically.
                        AppIdsStore.recordObserved(applicationContext, it, userHandleId)
                    }
                }
            }
        } catch (_: Exception) {
            // The listener may be reconnecting; normal notification callbacks
            // continue recording observations when new notifications arrive.
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        DiagnosticsStore.setListenerServiceState(applicationContext, true)
        DiagnosticsStore.appendTechnical(
            applicationContext,
            "LISTENER",
            "✓ Listener de notificações ligado ao Android."
        )
        activeNotificationFingerprints.clear()
        scanActiveNotifications()
        pollActiveNotifications()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        DiagnosticsStore.setListenerServiceState(applicationContext, false)
        DiagnosticsStore.appendTechnical(
            applicationContext,
            "LISTENER",
            "⚠ Listener de notificações desligado pelo Android; a pedir reconexão."
        )
        runCatching {
            requestRebind(applicationContext)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!isSupportedPackage(sbn.packageName)) return

        DiagnosticsStore.heartbeatListenerService(applicationContext)
        DiagnosticsStore.recordNotificationReceived(applicationContext)
        activeNotificationFingerprints[sbn.key] = notificationFingerprint(sbn)
        processPostedNotification(sbn, fromPoll = false)
    }

    private data class OwnReply(
        val timestamp: Long,
        val message: String
    )

    private fun processNotification(sbn: StatusBarNotification) {
        val notification = sbn.notification
        val extras = notification.extras

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = notificationMessageText(notification)
        val userHandleText = sbn.user?.toString().orEmpty()
        // UserHandle#getIdentifier is not exposed by the compile SDK used by this project.
        // Parse the stable UserHandle{N} representation instead.
        val userHandleId = parseUserHandleId(userHandleText)
        if (userHandleId >= 0) {
            val detected = detectedInstanceFor(sbn.packageName, userHandleId)
            if (detected != null) {
                // Detection is recorded for display/diagnostics only.
                // Do not change the active configuration automatically.
                AppIdsStore.recordObserved(applicationContext, detected, userHandleId)
            } else {
                supportedInstanceFor(sbn.packageName, userHandleId)?.let {
                    AppIdsStore.recordObserved(applicationContext, it, userHandleId)
                }
            }
        }

        DiagnosticsStore.append(
            applicationContext,
            sbn.packageName,
            userHandleText,
            title,
            text
        )
        DiagnosticsStore.appendNotificationDetails(applicationContext, sbn, notification)

        // WhatsApp can publish our own outgoing message as a MessagingStyle
        // notification.  In that notification the title/self display name is
        // the local account (for example "Eu"), while an incoming private
        // message has the other person's name.  Never treat an explicitly
        // self-authored WhatsApp notification as an incoming message.
        if (isWhatsAppPackage(sbn.packageName) && isOwnWhatsAppNotification(notification, title)) {
            DiagnosticsStore.appendResult(
                applicationContext,
                "↩ WhatsApp: notificação da própria conta ignorada."
            )
            return
        }

        // A notification may represent a message sent by the local account.
        // Sent messages belong in the human-readable History, but they must
        // never enter the autoresponder pipeline as if they were received.
        val direction = messageDirection(notification, title)
        if (direction == "sent") {
            val sentApp = supportedInstanceFor(sbn.packageName, userHandleId)
                ?: detectedInstanceFor(sbn.packageName, userHandleId)
                ?: sbn.packageName
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "SENT",
                "↗ Mensagem enviada detetada | aplicação=$sentApp | contacto=${title.ifBlank { "desconhecido" }}"
            )
            DiagnosticsStore.appendHistory(
                applicationContext,
                sentApp,
                title,
                text,
                "sent",
                "Enviada — não processada por ser mensagem de saída",
                null,
                0L
            )
            return
        }

        // Ignore the notification generated by our own automatic reply.
        // This is especially important for WhatsApp, which can publish the
        // outgoing reply back through NotificationListenerService.
        val now = System.currentTimeMillis()
        val conversationKey = buildConversationKey(sbn.packageName, userHandleId, title)
        val ownReply = recentOwnReplies[conversationKey]
        if (ownReply != null) {
            if (now - ownReply.timestamp < SELF_REPLY_SUPPRESSION_MS &&
                isSameAutomaticReply(text, ownReply.message)
            ) {
                return
            }
            if (now - ownReply.timestamp >= SELF_REPLY_SUPPRESSION_MS) {
                recentOwnReplies.remove(conversationKey, ownReply)
            }
        }

        // Autoresponder is deliberately limited to private/direct conversations.
        // Group conversations expose a conversation title through MessagingStyle;
        // those notifications must never trigger an automatic reply.
        if (!isDirectMessage(notification)) {
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "FILTER",
                "↪ Notificação descartada: não é conversa pessoa-a-pessoa | aplicação=${sbn.packageName} | título=${title.ifBlank { "(sem título)" }}"
            )
            return
        }

        DiagnosticsStore.appendTechnical(
            applicationContext,
            "PRIVATE",
            "✓ Conversa pessoa-a-pessoa aceite | aplicação=${sbn.packageName} | contacto=${title.ifBlank { "desconhecido" }}"
        )

        val processingStarted = System.currentTimeMillis()
        val historyApp = supportedInstanceFor(sbn.packageName, userHandleId)
            ?: detectedInstanceFor(sbn.packageName, userHandleId)
            ?: sbn.packageName
        fun history(direction: String, outcome: String, messageText: String = text, responseText: String? = null) {
            runCatching {
                DiagnosticsStore.appendHistory(
                    applicationContext,
                    historyApp,
                    title,
                    messageText,
                    direction,
                    outcome,
                    responseText,
                    System.currentTimeMillis() - processingStarted
                )
            }
        }
        runCatching {
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "EV-${System.currentTimeMillis()}",
                "Mensagem privada recebida | aplicação=$historyApp | contacto=${title.ifBlank { "desconhecido" }}"
            )
        }

        val store = RuleStore(applicationContext)
        if (!store.isMasterEnabled()) {
            history("received", "Não processada — respostas automáticas desativadas")
            return
        }

        val rules = store.loadRules()
        val matchingRule = rules.firstOrNull { candidate ->
            candidate.enabled &&
                matchesInstance(candidate.instance, sbn.packageName, userHandleId) &&
                isWithinSchedule(candidate) &&
                ruleTargetsConversation(candidate, title)
        }
        if (matchingRule == null) {
            DiagnosticsStore.appendResult(
                applicationContext,
                "⚠ Sem regra para ${sbn.packageName} / UserHandle{$userHandleId}. Regras ativas: ${rules.filter { it.enabled }.joinToString { it.instance }}"
            )
            history("received", "Não enviada — nenhuma regra aplicável")
            return
        }
        val rule = matchingRule
        DiagnosticsStore.appendResult(
            applicationContext,
            "✓ Instância detetada: ${rule.instance} (UserHandle{$userHandleId}); regra encontrada: ${rule.name}."
        )

        // WhatsApp-specific safety net retained as a secondary guard. The primary
        // protection is now the explicit self-authored notification check above.
        // Telegram keeps its previous behaviour.
        /*
         * Do not use notification.when here either: some WhatsApp notification
         * updates can expose a different event timestamp for the same message.
         * The stable identity is the normalized message content plus instance.
         */
        val eventKey = buildEventKey(sbn, notification, title, text)
        cleanup(now)

        val previous = handledEvents.putIfAbsent(eventKey, now)
        if (previous != null && now - previous < DEDUPE_WINDOW_MS) {
            DiagnosticsStore.appendResult(
                applicationContext,
                "↪ Evento duplicado ignorado em ${rule.instance}."
            )
            return
        }

        val action = findReplyAction(notification) ?: run {
            handledEvents.remove(eventKey)
            DiagnosticsStore.appendResult(
                applicationContext,
                "Sem ação de resposta rápida em ${rule.instance}. ações=${notification.actions?.size ?: 0}."
            )
            return
        }

        val whatsappConversationKey = buildConversationKey(
            sbn.packageName,
            userHandleId,
            title
        )
        if (isWhatsAppPackage(sbn.packageName)) {
            // HARD GATE: reserve the WhatsApp response slot atomically only after
            // the notification has a usable reply action.
            synchronized(whatsappGateLock) {
                val prefs = getSharedPreferences("whatsapp_reply_gate", MODE_PRIVATE)
                val stored = prefs.getLong(whatsappConversationKey, 0L)
                val inMemory = lastWhatsappReplies[whatsappConversationKey] ?: 0L
                val lastReplyAt = maxOf(stored, inMemory)

                if (lastReplyAt > 0L && now - lastReplyAt < WHATSAPP_REPLY_COOLDOWN_MS) {
                    DiagnosticsStore.appendResult(
                        applicationContext,
                        "↪ WhatsApp duplicado ignorado (${((WHATSAPP_REPLY_COOLDOWN_MS - (now - lastReplyAt)).coerceAtLeast(0L))} ms restantes)."
                    )
                    return
                }

                // Commit synchronously BEFORE sending. Even if WhatsApp fires
                // another notification while RemoteInput is executing, the gate
                // is already closed.
                prefs.edit().putLong(whatsappConversationKey, now).commit()
                lastWhatsappReplies[whatsappConversationKey] = now
            }
        }

        DiagnosticsStore.appendResult(
            applicationContext,
            "↳ RESPOSTA: título=\"${action.title ?: ""}\", semanticAction=${action.semanticAction}, remoteInputs=${action.remoteInputs?.joinToString { it.resultKey ?: "?" } ?: "nenhum"}."
        )

        val started = System.currentTimeMillis()

        /*
         * IMPORTANT FOR WHATSAPP: the RemoteInput action can cause WhatsApp to
         * publish the outgoing message before sendReply() returns.  Previously
         * we only registered the automatic reply AFTER sendReply(), which left
         * a small race window: WhatsApp published our reply, the listener saw it
         * as a new incoming notification, and sent the reply a second time.
         *
         * Register the exact outgoing text BEFORE invoking RemoteInput.  The
         * listener callback can therefore identify and suppress that notification
         * immediately, including the self-chat case where WhatsApp labels it
         * with the same title as the incoming message.
         */
        val replyConversationKey = buildConversationKey(sbn.packageName, userHandleId, title)
        val replyMarker = OwnReply(started, rule.message)
        recentOwnReplies[replyConversationKey] = replyMarker
        cleanupOwnReplies(started)

        val sent = sendReply(action, rule.message)
        val elapsed = System.currentTimeMillis() - started

        if (sent) {
            // Keep the marker active so any immediate WhatsApp notification for
            // the message we just sent is ignored rather than triggering another
            // automatic response.
            val replyTimestamp = System.currentTimeMillis()
            recentOwnReplies[replyConversationKey] = OwnReply(replyTimestamp, rule.message)
            cleanupOwnReplies(replyTimestamp)

            if (isWhatsAppPackage(sbn.packageName)) {
                // Do not move the gate timestamp forward here. The cooldown
                // starts when the incoming notification is accepted.
                cleanupWhatsappReplies(replyTimestamp)
            }

            DiagnosticsStore.appendResult(
                applicationContext,
                "✓ Resposta enviada: ${rule.instance} — \"${rule.name}\" (${elapsed} ms)."
            )
            history("received", "Resposta enviada — regra: ${rule.name}", text, rule.message)
        } else {
            handledEvents.remove(eventKey)
            recentOwnReplies.remove(replyConversationKey, replyMarker)
            if (isWhatsAppPackage(sbn.packageName)) {
                // Keep the short gate even when RemoteInput fails. This prevents
                // a duplicated callback from immediately retrying twice; the
                // user can retry naturally after the 3-second window.
                lastWhatsappReplies[whatsappConversationKey] = System.currentTimeMillis()
            }
            DiagnosticsStore.appendResult(
                applicationContext,
                "✗ Falha ao enviar para ${rule.instance} (${elapsed} ms)."
            )
            history("received", "Falha no envio — regra: ${rule.name}")
        }
    }

    private fun ruleTargetsConversation(rule: Rule, notificationTitle: String): Boolean {
        // Contact synchronization runs in the background from the activities.
        // Never query the Android Contacts provider synchronously for each notification.
        val title = normalizeRecipientName(notificationTitle)
        if (title.isBlank()) return rule.targetMode == "deny" && rule.targetPeople.isEmpty() && rule.targetGroups.isEmpty()

        val data = PeopleStore.load(applicationContext)
        val selectedPeople = mutableListOf<ContactPerson>()
        data.people.filter { personKey(it) in rule.targetPeople }.forEach { selectedPeople += it }
        data.groups.forEach { group ->
            // An organization marked Excluída is a hard exclusion for all of its members.
            // This lets a large organization be excluded without changing each contact.
            if (!group.included && group.people.any {
                    normalizeRecipientName(it.name) == title ||
                        (!it.phone.isNullOrBlank() && normalizeRecipientName(it.phone.orEmpty()) == title)
                }) return false
            group.people.filter { personKey(it) in rule.targetPeople && !isExcluded(group, it) }.forEach { selectedPeople += it }
            if (group.name in rule.targetGroups && group.included) {
                group.people.filter { !isExcluded(group, it) }.forEach { selectedPeople += it }
            }
        }

        val matches = selectedPeople.any { person ->
            normalizeRecipientName(person.name) == title ||
                (!person.phone.isNullOrBlank() && normalizeRecipientName(person.phone.orEmpty()) == title)
        }

        return if (rule.targetMode == "deny") {
            // Blacklist: the rule applies to everyone except the selected people/groups.
            !matches
        } else {
            // Whitelist: the rule applies only to selected people/groups.
            // Empty lists preserve legacy rules created before recipient selection existed.
            if (rule.targetPeople.isEmpty() && rule.targetGroups.isEmpty()) true else matches
        }
    }

    private fun personKey(person: ContactPerson): String =
        person.contactId?.let { "id:$it" } ?: "name:${person.name}"

    private fun isExcluded(group: ContactGroup, person: ContactPerson): Boolean =
        person.contactId?.let { it in group.excludedContactIds } ?: false

    private fun normalizeRecipientName(value: String): String =
        value.trim().replace(Regex("\\s+"), " ").lowercase()

    private fun isWithinSchedule(rule: Rule): Boolean {
        if (rule.scheduleMode != "scheduled") return true
        return try {
            val formatter = DateTimeFormatter.ofPattern("HH:mm")
            val start = LocalTime.parse(rule.startTime, formatter)
            val end = LocalTime.parse(rule.endTime, formatter)
            val now = LocalTime.now()
            if (start == end) {
                true
            } else if (start.isBefore(end)) {
                !now.isBefore(start) && now.isBefore(end)
            } else {
                // Horário que atravessa a meia-noite, por exemplo 18:00 → 08:00.
                !now.isBefore(start) || now.isBefore(end)
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun buildEventKey(
        sbn: StatusBarNotification,
        notification: Notification,
        title: String,
        text: String
    ): String {
        /*
         * WhatsApp may call onNotificationPosted() more than once for the
         * same incoming message. In practice those callbacks can contain
         * different internal notification/message metadata even though the
         * user-facing message is exactly the same.
         *
         * Therefore the deduplication identity MUST be based on what the user
         * actually received: app instance + conversation title + message text.
         * We deliberately do not include notification.when, sbn.id or
         * MessagingStyle timestamps here, because WhatsApp may change any of
         * those while publishing the same message.
         *
         * The short 2-second window is enough to collapse duplicate callbacks
         * while still allowing two genuinely separate messages sent normally
         * one after another.
         */
        val normalizedTitle = title.trim().replace(Regex("\\s+"), " ")
        val normalizedText = text.trim().replace(Regex("\\s+"), " ")

        val raw = buildString {
            append(sbn.packageName)
            append('|')
            append(parseUserHandleId(sbn.user?.toString().orEmpty()))
            append('|')
            append(normalizedTitle)
            append('|')
            append(normalizedText)
        }

        val digest = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray(Charsets.UTF_8))

        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun extractMessagingStyleIdentity(notification: Notification): String? {
        return try {
            val messages = notification.extras
                .getParcelableArray(Notification.EXTRA_MESSAGES)
                ?.mapNotNull { it as? Bundle }
                ?.filter { bundle ->
                    val messageText = bundle.getCharSequence("text")?.toString()?.trim()
                    !messageText.isNullOrEmpty()
                }
                .orEmpty()

            val latest = messages.lastOrNull() ?: return null
            val messageText = latest.getCharSequence("text")?.toString()?.trim().orEmpty()
            val timestamp = latest.getLong("time", Long.MIN_VALUE)
            if (messageText.isEmpty()) return null

            buildString {
                append(timestamp)
                append('|')
                append(messageText.replace(Regex("\\s+"), " "))
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun cleanup(now: Long) {
        handledEvents.entries.removeIf {
            now - it.value > DEDUPE_WINDOW_MS
        }
        cleanupOwnReplies(now)
    }

    private fun cleanupOwnReplies(now: Long) {
        recentOwnReplies.entries.removeIf {
            now - it.value.timestamp > SELF_REPLY_SUPPRESSION_MS
        }
    }

    private fun cleanupWhatsappReplies(now: Long) {
        lastWhatsappReplies.entries.removeIf {
            now - it.value > WHATSAPP_REPLY_COOLDOWN_MS
        }
    }

    private fun isWhatsAppPackage(packageName: String): Boolean =
        packageName == WHATSAPP_PACKAGE || packageName == WHATSAPP_BUSINESS_PACKAGE

    private fun buildConversationKey(
        packageName: String,
        userHandleId: Int,
        title: String
    ): String = buildString {
        append(packageName)
        append('|')
        append(userHandleId)
        append('|')
        append(title.trim())
    }

    private fun isSameAutomaticReply(notificationText: String, sentMessage: String): Boolean {
        val incoming = notificationText.trim()
        val sent = sentMessage.trim()
        if (incoming.isEmpty() || sent.isEmpty()) return false

        // WhatsApp normally exposes the sent text verbatim, but some versions
        // add a short prefix such as "You:". Accept those harmless wrappers
        // while keeping the comparison tied to the exact automatic message.
        return incoming == sent ||
            incoming.endsWith(sent) ||
            incoming.startsWith(sent)
    }

    private fun detectedInstanceFor(packageName: String, userHandleId: Int): String? {
        val personal = 0
        val cloned = 128
        val work = 10
        return when {
            packageName == WHATSAPP_PACKAGE && userHandleId == personal -> "WhatsApp"
            packageName == WHATSAPP_PACKAGE && userHandleId == cloned -> "WhatsApp Clonado"
            packageName == WHATSAPP_PACKAGE && userHandleId == work -> "WhatsApp Trabalho"
            packageName == WHATSAPP_BUSINESS_PACKAGE && userHandleId == personal -> "WhatsApp Business"
            packageName == WHATSAPP_BUSINESS_PACKAGE && userHandleId == cloned -> "WhatsApp Business Clonado"
            packageName == WHATSAPP_BUSINESS_PACKAGE && userHandleId == work -> "WhatsApp Business Trabalho"
            packageName == TELEGRAM_PACKAGE && userHandleId == personal -> "Telegram"
            packageName == TELEGRAM_PACKAGE && userHandleId == cloned -> "Telegram Clonado"
            packageName == TELEGRAM_PACKAGE && userHandleId == work -> "Telegram Trabalho"
            packageName == SIGNAL_PACKAGE && userHandleId == personal -> "Signal"
            packageName == SIGNAL_PACKAGE && userHandleId == cloned -> "Signal Clonado"
            packageName == SIGNAL_PACKAGE && userHandleId == work -> "Signal Trabalho"
            packageName.contains("ime", ignoreCase = true) && userHandleId == personal -> "iMe"
            packageName.contains("ime", ignoreCase = true) && userHandleId == work -> "iMe Trabalho"
            packageName.contains("nicegram", ignoreCase = true) && userHandleId == personal -> "Nicegram"
            packageName.contains("nicegram", ignoreCase = true) && userHandleId == work -> "Nicegram Trabalho"
            isSmsPackage(packageName) && userHandleId == personal -> "SMS"
            else -> null
        }
    }

    private fun supportedInstanceFor(packageName: String, userHandleId: Int): String? {
        val personal = 0
        val cloned = AppIdsStore.get(applicationContext, "WhatsApp Clonado")
        val work = AppIdsStore.get(applicationContext, "WhatsApp Trabalho")
        return when {
            packageName == WHATSAPP_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "WhatsApp") -> "WhatsApp"
            packageName == WHATSAPP_PACKAGE && userHandleId == cloned -> "WhatsApp Clonado"
            packageName == WHATSAPP_PACKAGE && userHandleId == work -> "WhatsApp Trabalho"
            packageName == WHATSAPP_BUSINESS_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "WhatsApp Business") -> "WhatsApp Business"
            packageName == WHATSAPP_BUSINESS_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "WhatsApp Business Clonado") -> "WhatsApp Business Clonado"
            packageName == WHATSAPP_BUSINESS_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "WhatsApp Business Trabalho") -> "WhatsApp Business Trabalho"
            packageName == TELEGRAM_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "Telegram") -> "Telegram"
            packageName == TELEGRAM_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "Telegram Clonado") -> "Telegram Clonado"
            packageName == TELEGRAM_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "Telegram Trabalho") -> "Telegram Trabalho"
            packageName == SIGNAL_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "Signal") -> "Signal"
            packageName == SIGNAL_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "Signal Clonado") -> "Signal Clonado"
            packageName == SIGNAL_PACKAGE && userHandleId == AppIdsStore.get(applicationContext, "Signal Trabalho") -> "Signal Trabalho"
            packageName.contains("ime", ignoreCase = true) && userHandleId == AppIdsStore.get(applicationContext, "iMe") -> "iMe"
            packageName.contains("ime", ignoreCase = true) && userHandleId == AppIdsStore.get(applicationContext, "iMe Trabalho") -> "iMe Trabalho"
            packageName.contains("nicegram", ignoreCase = true) && userHandleId == AppIdsStore.get(applicationContext, "Nicegram") -> "Nicegram"
            packageName.contains("nicegram", ignoreCase = true) && userHandleId == AppIdsStore.get(applicationContext, "Nicegram Trabalho") -> "Nicegram Trabalho"
            isSmsPackage(packageName) && userHandleId == AppIdsStore.get(applicationContext, "SMS") -> "SMS"
            else -> null
        }
    }

    private fun isSupportedPackage(packageName: String): Boolean =
        packageName == WHATSAPP_PACKAGE ||
            packageName == WHATSAPP_BUSINESS_PACKAGE ||
            packageName == TELEGRAM_PACKAGE ||
            packageName == SIGNAL_PACKAGE ||
            packageName.contains("nicegram", ignoreCase = true) ||
            packageName.contains("ime", ignoreCase = true)

    private fun matchesInstance(
        instance: String,
        packageName: String,
        userHandleId: Int
    ): Boolean =
        when (instance) {
            "WhatsApp", "WhatsApp Clonado", "WhatsApp Trabalho" ->
                packageName == WHATSAPP_PACKAGE && instanceMatchesStoredOrKnown(instance, userHandleId)
            "WhatsApp Business", "WhatsApp Business Clonado", "WhatsApp Business Trabalho" ->
                packageName == WHATSAPP_BUSINESS_PACKAGE && instanceMatchesStoredOrKnown(instance, userHandleId)
            "Telegram", "Telegram Clonado", "Telegram Trabalho" ->
                packageName == TELEGRAM_PACKAGE && instanceMatchesStoredOrKnown(instance, userHandleId)
            "Signal", "Signal Clonado", "Signal Trabalho" ->
                packageName == SIGNAL_PACKAGE && instanceMatchesStoredOrKnown(instance, userHandleId)
            "iMe", "iMe Trabalho" ->
                packageName.contains("ime", ignoreCase = true) && instanceMatchesStoredOrKnown(instance, userHandleId)
            "Nicegram", "Nicegram Trabalho" ->
                packageName.contains("nicegram", ignoreCase = true) && instanceMatchesStoredOrKnown(instance, userHandleId)
            "SMS" -> isSmsPackage(packageName) && instanceMatchesStoredOrKnown(instance, userHandleId)
            else -> false
        }

    private fun instanceMatchesStoredOrKnown(instance: String, userHandleId: Int): Boolean {
        val configured = AppIdsStore.get(this, instance)
        if (userHandleId == configured) return true
        return detectedInstanceForPackage(instance, userHandleId)
    }

    private fun detectedInstanceForPackage(instance: String, userHandleId: Int): Boolean {
        val packageName = when {
            instance.startsWith("WhatsApp Business") -> WHATSAPP_BUSINESS_PACKAGE
            instance.startsWith("WhatsApp") -> WHATSAPP_PACKAGE
            instance.startsWith("Telegram") -> TELEGRAM_PACKAGE
            instance.startsWith("Signal") -> SIGNAL_PACKAGE
            instance.startsWith("iMe") -> "com.iMeAndroid"
            instance.startsWith("Nicegram") -> "com.nicegram"
            instance == "SMS" -> "com.google.android.apps.messaging"
            else -> return false
        }
        return detectedInstanceFor(packageName, userHandleId) == instance
    }

    private fun isSmsPackage(packageName: String): Boolean =
        packageName == "com.google.android.apps.messaging" ||
            packageName == "com.android.mms" ||
            packageName.contains("mms", ignoreCase = true) ||
            packageName.contains("messaging", ignoreCase = true)

    private fun parseUserHandleId(userHandleText: String): Int {
        val match = Regex("""\{(\d+)\}""").find(userHandleText)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: -1
    }

    private enum class MessagingSenderState {
        SELF, OTHER, UNKNOWN
    }

    private fun latestMessagingSenderState(notification: Notification): MessagingSenderState {
        return try {
            val messages = notification.extras
                .getParcelableArray(Notification.EXTRA_MESSAGES)
                ?.mapNotNull { it as? Bundle }
                .orEmpty()
            val latest = messages.lastOrNull() ?: return MessagingSenderState.UNKNOWN

            // Native MessagingStyle stores the Person under sender_person.
            // Legacy notifications may instead expose the CharSequence sender.
            val senderPerson = runCatching {
                latest.getParcelable("sender_person") as? android.app.Person
            }.getOrNull()
            if (senderPerson != null) return MessagingSenderState.OTHER

            val legacySender = latest.getCharSequence("sender")?.toString()?.trim().orEmpty()
            if (legacySender.isNotEmpty()) return MessagingSenderState.OTHER

            // A present MessagingStyle message with no sender is authored by the
            // current user; Android uses the MessagingStyle user when rendering it.
            if (notification.extras.getParcelable<android.app.Person>(Notification.EXTRA_MESSAGING_PERSON) != null ||
                notification.extras.getCharSequence(Notification.EXTRA_SELF_DISPLAY_NAME) != null
            ) {
                MessagingSenderState.SELF
            } else {
                MessagingSenderState.UNKNOWN
            }
        } catch (_: Exception) {
            MessagingSenderState.UNKNOWN
        }
    }

    private fun isOwnWhatsAppNotification(
        notification: Notification,
        title: String
    ): Boolean {
        val extras = notification.extras
        val selfDisplayName = extras.getCharSequence(Notification.EXTRA_SELF_DISPLAY_NAME)
            ?.toString()
            ?.trim()
            .orEmpty()
        val messagingUser = extras.getParcelable<android.app.Person>(Notification.EXTRA_MESSAGING_PERSON)
        val messagingUserName = messagingUser?.name?.toString()?.trim().orEmpty()
        val localNames = listOf(selfDisplayName, messagingUserName).filter { it.isNotBlank() }

        if (localNames.any { title.trim().equals(it, ignoreCase = true) }) return true
        return latestMessagingSenderState(notification) == MessagingSenderState.SELF
    }

    /**
     * Gets the actual message body across notification formats used by the
     * supported messaging apps. Some cloned/work-profile WhatsApp builds do
     * not expose EXTRA_TEXT, but do expose the latest MessagingStyle message.
     */
    private fun notificationMessageText(notification: Notification): String {
        val extras = notification.extras

        extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotEmpty() }?.let { return it }

        extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotEmpty() }?.let { return it }

        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.map { it.toString().trim() }
            ?.filter { it.isNotEmpty() }
            .orEmpty()
        if (lines.isNotEmpty()) return lines.last()

        val messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
            ?.mapNotNull { it as? Bundle }
            .orEmpty()
        val latest = messages.lastOrNull()
        latest?.getCharSequence("text")?.toString()?.trim()
            ?.takeIf { it.isNotEmpty() }?.let { return it }

        return "Mensagem recebida"
    }

    private fun messageDirection(notification: Notification, title: String): String {
        return try {
            val extras = notification.extras
            val selfName = extras.getCharSequence(Notification.EXTRA_SELF_DISPLAY_NAME)?.toString()?.trim().orEmpty()
            val messagingUser = extras.getParcelable<android.app.Person>(Notification.EXTRA_MESSAGING_PERSON)
            val messagingUserName = messagingUser?.name?.toString()?.trim().orEmpty()
            val localNames = listOf(selfName, messagingUserName).filter { it.isNotBlank() }

            when (latestMessagingSenderState(notification)) {
                MessagingSenderState.SELF -> return "sent"
                MessagingSenderState.OTHER -> {
                    val messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                        ?.mapNotNull { it as? Bundle }
                        .orEmpty()
                    val latest = messages.lastOrNull()
                    val senderPerson = runCatching {
                        latest?.getParcelable("sender_person") as? android.app.Person
                    }.getOrNull()
                    val senderName = senderPerson?.name?.toString()?.trim().orEmpty()
                    val legacySender = latest?.getCharSequence("sender")?.toString()?.trim().orEmpty()
                    val displayedSender = senderName.ifBlank { legacySender }
                    if (displayedSender.isNotBlank() && localNames.any { it.equals(displayedSender, ignoreCase = true) }) {
                        return "sent"
                    }
                    return "received"
                }
                MessagingSenderState.UNKNOWN -> Unit
            }

            if (title.isNotBlank() && localNames.any { it.equals(title, ignoreCase = true) }) {
                return "sent"
            }

            "received"
        } catch (_: Exception) {
            "received"
        }
    }

    private fun isGroupOrChannelNotification(notification: Notification): Boolean {
        val extras = notification.extras

        // Android's explicit flag is the most reliable signal when the messaging
        // application publishes it.
        if (extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return true

        // A conversation title is used by Android for a named/group conversation.
        // Private one-to-one notifications normally leave this extra absent.
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?.toString()
            ?.trim()
        if (!conversationTitle.isNullOrEmpty()) return true

        // Some WhatsApp builds do not expose the explicit group flag, but their
        // MessagingStyle payload contains the sender of the message. If that
        // sender is different from the notification title, the title is normally
        // the group name and the sender is the individual who posted in it.
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            runCatching {
                val messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES).orEmpty()
                val latest = messages.lastOrNull() as? Bundle
                val senderPerson = runCatching {
                    latest?.getParcelable("sender_person") as? android.app.Person
                }.getOrNull()
                val sender = senderPerson?.name?.toString()?.trim().orEmpty()
                    .ifBlank { latest?.getCharSequence("sender")?.toString()?.trim().orEmpty() }
                val title = extras.getCharSequence(Notification.EXTRA_TITLE)
                    ?.toString()
                    ?.trim()
                if (!sender.isNullOrEmpty() && !title.isNullOrEmpty() &&
                    !sender.equals(title, ignoreCase = true)) {
                    return true
                }
            }
        }

        return false
    }

    private fun isDirectMessage(notification: Notification): Boolean =
        !isGroupOrChannelNotification(notification)

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions.orEmpty()
        actions.firstOrNull { action ->
            action.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY &&
                !action.remoteInputs.isNullOrEmpty()
        }?.let { return it }
        return actions.firstOrNull { action ->
            val inputs = action.remoteInputs ?: return@firstOrNull false
            inputs.isNotEmpty() && inputs.any { it.allowFreeFormInput }
        }
    }

    private fun sendReply(action: Notification.Action, message: String): Boolean {
        val remoteInputs = action.remoteInputs ?: return false

        return try {
            val intent = Intent()
            val results = Bundle()

            remoteInputs.forEach { input ->
                results.putCharSequence(input.resultKey, message)
            }

            RemoteInput.addResultsToIntent(
                remoteInputs,
                intent,
                results
            )

            action.actionIntent.send(applicationContext, 0, intent)
            true
        } catch (error: Exception) {
            DiagnosticsStore.appendTechnical(
                applicationContext,
                "REPLY",
                "✗ Exceção no RemoteInput: ${error.javaClass.simpleName}: ${error.message ?: "sem mensagem"}"
            )
            false
        }
    }
}
