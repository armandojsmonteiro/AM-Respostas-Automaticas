AM Respostas Automáticas — V260

Base: V259.

Correção focada no problema reproduzido após reinício do telefone.
- Após BOOT_COMPLETED/USER_UNLOCKED, se o acesso ao listener continuar autorizado, é feito um ciclo controlado do componente NotificationListenerService: desativar o componente e voltar a ativá-lo, seguido de requestRebind().
- O ciclo é executado uma vez por arranque/desbloqueio e protegido contra disparos duplicados muito próximos.
- O listener só é considerado ligado depois de onListenerConnected().
- A receção real continua a ser confirmada apenas por onNotificationPosted().
- O diagnóstico regista cada etapa do ciclo de recuperação com data e hora.
- Mantidos UserHandle 0/128/10, regras, respostas, histórico e restante funcionamento.

VersionCode: 260
VersionName: 260
