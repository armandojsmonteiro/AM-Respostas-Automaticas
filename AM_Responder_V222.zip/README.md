AM Respostas Automáticas — V222

Base funcional: V221.
Primeira implementação da monitorização/diagnóstico XPTO.
