package pt.am.respostasautomaticas

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

class RulesAdapter(
    private val rules: MutableList<Rule>,
    private val onToggle: (Rule) -> Unit,
    private val onMove: (Int, Int) -> Unit,
    private val onEdit: (Rule) -> Unit,
    private val onDelete: (Rule) -> Unit
) : RecyclerView.Adapter<RulesAdapter.Holder>() {

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvRuleName)
        val instance: TextView = v.findViewById(R.id.tvInstance)
        val icon: ImageView = v.findViewById(R.id.imgInstanceIcon)
        val message: TextView = v.findViewById(R.id.tvMessage)
        val schedule: TextView = v.findViewById(R.id.tvSchedule)
        val targets: TextView = v.findViewById(R.id.tvTargets)
        val toggle: MaterialSwitch = v.findViewById(R.id.switchRule)
        val edit: ImageButton = v.findViewById(R.id.btnEdit)
        val delete: ImageButton = v.findViewById(R.id.btnDelete)
        val drag: View = v.findViewById(R.id.btnDrag)
    }

    private var dragStarter: ((Holder) -> Unit)? = null
    fun setDragStarter(starter: (Holder) -> Unit) { dragStarter = starter }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_rule, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val rule = rules[position]
        holder.name.text = rule.name
        holder.icon.setImageResource(iconFor(rule.instance))
        // V142 — ajustes mínimos apenas nos quatro ícones indicados.
        // Nicegram normal: ligeiro aumento.
        // Signal Clonado/Trabalho: ligeiro alargamento horizontal + pequeno avanço para a direita.
        // Tudo o resto mantém exatamente a escala/posição da V141.
        val scaleX = when (rule.instance) {
            "Nicegram" -> 1.06f
            "Signal Clonado", "Signal Trabalho" -> 1.08f
            else -> 1f
        }
        val scaleY = if (rule.instance == "iMe") 0.93f else 1f
        val translationX = if (rule.instance == "Signal Clonado" || rule.instance == "Signal Trabalho") {
            2f * holder.itemView.resources.displayMetrics.density
        } else {
            0f
        }
        holder.icon.scaleX = scaleX
        holder.icon.scaleY = scaleY
        holder.icon.translationX = translationX
        val palette = ThemeStore.palette(holder.itemView.context)
        val transparency = ThemeStore.getMenuTransparency(holder.itemView.context)
        val alpha = (255f * (1f - transparency / 100f)).toInt().coerceIn(0, 255)
        val cardDrawable = holder.itemView.background.mutate() as? android.graphics.drawable.GradientDrawable
        cardDrawable?.apply {
            setColor(android.graphics.Color.argb(
                alpha,
                android.graphics.Color.red(palette.card),
                android.graphics.Color.green(palette.card),
                android.graphics.Color.blue(palette.card)
            ))
            setStroke(
                1,
                android.graphics.Color.argb(
                    (alpha * 0.55f).toInt().coerceIn(0, 255),
                    android.graphics.Color.red(palette.line),
                    android.graphics.Color.green(palette.line),
                    android.graphics.Color.blue(palette.line)
                )
            )
        }
        holder.edit.backgroundTintList = android.content.res.ColorStateList.valueOf(
            android.graphics.Color.argb(alpha, android.graphics.Color.red(palette.surfaceAlt), android.graphics.Color.green(palette.surfaceAlt), android.graphics.Color.blue(palette.surfaceAlt))
        )
        holder.delete.backgroundTintList = android.content.res.ColorStateList.valueOf(
            android.graphics.Color.argb(alpha, android.graphics.Color.red(palette.surfaceAlt), android.graphics.Color.green(palette.surfaceAlt), android.graphics.Color.blue(palette.surfaceAlt))
        )
        holder.name.setTextColor(palette.text)
        holder.instance.setTextColor(palette.muted)
        holder.message.setTextColor(palette.text)
        holder.schedule.setTextColor(palette.muted)
        holder.instance.text = rule.instance
        holder.message.text = rule.message
        holder.schedule.visibility = if (rule.scheduleMode == "scheduled") View.VISIBLE else View.GONE
        if (rule.scheduleMode == "scheduled") holder.schedule.text = "🕒 ${rule.startTime} → ${rule.endTime}"

        holder.toggle.setOnCheckedChangeListener(null)
        holder.toggle.isChecked = rule.enabled
        holder.toggle.setOnCheckedChangeListener { _, checked ->
            rule.enabled = checked
            onToggle(rule)
        }
        holder.edit.setOnClickListener { onEdit(rule) }
        holder.delete.setOnClickListener { onDelete(rule) }
        holder.drag.setOnTouchListener { _, event ->
            if (event.actionMasked == android.view.MotionEvent.ACTION_DOWN) {
                dragStarter?.invoke(holder)
                true
            } else false
        }
        // Do not apply a second alpha to the whole card: the menu transparency slider
        // must be the single source of truth for the card surface.
        holder.itemView.alpha = 1f
    }

    private fun iconFor(instance: String): Int = when (instance) {
            "WhatsApp Clonado" -> R.drawable.ic_whatsapp_clone
            "WhatsApp Trabalho" -> R.drawable.ic_whatsapp_work
            "WhatsApp Business Clonado" -> R.drawable.ic_whatsapp_business_clone
            "WhatsApp Business" -> R.drawable.ic_whatsapp_business
            "WhatsApp" -> R.drawable.ic_whatsapp
            "Telegram Clonado" -> R.drawable.ic_telegram_clone
            "Telegram Trabalho" -> R.drawable.ic_telegram_work
            "Telegram" -> R.drawable.ic_telegram
            "Signal Clonado" -> R.drawable.ic_signal_clone
            "Signal Trabalho" -> R.drawable.ic_signal_work
            "Signal" -> R.drawable.ic_signal
            "iMe Trabalho" -> R.drawable.ic_ime_work
            "iMe" -> R.drawable.ic_ime
            "Nicegram Trabalho" -> R.drawable.ic_nicegram_work
            "Nicegram" -> R.drawable.ic_nicegram
            "SMS" -> R.drawable.ic_sms
            else -> R.drawable.ic_app
        }

    override fun getItemCount(): Int = rules.size
}
