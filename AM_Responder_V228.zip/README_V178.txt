AM Respostas Automáticas — V178

Base obrigatória: V176. A V177 foi descartada e não é usada.

Alterações desta versão:
- Espaço inferior consistente em todos os diálogos/mensagens, para que os botões não terminem colados ao limite inferior do balão.
- Títulos dos diálogos maiores e a negrito, incluindo Identificação das aplicações.
- Mantidos os balões com cantos arredondados e os botões azuis usados na aplicação.
- Os diálogos de edição/remoção de pessoas e organizações passam também pelo mesmo estilo visual.
- O projeto Gradle mantém a estrutura correta na raiz do ZIP.
- versionCode: 178
- versionName: 178
