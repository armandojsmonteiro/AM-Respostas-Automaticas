AM Responder — V167

Correção da V166: ThemesActivity.kt usava a propriedade inexistente textSecondary da Palette. Foi substituída por muted, que é a propriedade existente em ThemeStore.Palette.

Mantidas as alterações da V166 para o diálogo de Identificação das aplicações / IDs:
- Botões Cancelar, Procurar IDs e Guardar sempre visíveis.
- Procurar IDs atualiza o estado de deteção e preenche os IDs observados.
- Lista com scroll.

Versão Android:
- versionCode = 167
- versionName = "167"
