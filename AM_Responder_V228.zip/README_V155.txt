V155
Base: V152.
Apenas o ícone WhatsApp Business normal foi aumentado ligeiramente em largura e altura, mantendo os restantes ícones inalterados. versionName=155; versionCode=149.
