AM Respostas Automáticas — V165

Base: V163 (V164 descartada).

Alterações:
- VersionCode e VersionName definidos para 165.
- Identificação das aplicações / IDs com diálogo com Cancelar, Procurar IDs e Guardar.
- Procurar IDs consulta as notificações ativas através do serviço de diagnóstico.
- Lista de IDs com scroll para manter os botões do diálogo acessíveis.
- Mantida a assinatura estável existente.
