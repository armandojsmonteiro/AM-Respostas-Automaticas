AM Respostas Automáticas — V200

Alterações desta versão:
- Corrigido o scroll vertical interno das organizações: ao deslizar dentro da área dos contactos, o gesto fica nessa área e não move o ScrollView principal das Configurações.
- Mantido o limite visual de 5 contactos por vez dentro de cada organização.
- Os botões de cada organização passaram a ficar lado a lado: “Atualizar” e “＋ Pessoa”.
- Mantida a base funcional da V199, sem alterar outras áreas da aplicação.
