AM Respostas Automáticas — V219
Base: V217. V218 descartada por falha de compilação.
