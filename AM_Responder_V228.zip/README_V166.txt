AM Responder — V166

Correção da identificação das aplicações / IDs.
- Base: V165, que já compila.
- Os botões deixam de depender dos botões inferiores do AlertDialog e passam a ficar sempre visíveis dentro do próprio conteúdo: Cancelar, Procurar IDs e Guardar.
- Procurar IDs mostra o estado da pesquisa e atualiza a indicação “IDs encontrados: X”.
- Mantida a deteção através das notificações ativas e o preenchimento automático dos IDs observados.
- versionCode = 166.
- versionName = "166".
- Nenhuma outra funcionalidade foi alterada.
