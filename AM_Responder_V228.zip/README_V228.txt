AM Respostas Automáticas — V228

Base: V227.

Alterações:
- Histórico com direção visual: aplicação → contacto para mensagens enviadas e aplicação ← contacto para recebidas.
- Mensagens de saída são registadas no Histórico, mas não entram no motor de resposta automática.
- Botão Limpar histórico / Limpar diagnóstico com confirmação.
- Diagnóstico técnico preservado e separado do Histórico.
- versionCode=228; versionName=228.
- Sem alteração do fluxo de navegação inferior.
