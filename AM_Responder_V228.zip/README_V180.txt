AM Respostas Automáticas — V180

Base obrigatória: V178, a base correta/aprovada.

Alterações desta versão:
- Contactos apresentados com o nome numa linha e o telefone na linha seguinte, sem o separador “·”.
- Ao criar uma organização, depois de indicar o nome, é apresentada uma escolha explícita entre Incluída e Excluída antes de importar os contactos.
- A organização passa a mostrar o seu estado Incluída/Excluída no cabeçalho, com alternância por toque.
- Uma organização marcada como Excluída bloqueia a resposta automática para os seus membros, evitando excluir contacto a contacto.
- As exceções individuais Incluída/Excluída dos contactos continuam a funcionar.
- O estado da organização é preservado nas cópias de segurança e é compatível com backups anteriores (organizações antigas ficam Incluídas por defeito).
- Mantidos os restantes visuais e comportamentos da V178, incluindo diálogos com cantos arredondados, títulos a negrito, espaçamento inferior e botões azuis.
- versionCode: 180
- versionName: 180
