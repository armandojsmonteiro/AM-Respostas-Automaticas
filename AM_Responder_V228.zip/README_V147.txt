AM Respostas Automáticas — V147

Base: V146.

Alterações: adicionar a instância WhatsApp Business Trabalho à seleção de regras, com o mesmo tratamento de instância Trabalho usado nas restantes aplicações (perfil de trabalho), e substituir os ícones WhatsApp Business / Clonado pelos recortes de melhor qualidade fornecidos pelo utilizador, adicionando o novo ícone WhatsApp Business Trabalho.
