AM Respostas Automáticas — V195

Base exclusiva: V188.

Correções desta versão:
- Regras: lápis e caixote do lixo passam a ser verdadeiramente transparentes, sem o fundo/quadrado por baixo dos ícones.
- Temas > Azul: a alteração da intensidade do azul passa a ser aplicada imediatamente enquanto a barra é arrastada, sem ser necessário sair das Configurações ou mudar de menu.
- A aplicação da intensidade do azul deixa de depender da cor anterior do botão, garantindo que todos os botões azuis, incluindo Repor cópia de segurança e Limpar fotografia de fundo, acompanham imediatamente a afinação.
- Os botões de estado Incluída/Excluída continuam protegidos e mantêm as respetivas cores verde/vermelho.
- Barra inferior das Configurações: o ícone ativo passa a corresponder sempre ao menu ativo. Em Configurações, a roda dentada fica azul e Regras/Histórico ficam na cor inativa.
- A seleção dos três itens da barra inferior das Configurações passa a atualizar também a cor dos respetivos ícones.

Nenhuma outra alteração funcional foi introduzida.
