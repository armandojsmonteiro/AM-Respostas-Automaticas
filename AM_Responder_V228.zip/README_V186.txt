AM Responder V186

Base exclusiva: V185. Nenhuma versão anterior foi usada como base.

Alterações desta versão:
- Título Limpar fotografia de fundo? em uma única linha, sem truncar, mantendo negrito.
- Título Limpar dados da aplicação? em uma única linha, sem truncar, mantendo negrito.
- Título Adicionar organização mantém-se centrado.
- Campo Nome da organização passa a ficar alinhado à esquerda.
- Lápis de editar volta ao estilo simples, sem fundo/caixa branca.
- Caixote do lixo permanece sem fundo/caixa branca.
- Estado da organização controla visualmente todos os membros: Excluída torna todos os membros Excluídos; Incluída restaura a memória das exclusões individuais.
- A lista excludedContactIds nunca é apagada ao alternar o estado da organização.

Regra de continuidade: V186 parte diretamente de V185. Não retroceder para versões anteriores salvo ordem explícita do utilizador.
