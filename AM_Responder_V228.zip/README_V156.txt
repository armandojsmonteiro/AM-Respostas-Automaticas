AM Responder Automáticas — V156

Base: V155
Alteração única: ajuste do ícone Nicegram normal, aumentando apenas a dimensão vertical do conteúdo visível para aproximá-lo visualmente do Nicegram Trabalho. Largura preservada.
Versão interna: 156
