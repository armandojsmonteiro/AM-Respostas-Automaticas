AM Respostas Automáticas — V196

Base: V195

Alteração desta versão:
- Ao importar os contactos de uma Organização/Grupo (por exemplo, Longo Plano), os contactos são automaticamente ordenados alfabeticamente pelo nome depois da importação.
- A ordenação ignora diferenças de maiúsculas/minúsculas e acentos, mantendo nomes semelhantes juntos.
- Em caso de nomes iguais, o número de telefone é usado apenas como critério secundário.
- Nenhuma outra funcionalidade ou interface foi alterada.
