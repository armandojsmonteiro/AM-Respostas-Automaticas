AM Respostas Automáticas — V198

Base exclusiva: V197.

Correção desta versão:
- Corrigido erro de compilação em ThemesActivity.kt causado por referência inválida a ScrollView.LayoutParams.
- O contentor interno dos contactos passa a usar ViewGroup.LayoutParams, mantendo exatamente o comportamento de scroll interno limitado a cinco contactos.
- Nenhuma outra funcionalidade ou alteração visual da V197 foi modificada.
