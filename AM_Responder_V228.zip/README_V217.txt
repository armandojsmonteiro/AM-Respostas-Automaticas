AM Respostas Automáticas — V217

Base obrigatória: V215-1 fornecida pelo utilizador.

Única alteração desta versão:
- Corrigido apenas o diálogo “Apagar regra?”.
- Mantida a altura/espaço inferior do cartão branco.
- Os botões azuis “Cancelar” e “Apagar” ficam alinhados à direita, na zona inferior do diálogo.
- O texto da mensagem volta a ficar alinhado à esquerda, como nos restantes menus/diálogos da aplicação.
- Não foram alterados menus, regras, contactos, configurações ou outras funcionalidades.
