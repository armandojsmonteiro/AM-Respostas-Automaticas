AM Respostas Automáticas — V171

Base: V168 aprovada.

Alteração desta versão:
- Diálogos Limpar fotografia de fundo e Limpar dados da aplicação com cantos arredondados.
- Espaçamento interno melhorado entre mensagem, botões e fundo.
- Sem dependência de buttonPanel/ViewGroup ou referências não existentes.
- versionCode = 171
- versionName = "171"

A V169 e V170 ficam descartadas e não são usadas como base.
