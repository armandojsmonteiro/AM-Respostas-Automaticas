AM Respostas Automáticas — V176

Base: V175

Ponto 3 — Organizações/contactos: incluir e excluir
- Cada contacto dentro de uma organização pode ser marcado como Incluída ou Excluída.
- Excluídas ficam guardadas como exceções pelo contactId e não voltam a ser adicionadas por uma nova procura da organização.
- O contacto continua visível na organização, com o estado Excluída.
- Reativar como Incluída remove a exceção.
- Apagar continua a remover apenas da aplicação/lista da organização, sem apagar o contacto do Android.
- Mantidos os botões de editar nome e apagar.
- O backup passa a preservar as exceções de exclusão.
- versionCode: 176
- versionName: 176
