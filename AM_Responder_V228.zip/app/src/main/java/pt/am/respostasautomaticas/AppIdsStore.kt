package pt.am.respostasautomaticas

import android.content.Context

object AppIdsStore {
    private const val PREFS = "am_application_ids"
    private const val PREFIX = "id_"
    private const val OBS_PREFIX = "observed_"

    val instances = listOf(
        "WhatsApp", "WhatsApp Clonado", "WhatsApp Trabalho",
        "WhatsApp Business", "WhatsApp Business Clonado", "WhatsApp Business Trabalho",
        "Telegram", "Telegram Clonado", "Telegram Trabalho",
        "Signal", "Signal Clonado", "Signal Trabalho",
        "iMe", "iMe Trabalho", "Nicegram", "Nicegram Trabalho", "SMS"
    )

    private val defaults = mapOf(
        "WhatsApp" to 0, "WhatsApp Clonado" to 128, "WhatsApp Trabalho" to 10,
        "WhatsApp Business" to 0, "WhatsApp Business Clonado" to 128, "WhatsApp Business Trabalho" to 10,
        "Telegram" to 0, "Telegram Clonado" to 128, "Telegram Trabalho" to 10,
        "Signal" to 0, "Signal Clonado" to 128, "Signal Trabalho" to 10,
        "iMe" to 0, "iMe Trabalho" to 10, "Nicegram" to 0, "Nicegram Trabalho" to 10,
        "SMS" to 0
    )

    fun get(context: Context, instance: String): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(PREFIX + instance, defaults[instance] ?: 0)

    fun set(context: Context, instance: String, value: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(PREFIX + instance, value).apply()
    }

    fun observed(context: Context, instance: String): Int? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains(OBS_PREFIX + instance)) return null
        return prefs.getInt(OBS_PREFIX + instance, -1).takeIf { it >= 0 }
    }

    fun recordObserved(context: Context, instance: String, id: Int) {
        if (id < 0) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(OBS_PREFIX + instance, id).apply()
    }

    fun snapshot(context: Context): Map<String, Int> = instances.associateWith { get(context, it) }

    fun restore(context: Context, values: Map<String, Int>) {
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        values.forEach { (name, id) -> editor.putInt(PREFIX + name, id) }
        editor.apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
