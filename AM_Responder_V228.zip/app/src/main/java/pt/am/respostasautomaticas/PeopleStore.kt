package pt.am.respostasautomaticas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Collator
import java.util.Locale

data class ContactPerson(
    var name: String,
    var contactId: String? = null,
    var lookupKey: String? = null,
    var phone: String? = null
)

data class ContactGroup(
    var name: String,
    val people: MutableList<ContactPerson> = mutableListOf(),
    val excludedContactIds: MutableSet<String> = mutableSetOf(),
    var included: Boolean = true
)

data class PeopleData(
    val people: MutableList<ContactPerson> = mutableListOf(),
    val groups: MutableList<ContactGroup> = mutableListOf()
)

object PeopleStore {
    private const val PREFS = "am_people"
    private const val KEY = "data"

    fun load(context: Context): PeopleData {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return PeopleData()
        return runCatching {
            val root = JSONObject(raw)
            val peopleArr = root.optJSONArray("people") ?: JSONArray()
            val groupsArr = root.optJSONArray("groups") ?: JSONArray()
            val people = MutableList(peopleArr.length()) { i -> parsePerson(peopleArr.get(i)) }
            val groups = MutableList(groupsArr.length()) { i ->
                val o = groupsArr.getJSONObject(i)
                val members = o.optJSONArray("people") ?: JSONArray()
                ContactGroup(
                    o.optString("name"),
                    MutableList(members.length()) { j -> parsePerson(members.get(j)) },
                    mutableSetOf<String>().apply {
                        val excluded = o.optJSONArray("excludedContactIds") ?: JSONArray()
                        for (k in 0 until excluded.length()) excluded.optString(k).takeIf { it.isNotBlank() }?.let { add(it) }
                    },
                    o.optBoolean("included", true)
                )
            }
            val nameCollator = Collator.getInstance(Locale("pt", "PT")).apply {
                strength = Collator.PRIMARY
                decomposition = Collator.CANONICAL_DECOMPOSITION
            }
            groups.forEach { group ->
                group.people.sortWith(Comparator { a, b ->
                    val byName = nameCollator.compare(a.name.trim(), b.name.trim())
                    if (byName != 0) byName else a.phone.orEmpty().compareTo(b.phone.orEmpty(), ignoreCase = true)
                })
            }
            people.sortWith(Comparator { a, b ->
                val byName = nameCollator.compare(a.name.trim(), b.name.trim())
                if (byName != 0) byName else a.phone.orEmpty().compareTo(b.phone.orEmpty(), ignoreCase = true)
            })
            PeopleData(people, groups)
        }.getOrElse { PeopleData() }
    }

    private fun parsePerson(value: Any): ContactPerson {
        return if (value is JSONObject) {
            ContactPerson(
                name = value.optString("name"),
                contactId = value.optString("contactId").ifBlank { null },
                lookupKey = value.optString("lookupKey").ifBlank { null },
                phone = value.optString("phone").ifBlank { null }
            )
        } else {
            // Compatibilidade com versões anteriores que guardavam apenas o nome.
            ContactPerson(value.toString())
        }
    }

    fun save(context: Context, data: PeopleData) {
        val root = JSONObject().apply {
            put("people", JSONArray().apply { data.people.forEach { put(personJson(it)) } })
            put("groups", JSONArray().apply {
                data.groups.forEach { g ->
                    put(JSONObject().apply {
                        put("name", g.name)
                        put("people", JSONArray().apply { g.people.forEach { put(personJson(it)) } })
                        put("excludedContactIds", JSONArray().apply { g.excludedContactIds.forEach { put(it) } })
                        put("included", g.included)
                    })
                }
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, root.toString()).apply()
    }

    private fun personJson(person: ContactPerson): JSONObject = JSONObject().apply {
        put("name", person.name)
        person.contactId?.let { put("contactId", it) }
        person.lookupKey?.let { put("lookupKey", it) }
        person.phone?.let { put("phone", it) }
    }
}
