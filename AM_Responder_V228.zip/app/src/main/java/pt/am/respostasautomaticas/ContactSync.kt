package pt.am.respostasautomaticas

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

/** Keeps the app's selected people linked to the Android Contacts database. */
object ContactSync {
    private const val PREFS = "am_contact_sync"
    private const val KEY_LAST_SYNC = "last_sync"
    private const val INTERVAL_MS = 60_000L
    private const val BATCH_SIZE = 25
    private const val BATCH_DELAY_MS = 2_000L
    private val running = AtomicBoolean(false)

    data class SyncResult(
        val removed: Int = 0,
        val changed: Int = 0
    )

    /**
     * Reads Contacts away from the Android UI thread. Selected people are then
     * reconciled in small batches of 25, with a 2-second pause between batches.
     * The existing PeopleStore remains available while the reconciliation runs.
     */
    fun syncAsync(context: Context, force: Boolean = false, onComplete: (SyncResult) -> Unit = {}) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            onComplete(SyncResult())
            return
        }
        if (!running.compareAndSet(false, true)) return

        val appContext = context.applicationContext
        Thread {
            val result = runCatching { sync(appContext, force) }.getOrElse { SyncResult() }
            running.set(false)
            Handler(Looper.getMainLooper()).post { onComplete(result) }
        }.start()
    }

    fun sync(context: Context, force: Boolean = false): SyncResult {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return SyncResult()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!force && now - prefs.getLong(KEY_LAST_SYNC, 0L) < INTERVAL_MS) return SyncResult()

        return runCatching {
            // This potentially large ContactsContract read is already off the UI thread.
            val contacts = loadContacts(context)
            val validIds = contacts.keys
            val data = PeopleStore.load(context)
            var removed = 0
            var changed = 0

            val selected = mutableListOf<Pair<ContactPerson, MutableList<ContactPerson>>>()
            data.people.forEach { person -> selected += person to data.people }
            data.groups.forEach { group -> group.people.forEach { person -> selected += person to group.people } }

            selected.chunked(BATCH_SIZE).forEachIndexed { batchIndex, batch ->
                batch.forEach { (person, owner) ->
                    val id = person.contactId
                    if (id != null) {
                        if (id !in validIds) {
                            if (owner.remove(person)) {
                                removed++
                                changed++
                            }
                        } else if (updatePerson(person, contacts[id])) {
                            changed++
                        }
                    }
                }

                // Give the UI thread and the rest of the application time to run.
                if ((batchIndex + 1) * BATCH_SIZE < selected.size) {
                    Thread.sleep(BATCH_DELAY_MS)
                }

                // Persist each completed batch, so the work is incremental rather
                // than one large operation at the end.
                PeopleStore.save(context, data)
            }

            val validKeys = data.people.mapNotNull { it.contactId?.let { id -> "id:$id" } }.toMutableSet()
            data.groups.forEach { group -> group.people.forEach { it.contactId?.let { id -> validKeys += "id:$id" } } }
            val store = RuleStore(context)
            val rules = store.loadRules()
            var rulesChanged = false
            rules.forEach { rule ->
                val beforePeople = rule.targetPeople.size
                rule.targetPeople.removeAll { it.startsWith("id:") && it !in validKeys }
                if (beforePeople != rule.targetPeople.size) rulesChanged = true
            }
            if (rulesChanged) {
                store.saveRules(rules)
                changed++
            }

            PeopleStore.save(context, data)
            prefs.edit().putLong(KEY_LAST_SYNC, now).apply()
            SyncResult(removed = removed, changed = changed)
        }.getOrElse { SyncResult() }
    }

    private fun loadContacts(context: Context): Map<String, ContactSnapshot> {
        val result = linkedMapOf<String, ContactSnapshot>()

        // One query for contacts (instead of one phone query per contact).
        context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts.LOOKUP_KEY
            ),
            null, null, null
        )?.use { c ->
            val idIndex = c.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
            val nameIndex = c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)
            val lookupIndex = c.getColumnIndexOrThrow(ContactsContract.Contacts.LOOKUP_KEY)
            while (c.moveToNext()) {
                val id = c.getString(idIndex)
                val name = c.getString(nameIndex).orEmpty().ifBlank { "Contacto" }
                val lookup = c.getString(lookupIndex)
                result[id] = ContactSnapshot(name, lookup, null)
            }
        }

        // One query for all phone numbers, retaining the first number per contact.
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            val idIndex = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numberIndex = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val id = c.getString(idIndex)
                val number = c.getString(numberIndex)
                val existing = result[id]
                if (existing != null && existing.phone == null) {
                    result[id] = existing.copy(phone = number)
                }
            }
        }
        return result
    }

    private fun updatePerson(person: ContactPerson, snapshot: ContactSnapshot?): Boolean {
        if (snapshot == null) return false
        val changed = person.name != snapshot.name || person.lookupKey != snapshot.lookupKey || person.phone != snapshot.phone
        person.name = snapshot.name
        person.lookupKey = snapshot.lookupKey
        person.phone = snapshot.phone
        return changed
    }

    private data class ContactSnapshot(val name: String, val lookupKey: String?, val phone: String?)
}
