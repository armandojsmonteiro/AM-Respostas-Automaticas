package pt.am.respostasautomaticas

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

object BackupStore {
    fun export(context: Context): String {
        val root = JSONObject()
        root.put("format", "AM_RESPOSTAS_AUTOMATICAS_BACKUP_3")
        root.put("masterEnabled", RuleStore(context).isMasterEnabled())
        val rules = JSONArray()
        RuleStore(context).loadRules().forEach { r ->
            rules.put(JSONObject().apply {
                put("id", r.id); put("name", r.name); put("instance", r.instance); put("message", r.message)
                put("enabled", r.enabled); put("scheduleMode", r.scheduleMode); put("startTime", r.startTime); put("endTime", r.endTime)
                put("targetPeople", JSONArray(r.targetPeople)); put("targetGroups", JSONArray(r.targetGroups)); put("targetMode", r.targetMode)
            })
        }
        root.put("rules", rules)
        root.put("blueIntensity", ThemeStore.getBlueIntensity(context))
        root.put("menuTransparency", ThemeStore.getMenuTransparency(context))
        root.put("applicationIds", JSONObject().apply {
            AppIdsStore.snapshot(context).forEach { (name, id) -> put(name, id) }
        })

        // Store the selected background image inside the backup so the visual configuration
        // can be restored even when the original document URI is not available afterwards.
        val background = ThemeStore.getBackgroundUri(context)
        if (background != null) {
            runCatching {
                context.contentResolver.openInputStream(background)?.use { input ->
                    root.put("backgroundImageBase64", Base64.encodeToString(input.readBytes(), Base64.NO_WRAP))
                }
            }
        } else {
            root.put("backgroundImageBase64", JSONObject.NULL)
        }

        val peopleData = PeopleStore.load(context)
        root.put("people", peopleArray(peopleData.people))
        root.put("peopleGroups", JSONArray().apply {
            peopleData.groups.forEach { g ->
                put(JSONObject().apply { put("name", g.name); put("people", peopleArray(g.people)); put("excludedContactIds", JSONArray(g.excludedContactIds.toList())); put("included", g.included) })
            }
        })
        return root.toString(2)
    }

    private fun peopleArray(people: List<ContactPerson>) = JSONArray().apply {
        people.forEach { person ->
            put(JSONObject().apply {
                put("name", person.name)
                person.contactId?.let { put("contactId", it) }
                person.lookupKey?.let { put("lookupKey", it) }
                person.phone?.let { put("phone", it) }
            })
        }
    }

    private fun parsePerson(value: Any): ContactPerson {
        return if (value is JSONObject) {
            ContactPerson(
                value.optString("name"),
                value.optString("contactId").ifBlank { null },
                value.optString("lookupKey").ifBlank { null },
                value.optString("phone").ifBlank { null }
            )
        } else ContactPerson(value.toString())
    }

    fun import(context: Context, raw: String) {
        val root = JSONObject(raw)
        val format = root.optString("format")
        require(format == "AM_RESPOSTAS_AUTOMATICAS_BACKUP_1" || format == "AM_RESPOSTAS_AUTOMATICAS_BACKUP_2" || format == "AM_RESPOSTAS_AUTOMATICAS_BACKUP_3") {
            "Ficheiro de backup inválido."
        }

        val rules = mutableListOf<Rule>()
        val arr = root.optJSONArray("rules") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val targetPeople = mutableListOf<String>().apply {
                val a = o.optJSONArray("targetPeople") ?: JSONArray()
                for (j in 0 until a.length()) add(a.optString(j))
            }
            val targetGroups = mutableListOf<String>().apply {
                val a = o.optJSONArray("targetGroups") ?: JSONArray()
                for (j in 0 until a.length()) add(a.optString(j))
            }
            rules += Rule(o.getLong("id"), o.getString("name"), o.getString("instance"), o.getString("message"),
                o.optBoolean("enabled", true), o.optString("scheduleMode", "always"), o.optString("startTime", "18:00"), o.optString("endTime", "08:00"),
                targetPeople, targetGroups, o.optString("targetMode", "allow"))
        }
        val ruleStore = RuleStore(context)
        ruleStore.saveRules(rules)
        ruleStore.setMasterEnabled(root.optBoolean("masterEnabled", true))

        ThemeStore.setBlueIntensity(context, root.optInt("blueIntensity", ThemeStore.DEFAULT_BLUE_INTENSITY))
        ThemeStore.setMenuTransparency(context, root.optInt("menuTransparency", 28))
        root.optJSONObject("applicationIds")?.let { ids ->
            val values = mutableMapOf<String, Int>()
            AppIdsStore.instances.forEach { name ->
                if (ids.has(name)) values[name] = ids.optInt(name, AppIdsStore.get(context, name))
            }
            AppIdsStore.restore(context, values)
        }
        if (root.has("backgroundImageBase64")) {
            val encoded = if (root.isNull("backgroundImageBase64")) null else root.optString("backgroundImageBase64").takeIf { it.isNotBlank() }
            restoreBackground(context, encoded)
        }

        val people = mutableListOf<ContactPerson>()
        val peopleArr = root.optJSONArray("people") ?: JSONArray()
        for (i in 0 until peopleArr.length()) people += parsePerson(peopleArr.get(i))
        val groups = mutableListOf<ContactGroup>()
        val groupArr = root.optJSONArray("peopleGroups") ?: JSONArray()
        for (i in 0 until groupArr.length()) {
            val o = groupArr.getJSONObject(i)
            val members = o.optJSONArray("people") ?: JSONArray()
            groups += ContactGroup(
                o.optString("name"),
                MutableList(members.length()) { j -> parsePerson(members.get(j)) },
                mutableSetOf<String>().apply {
                    val excluded = o.optJSONArray("excludedContactIds") ?: JSONArray()
                    for (j in 0 until excluded.length()) excluded.optString(j).takeIf { it.isNotBlank() }?.let { add(it) }
                },
                o.optBoolean("included", true)
            )
        }
        PeopleStore.save(context, PeopleData(people, groups))
    }

    private fun restoreBackground(context: Context, encoded: String?) {
        if (encoded == null) {
            ThemeStore.setBackgroundUri(context, null)
            return
        }
        runCatching {
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            val file = java.io.File(context.filesDir, "am_background_backup.jpg")
            file.outputStream().use { it.write(bytes) }
            ThemeStore.setBackgroundUri(context, Uri.fromFile(file))
        }
    }
}
