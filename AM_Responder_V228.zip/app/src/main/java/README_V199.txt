AM Respostas Automáticas — V199

Base exclusiva: V198.

Correções desta versão:
- Arrastar organizações: o gesto fica capturado pelo puxador, impede o ScrollView de mover o fundo durante o arrasto e apresenta o cartão elevado/levitado enquanto é movido.
- Cabeçalho das organizações: passa a mostrar “Organização” na primeira linha e o nome da organização na segunda, com o puxador mais à esquerda e menos largura ocupada pelo estado.
- Mantido o grupo fechado por defeito e o limite interno de cinco contactos quando aberto.
- Corrigida também a referência de LayoutParams do contentor interno para garantir compilação.
- Nenhuma outra funcionalidade foi alterada.
