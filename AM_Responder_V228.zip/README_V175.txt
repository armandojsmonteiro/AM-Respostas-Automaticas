AM Respostas Automáticas — V175

Base: V174

Correção de compilação:
- Corrigido o tratamento nullable de pendingGroupName em ThemesActivity.kt.
- Não foram alteradas outras funcionalidades da V174.
- versionCode: 175
- versionName: 175
