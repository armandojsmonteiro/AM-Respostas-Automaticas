V148 – Base V147

Alterações: substituição dos ícones WhatsApp Business, WhatsApp Business Clonado e WhatsApp Business Trabalho por versões de alta resolução, sem os artefactos azuis visíveis; novo ícone da aplicação usando a imagem fornecida pelo utilizador (87440.png), com o fundo exterior preto tornado transparente.
Não foram alteradas regras, instâncias, menus, lógica ou comportamento da V147.
