AM Respostas Automáticas — V150

Base: V148.

Alterações: corrigido o ícone da aplicação para usar efetivamente o PNG fornecido pelo utilizador, removendo apenas o fundo exterior preto e preservando o desenho original. Substituídos os três ícones WhatsApp Business (normal, Clonado e Trabalho) por versões derivadas diretamente do PNG fornecido, em alta resolução e com fundo exterior transparente; mantidos os distintivos 2 e Trabalho.

A instância WhatsApp Business Trabalho continua disponível na seleção de regras e mantém o mesmo tratamento de perfil Trabalho das restantes aplicações. Não foram alterados menus, regras, lógica de respostas, histórico ou configurações.

VersionCode: 144 · versionName: 150.


Alteração V150: substituídos os ícones do WhatsApp Business Clonado e WhatsApp Business Trabalho pelos símbolos fornecidos, com fundo exterior transparente e sem margens exteriores. Nenhuma outra funcionalidade foi alterada.
