AM Respostas Automáticas — V206

Base: V205 exclusivamente.

Correção:
- Corrigidas apenas as referências inválidas `insetLeft` e `insetRight` em ThemesActivity.kt que impediam a compilação Kotlin.
- Nenhuma alteração funcional, visual ou de comportamento foi introduzida nesta versão.
- Mantidas as alterações já existentes na V205, incluindo atualização faseada de contactos em lotes de 25 com intervalo de 2 segundos, processamento fora da thread da interface, RecyclerView para grupos grandes e restantes correções anteriores.
