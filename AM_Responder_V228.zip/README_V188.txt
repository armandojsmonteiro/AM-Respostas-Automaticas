AM Respostas Automáticas — V188

Base exclusiva: V187.

Alterações desta versão:
- Campo Nome da organização: reposicionado dentro da área útil do diálogo, alinhado à esquerda sem ficar cortado.
- Azul das aplicações: a intensidade escolhida no menu Temas passa a aplicar-se de forma consistente aos controlos azuis da aplicação, incluindo botões, barras/indicadores e interruptores Ativo.
- Os estados verdes/vermelhos de Incluída/Excluída não são alterados pelo controlo de intensidade do azul.

Nenhuma outra alteração funcional foi introduzida.
