AM Respostas Automáticas — V227

Base: V226 (interface aprovada) com o motor de notificações preservado da linha funcional V221.

Objetivo desta versão: diagnóstico do próprio NotificationListenerService, sem alterar a lógica de resposta automática.

Alterações V227:
- versionCode = 227
- versionName = "227"
- Registo explícito do ciclo de vida do NotificationListenerService.
- Registo imediato de notificações suportadas antes dos filtros de processamento.
- Registo explícito de notificações descartadas por serem ongoing/group summary/conversa não direta.
- Diagnóstico mostra o estado do acesso do Notification Listener no Android.
- Histórico continua separado do diagnóstico e limitado a interações pessoa-a-pessoa.
- Grupos, canais e comunidades não entram no Histórico e não acionam respostas.
- Motor de resposta preservado; não foi introduzida alteração de regra/RemoteInput nesta versão.

Teste principal:
1. Confirmar no Diagnóstico se o Listener aparece como ATIVO.
2. Enviar uma mensagem privada no Telegram.
3. Abrir Histórico > Diagnóstico.
4. Verificar a entrada "Notificação recebida" e o percurso subsequente.
