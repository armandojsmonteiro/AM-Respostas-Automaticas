AM Respostas Automáticas — V219

Base obrigatória: V217. A V218 foi descartada por falha de compilação.

Única alteração desta versão:
- Corrigido apenas o diálogo “Apagar regra?”.
- O texto da mensagem fica alinhado à esquerda.
- Os botões “Cancelar” e “Apagar” usam o mesmo padrão visual, dimensões, alinhamento e espaçamento dos restantes diálogos de confirmação da aplicação.
- Mantido o espaço inferior branco dentro do balão.
- Não foram alterados menus, regras, contactos, configurações ou outras funcionalidades.
