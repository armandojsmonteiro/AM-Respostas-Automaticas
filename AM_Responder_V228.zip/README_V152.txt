AM Respostas Automáticas — V152

Base: V150.
Alterações: aumento muito ligeiro (7%) apenas no ícone WhatsApp Business normal na lista de regras, para ficar visualmente mais coerente com as variantes Clonado e Trabalho. Nenhuma outra funcionalidade, ícone, menu ou lógica foi alterada.

VersionCode: 146 · versionName: 152.
