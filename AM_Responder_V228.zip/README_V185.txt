AM Respostas Automáticas — V185

Base obrigatória: V180 enviada para esta alteração.

Alterações desta versão, e apenas estas:
- O título “Limpar fotografia de fundo?” mantém-se numa única linha, com tamanho ligeiramente reduzido e negrito preservado.
- No diálogo “Adicionar organização”, o título e o campo “Nome da organização” ficam centrados.
- O estado Excluída/Incluída da organização passa a refletir-se efetivamente em todos os membros apresentados.
- Ao voltar a marcar a organização como Incluída, são recuperados os estados individuais anteriormente guardados (as exclusões individuais continuam memorizadas).
- Os botões de editar e apagar de pessoas e organizações voltam a usar os ícones gráficos correspondentes, incluindo o caixote do lixo no lado direito.
- Não foram revertidas nem alteradas outras funcionalidades da base V180.
- versionCode: 185
- versionName: 185
