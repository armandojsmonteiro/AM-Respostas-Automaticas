AM Respostas Automáticas — V187

Base exclusiva: V186.

Alterações desta versão:
- Pessoas: nome na primeira linha e telefone na segunda, com mais espaço horizontal para o número.
- Botões de estado Incluída/Excluída ligeiramente compactados para garantir que o telefone cabe.
- Lápis e caixote do lixo mantidos sem fundo/quadrado branco e aproximados.
- Diálogos: títulos normalizados para tamanho compacto e consistente.
- Identificação das aplicações: título em uma única linha.
- Limpar fotografia de fundo: título deixa de ser cortado.
- Adicionar organização: título reduzido e campo Nome da organização alinhado à esquerda.
- Nenhuma alteração às restantes funcionalidades.
