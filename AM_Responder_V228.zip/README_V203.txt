AM Respostas Automáticas — V203

Base: V201 exclusivamente. A V202 foi descartada.

Alterações:
- Mantidos os restantes comportamentos da V201.
- Botões “Atualizar” e “＋ Pessoa” das organizações alinhados à esquerda e com largura ajustada ao texto, sem espaço lateral excessivo.
- Lista de pessoas de organizações grandes passou a usar RecyclerView, criando apenas as linhas visíveis e evitando bloquear a interface ao abrir/fechar organizações com centenas de pessoas.
- Sincronização dos contactos continua fora da thread da interface.
- Sincronização dos contactos selecionados processada em lotes de 25.
- Intervalo entre lotes: 2 segundos (em vez dos 5 segundos inicialmente considerados).
- Cada lote é guardado progressivamente, sem apagar/reconstruir a lista existente.
- A interface só é reconstruída quando a sincronização deteta alterações; um simples regresso/abertura do menu não provoca uma reconstrução desnecessária.
- Mantida a execução em background e o intervalo mínimo de sincronização de 60 segundos.
- Diálogo “Apagar regra?” reforçado para manter o painel e os botões “Cancelar”/“Apagar” visíveis dentro do balão.
