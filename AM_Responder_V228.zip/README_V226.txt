AM Respostas Automáticas — V226

Base: V221 funcional.
Alterações: navegação entre ecrãs sem animação lateral; histórico separado do diagnóstico; histórico apenas para interações pessoa-a-pessoa; restauração do motor de resposta da V221 com instrumentação não-crítica.
VersionCode: 226
VersionName: 226
