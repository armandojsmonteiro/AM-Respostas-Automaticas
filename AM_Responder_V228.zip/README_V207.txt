AM Respostas Automáticas — V207

Base: V206 exclusivamente.

Alteração:
- Corrigido apenas o espaçamento inferior do diálogo “Apagar regra?”.
- Mantido o painel de botões “Cancelar” / “Apagar” com 16dp de espaço inferior, para que exista a mesma folga visual entre os botões e o limite inferior do cartão branco dos restantes diálogos.
- Nenhuma outra função, regra, layout, menu ou comportamento foi alterado.
