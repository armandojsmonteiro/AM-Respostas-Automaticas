AM Respostas Automáticas — V221

Base: V219.

Alteração única em relação ao V219:
- No diálogo “Apagar regra?”, o título “Apagar regra?” volta a ficar centrado.
- O texto mantém-se alinhado à esquerda.
- Os botões, dimensões, posições, espaçamentos e restante aplicação não foram alterados.

V220 foi descartada conforme solicitado.
