AM Respostas Automáticas — V210

Base: V209 exclusivamente.

Correção única:
- Mantido o diálogo Apagar regra da V209 e acrescentado apenas espaço inferior no painel dos botões Cancelar e Apagar, para ficar visualmente alinhado com o espaço inferior dos restantes menus.
- Nenhuma outra área, função, regra, menu, configuração ou lógica foi alterada.
