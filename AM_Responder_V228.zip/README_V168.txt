AM Responder — V168

Alterações do diálogo Identificação das aplicações / IDs:
- Botão Procurar passa a mostrar apenas "Procurar".
- IDs passam a ser apresentados dentro de círculos, sem a linha/traço do EditText.
- ID confirmado por uma notificação fica verde.
- Um ID novo/diferente detetado pela pesquisa fica azul.
- A pesquisa identifica no estado exatamente a aplicação e o ID encontrado.
- Conteúdo do diálogo com mais espaço lateral para melhor leitura.
- Botões Cancelar, Procurar e Guardar mantidos sempre visíveis.
- Diálogo com cantos arredondados.
- Campos continuam editáveis manualmente.

Versão Android:
- versionCode = 168
- versionName = "168"
