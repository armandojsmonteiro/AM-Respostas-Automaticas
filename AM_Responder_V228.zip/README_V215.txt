AM Respostas Automáticas — V215

Base: V210-1 fornecida pelo utilizador.

Única alteração desta versão:
- Corrigido o diálogo “Apagar regra?” para que os botões azuis “Cancelar” e “Apagar” sejam construídos dentro do próprio conteúdo do diálogo.
- Os dois botões ficam sempre visíveis e na zona inferior do cartão branco.
- Mantido espaço inferior branco abaixo dos botões, igual ao pretendido nas restantes caixas de confirmação.
- Não foram alterados menus, regras, contactos, configurações ou outras funcionalidades.
