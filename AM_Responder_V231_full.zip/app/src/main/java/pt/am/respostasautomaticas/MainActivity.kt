package pt.am.respostasautomaticas

import android.app.Activity
import android.content.Intent
import android.content.ComponentName
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.content.DialogInterface
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.ItemTouchHelper
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {
    private lateinit var store: RuleStore
    private lateinit var rules: MutableList<Rule>
    private lateinit var adapter: RulesAdapter
    private lateinit var master: MaterialSwitch
    private lateinit var status: TextView
    private lateinit var root: View
    private lateinit var topBar: View
    private lateinit var bottomNav: View
    private lateinit var backgroundImage: ImageView
    private lateinit var backgroundOverlay: View
    private lateinit var sectionHeader: View
    private lateinit var sectionTitle: TextView
    private lateinit var addButton: com.google.android.material.button.MaterialButton
    private lateinit var historyPanel: View
    private lateinit var historyText: TextView
    private lateinit var historyScroll: ScrollView
    private var diagnosticSelected = false

    private val instances = listOf(
        "WhatsApp",
        "WhatsApp Clonado",
        "WhatsApp Trabalho",
        "WhatsApp Business",
        "WhatsApp Business Clonado",
        "WhatsApp Business Trabalho",
        "Telegram",
        "Telegram Clonado",
        "Telegram Trabalho",
        "iMe",
        "iMe Trabalho",
        "Nicegram",
        "Nicegram Trabalho",
        "Signal",
        "Signal Clonado",
        "Signal Trabalho",
        "SMS"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = RuleStore(this)
        rules = store.loadRules()
        root = findViewById(R.id.rootMain)
        topBar = findViewById(R.id.topBar)
        bottomNav = findViewById(R.id.bottomNav)
        backgroundImage = findViewById(R.id.imgBackground)
        backgroundOverlay = findViewById(R.id.backgroundOverlay)
        sectionHeader = findViewById(R.id.sectionHeader)
        sectionTitle = findViewById(R.id.tvSectionTitle)
        addButton = findViewById(R.id.btnAdd)
        historyPanel = findViewById(R.id.historyPanel)
        historyText = findViewById(R.id.tvHistoryContent)
        historyScroll = findViewById(R.id.historyScroll)
        master = findViewById(R.id.switchMaster)
        status = findViewById(R.id.tvStatus)

        applyVisualTheme()
        ThemeStore.applyBlueTheme(root, this)
        ThemeStore.applyDynamicTheme(root, this)
        applyBackground()

        master.isChecked = store.isMasterEnabled()
        updateMasterStatus(master.isChecked)
        master.setOnCheckedChangeListener { _, checked ->
            store.setMasterEnabled(checked)
            updateMasterStatus(checked)
        }

        adapter = RulesAdapter(
            rules,
            onToggle = { store.saveRules(rules) },
            onMove = { from, to ->
                if (from in rules.indices && to in rules.indices) {
                    val moved = rules.removeAt(from)
                    rules.add(to, moved)
                    store.saveRules(rules)
                }
            },
            onEdit = { showRuleDialog(it) },
            onDelete = { rule ->
                showDeleteRuleDialog(rule)
            }
        )

        findViewById<RecyclerView>(R.id.recyclerRules).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        val dragCallback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                rules.add(to, rules.removeAt(from))
                adapter.notifyItemMoved(from, to)
                store.saveRules(rules)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit

            override fun isLongPressDragEnabled(): Boolean = false

            override fun isItemViewSwipeEnabled(): Boolean = false
        }
        val itemTouchHelper = ItemTouchHelper(dragCallback)
        itemTouchHelper.attachToRecyclerView(findViewById(R.id.recyclerRules))
        adapter.setDragStarter { holder ->
            itemTouchHelper.startDrag(holder)
        }

        findViewById<View>(R.id.btnAdd).setOnClickListener { showRuleDialog(null) }

        findViewById<TextView>(R.id.navRules).setOnClickListener { showRules() }
        findViewById<TextView>(R.id.navHistory).setOnClickListener { showHistory() }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnHistoryView).setOnClickListener {
            showHistoryContent(false)
        }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnDiagnosticView).setOnClickListener {
            showHistoryContent(true)
        }
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnClearHistory).setOnClickListener {
            showClearHistoryDialog()
        }
        findViewById<TextView>(R.id.navSettings).setOnClickListener {
            startActivity(Intent(this, ThemesActivity::class.java))
            overridePendingTransition(0, 0)
        }

        ContactSync.syncAsync(this, force = false) { result ->
            if (result.removed > 0 && !isFinishing && !isDestroyed && ::adapter.isInitialized) {
                rules = store.loadRules()
                adapter.notifyDataSetChanged()
            }
        }

        when (intent.getStringExtra("screen")) {
            "history" -> showHistory()
            "rules" -> showRules()
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        when (intent?.getStringExtra("screen")) {
            "history" -> showHistory()
            "rules" -> showRules()
        }
    }

    private fun showDeleteRuleDialog(rule: Rule) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Apagar regra?")
            .setMessage("Apagar a regra \"${rule.name}\"?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar") { _, _ ->
                rules.remove(rule)
                store.saveRules(rules)
                adapter.notifyDataSetChanged()
            }
            .create()

        dialog.show()
        styleDialogButtons(dialog)
        styleDialogCard(dialog)
        styleDialogTitleAndSpacing(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun styleDialogCard(dialog: AlertDialog) {
        val palette = ThemeStore.palette(this)
        dialog.window?.decorView?.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(22).toFloat()
            setColor(palette.surface)
        }

        dialog.findViewById<TextView>(android.R.id.message)?.let { message ->
            message.setPadding(dp(22), dp(8), dp(22), dp(16))
        }
    }

    private fun styleDialogButtons(dialog: AlertDialog) {
        val blue = ThemeStore.palette(this).accent
        listOf(AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_POSITIVE).forEach { which ->
            dialog.getButton(which)?.let { button ->
                button.setTextColor(Color.WHITE)
                button.backgroundTintList = null
                button.background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(blue)
                }
                button.minWidth = 0
                button.minimumWidth = 0
                button.minHeight = dp(40)
                button.minimumHeight = dp(40)
                button.setPadding(dp(12), 0, dp(12), 0)
                (button.layoutParams as? android.widget.LinearLayout.LayoutParams)?.let { lp ->
                    lp.width = android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                    lp.weight = 0f
                    lp.marginStart = dp(4)
                    lp.marginEnd = dp(4)
                    button.layoutParams = lp
                }
            }
        }
    }

    private fun styleDialogTitleAndSpacing(dialog: AlertDialog) {
        val titleId = androidx.appcompat.R.id.alertTitle
        dialog.findViewById<TextView>(titleId)?.let { title ->
            title.textSize = 18f
            title.setTypeface(null, android.graphics.Typeface.BOLD)
            title.setTextColor(ThemeStore.palette(this).text)
            title.gravity = android.view.Gravity.CENTER
            title.setPadding(dp(14), dp(18), dp(14), dp(8))
        }

        dialog.findViewById<TextView>(android.R.id.message)?.let { message ->
            message.setPadding(dp(22), dp(4), dp(22), dp(20))
        }

        val buttonPanelId = androidx.appcompat.R.id.buttonPanel
        dialog.findViewById<View>(buttonPanelId)?.let { panel ->
            panel.setPadding(panel.paddingLeft, panel.paddingTop, panel.paddingRight, dp(16))
        }
    }

    override fun onResume() {
        super.onResume()
        // Reload persisted data so an import made in Configurações is immediately reflected here.
        if (::store.isInitialized && ::adapter.isInitialized) {
            // Do not replace the list: RulesAdapter keeps a reference to this exact object.
            // Mutating it in place keeps saved/imported edits visible immediately and after
            // navigating away and back.
            rules.clear()
            rules.addAll(store.loadRules())
            adapter.notifyDataSetChanged()
            master.setOnCheckedChangeListener(null)
            master.isChecked = store.isMasterEnabled()
            updateMasterStatus(master.isChecked)
            master.setOnCheckedChangeListener { _, checked ->
                store.setMasterEnabled(checked)
                updateMasterStatus(checked)
            }
        }
        applyVisualTheme()
        applyBackground()
        if (historyPanel.visibility == View.VISIBLE) {
            showHistoryContent(diagnosticSelected)
        }
    }

    private fun applyVisualTheme() {
        val p = ThemeStore.palette(this)
        val menuAlpha = (255f * (1f - ThemeStore.getMenuTransparency(this) / 100f)).toInt().coerceIn(0, 255)
        val surface = withAlpha(p.surface, menuAlpha)
        root.setBackgroundColor(p.background)
        topBar.setBackgroundColor(surface)
        sectionHeader.setBackgroundColor(surface)
        bottomNav.setBackgroundColor(surface)
        historyPanel.setBackgroundColor(surface)
        historyText.setBackgroundColor(Color.TRANSPARENT)
        sectionTitle.setTextColor(p.text)
        status.setTextColor(p.muted)
        historyText.setTextColor(p.text)
        addButton.backgroundTintList = android.content.res.ColorStateList.valueOf(p.accent)
        ThemeStore.applyBlueTheme(root, this)
        if (historyPanel.visibility == View.VISIBLE) {
            styleHistoryTabs()
        }
        window.statusBarColor = if (ThemeStore.isNightMode(this)) Color.rgb(4, 10, 30) else surface
        window.navigationBarColor = if (ThemeStore.isNightMode(this)) Color.rgb(3, 8, 24) else withAlpha(p.background, menuAlpha)
        window.decorView.systemUiVisibility = if (ThemeStore.isNightMode(this)) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        ThemeStore.applyDynamicTheme(root, this)
        setNavSelected(if (historyPanel.visibility == View.VISIBLE) R.id.navHistory else R.id.navRules)
    }

    private fun applyBackground() {
        val uri = ThemeStore.getBackgroundUri(this)
        backgroundOverlay.visibility = View.GONE
        backgroundOverlay.setBackgroundColor(Color.TRANSPARENT)
        backgroundOverlay.alpha = 0f
        if (ThemeStore.isNightMode(this)) {
            backgroundImage.visibility = View.GONE
        } else if (uri == null) {
            backgroundImage.visibility = View.GONE
        } else {
            runCatching {
                backgroundImage.setImageURI(uri)
                backgroundImage.visibility = View.VISIBLE
            }.onFailure {
                ThemeStore.setBackgroundUri(this, null)
                backgroundImage.visibility = View.GONE
            }
        }
        applyVisualTheme()
        applyMenuTransparencyToCards()
    }

    private fun applyMenuTransparencyToCards() {
        if (!::adapter.isInitialized) return
        adapter.notifyDataSetChanged()
    }

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))

    private fun showRules() {
        sectionTitle.text = "Regras"
        addButton.visibility = View.VISIBLE
        findViewById<RecyclerView>(R.id.recyclerRules).visibility = View.VISIBLE
        historyPanel.visibility = View.GONE
        setNavSelected(R.id.navRules)
    }

    private fun showHistory() {
        sectionTitle.text = "Histórico"
        addButton.visibility = View.GONE
        findViewById<RecyclerView>(R.id.recyclerRules).visibility = View.GONE
        historyPanel.visibility = View.VISIBLE
        showHistoryContent(false)
        setNavSelected(R.id.navHistory)
    }

    private fun styleHistoryTabs() {
        if (!::historyPanel.isInitialized || historyPanel.visibility != View.VISIBLE) return
        val historyButton = findViewById<com.google.android.material.button.MaterialButton>(R.id.btnHistoryView)
        val diagnosticButton = findViewById<com.google.android.material.button.MaterialButton>(R.id.btnDiagnosticView)
        val palette = ThemeStore.palette(this)

        fun style(button: com.google.android.material.button.MaterialButton, selected: Boolean) {
            // Use an explicit drawable instead of MaterialButton's state tint.
            // This prevents both tabs from inheriting the blue selected state.
            button.backgroundTintList = null
            button.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = dp(12).toFloat()
                setColor(if (selected) palette.accent else palette.surface)
            }
            button.setTextColor(if (selected) Color.WHITE else palette.text)
            button.isSelected = selected
        }

        style(historyButton, !diagnosticSelected)
        style(diagnosticButton, diagnosticSelected)
    }

    private fun showClearHistoryDialog() {
        val message = if (diagnosticSelected) {
            "Queres limpar todo o diagnóstico?"
        } else {
            "Queres limpar todo o histórico?"
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (diagnosticSelected) "Limpar diagnóstico?" else "Limpar histórico?")
            .setMessage(message)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar") { _, _ ->
                if (diagnosticSelected) {
                    DiagnosticsStore.clearTechnical(this)
                } else {
                    DiagnosticsStore.clearHistory(this)
                }
                showHistoryContent(diagnosticSelected)
            }
            .create()
        dialog.show()
        styleDialogButtons(dialog)
        styleDialogCard(dialog)
        styleDialogTitleAndSpacing(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
    }

    private fun showHistoryContent(diagnostic: Boolean) {
        diagnosticSelected = diagnostic
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnClearHistory).text =
            "Limpar"
        styleHistoryTabs()
        historyText.text = if (diagnostic) {
            buildString {
                append(listenerStatusText())
                append("\n\n")
                append(DiagnosticsStore.getTechnical(this@MainActivity))
            }
        } else {
            DiagnosticsStore.get(this)
        }
        historyScroll.post { historyScroll.fullScroll(View.FOCUS_UP) }
    }


    private fun listenerStatusText(): String {
        val enabled = try {
            val raw = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
            val serviceName = ComponentName(this, NotificationDiagnosticService::class.java).flattenToString()
            raw.split(":").any { it.equals(serviceName, ignoreCase = true) }
        } catch (_: Exception) {
            false
        }
        return if (enabled) {
            "🟢 Listener do Android: ATIVO"
        } else {
            "🔴 Listener do Android: INATIVO — ativar Acesso às notificações"
        }
    }

    private fun setNavSelected(selected: Int) {
        val ids = listOf(R.id.navRules, R.id.navHistory, R.id.navSettings)
        val p = ThemeStore.palette(this)
        val navAlpha = (255f * (1f - ThemeStore.getMenuTransparency(this) / 100f)).toInt().coerceIn(0, 255)
        ids.forEach { id ->
            val v = findViewById<TextView>(id)
            val active = id == selected
            v.isSelected = active
            val color = if (active) p.accent else p.muted
            v.setTextColor(color)
            v.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(color)
            v.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                cornerRadius = 16f * resources.displayMetrics.density
                setColor(if (active) withAlpha(p.surfaceAlt, navAlpha) else Color.TRANSPARENT)
            }
        }
    }

    private fun updateMasterStatus(enabled: Boolean) {
        status.text = if (enabled) "Ativo" else "Desativado"
    }

    private fun showRuleDialog(existing: Rule?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_rule, null)
        val title = view.findViewById<TextView>(R.id.tvDialogTitle)
        val name = view.findViewById<EditText>(R.id.etName)
        val spinner = view.findViewById<Spinner>(R.id.spinnerInstance)
        val message = view.findViewById<EditText>(R.id.etMessage)
        val radioAlways = view.findViewById<RadioButton>(R.id.radioAlways)
        val radioScheduled = view.findViewById<RadioButton>(R.id.radioScheduled)
        val timeRow = view.findViewById<View>(R.id.timeRow)
        val startTime = view.findViewById<EditText>(R.id.etStartTime)
        val endTime = view.findViewById<EditText>(R.id.etEndTime)
        val targetsSummary = view.findViewById<TextView>(R.id.tvTargetsSummary)
        val choosePeople = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnChoosePeople)
        val chooseGroups = view.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnChooseGroups)
        val dialogAccent = ThemeStore.palette(this).accent
        choosePeople.backgroundTintList = android.content.res.ColorStateList.valueOf(dialogAccent)
        chooseGroups.backgroundTintList = android.content.res.ColorStateList.valueOf(dialogAccent)

        val instanceAdapter = InstanceSpinnerAdapter(this, instances)
        spinner.adapter = instanceAdapter
        spinner.post {
            if (spinner.width > 0) {
                spinner.dropDownWidth = spinner.width
                spinner.dropDownHorizontalOffset = 0
            }
        }

        val selectedPeople = mutableListOf<String>()
        val selectedGroups = mutableListOf<String>()
        var targetMode = existing?.targetMode ?: "allow"
        existing?.let {
            selectedPeople.addAll(it.targetPeople)
            selectedGroups.addAll(it.targetGroups)
        }
        val targetModeGroup = view.findViewById<RadioGroup>(R.id.targetModeGroup)
        val radioAllowed = view.findViewById<RadioButton>(R.id.radioAllowedTargets)
        val radioDenied = view.findViewById<RadioButton>(R.id.radioDeniedTargets)

        fun updateTargetsSummary() {
            val peopleData = PeopleStore.load(this)
            val peopleNames = selectedPeople.mapNotNull { key ->
                val person = peopleData.people.firstOrNull { personKey(it) == key }
                    ?: peopleData.groups.asSequence().flatMap { it.people.asSequence() }.firstOrNull { personKey(it) == key }
                person?.name ?: key.removePrefix("id:").removePrefix("name:")
            }
            val parts = mutableListOf<String>()
            if (selectedGroups.isNotEmpty()) parts += "Grupos: ${selectedGroups.joinToString(", ")}" 
            if (peopleNames.isNotEmpty()) parts += "Pessoas: ${peopleNames.joinToString(", ")}" 
            val prefix = if (targetMode == "deny") "Excluídos" else "Permitidos"
            targetsSummary.text = if (parts.isEmpty()) "$prefix: nenhum selecionado" else "$prefix: " + parts.joinToString("  •  ")
        }

        fun updateTargetModeLabels() {
            val allow = targetMode != "deny"
            radioAllowed.isChecked = allow
            radioDenied.isChecked = !allow
            choosePeople.text = "＋ Pessoas"
            chooseGroups.text = "＋ Grupos"
        }
        targetModeGroup.setOnCheckedChangeListener { _, checkedId ->
            targetMode = if (checkedId == R.id.radioDeniedTargets) "deny" else "allow"
            updateTargetModeLabels()
            updateTargetsSummary()
        }

        fun updateScheduleVisibility() { timeRow.visibility = if (radioScheduled.isChecked) View.VISIBLE else View.GONE }
        radioAlways.setOnClickListener { updateScheduleVisibility() }
        radioScheduled.setOnClickListener { updateScheduleVisibility() }

        if (existing != null) {
            title.text = "Editar regra"
            name.setText(existing.name)
            spinner.setSelection(instanceAdapter.positionOf(existing.instance))
            message.setText(existing.message)
            radioScheduled.isChecked = existing.scheduleMode == "scheduled"
            radioAlways.isChecked = existing.scheduleMode != "scheduled"
            startTime.setText(existing.startTime)
            endTime.setText(existing.endTime)
            updateScheduleVisibility()
        }

        choosePeople.setOnClickListener {
            showPeoplePicker(selectedPeople) { chosen ->
                selectedPeople.clear()
                selectedPeople.addAll(chosen)
                updateTargetsSummary()
            }
        }
        chooseGroups.setOnClickListener {
            showGroupPicker(selectedGroups) { chosen ->
                selectedGroups.clear()
                selectedGroups.addAll(chosen)
                updateTargetsSummary()
            }
        }
        updateTargetModeLabels()
        updateTargetsSummary()

        AlertDialog.Builder(this)
            .setView(view)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
            .apply {
                setOnShowListener {
                    getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val ruleName = name.text.toString().trim()
                        val reply = message.text.toString().trim()
                        if (ruleName.isEmpty() || reply.isEmpty()) {
                            Toast.makeText(this@MainActivity, "Preenche o nome e a resposta.", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        val scheduled = radioScheduled.isChecked
                        val start = startTime.text.toString().trim().ifEmpty { "18:00" }
                        val end = endTime.text.toString().trim().ifEmpty { "08:00" }
                        val selectedInstance = instanceAdapter.instanceAt(spinner.selectedItemPosition)
                        if (selectedInstance == null) {
                            Toast.makeText(this@MainActivity, "Escolhe uma aplicação / instância.", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        if (existing == null) {
                            rules.add(
                                Rule(
                                    System.currentTimeMillis(), ruleName, selectedInstance, reply, true,
                                    if (scheduled) "scheduled" else "always", start, end,
                                    selectedPeople.toMutableList(), selectedGroups.toMutableList(), targetMode
                                )
                            )
                        } else {
                            existing.name = ruleName
                            existing.instance = selectedInstance
                            existing.message = reply
                            existing.scheduleMode = if (scheduled) "scheduled" else "always"
                            existing.startTime = start
                            existing.endTime = end
                            existing.targetPeople = selectedPeople.toMutableList()
                            existing.targetGroups = selectedGroups.toMutableList()
                            existing.targetMode = targetMode
                        }
                        store.saveRules(rules)
                        adapter.notifyDataSetChanged()
                        dismiss()
                    }
                }
            }.show()
    }

    private fun personKey(person: ContactPerson): String =
        person.contactId?.let { "id:$it" } ?: "name:${person.name}"

    private fun showPeoplePicker(selected: MutableList<String>, onDone: (List<String>) -> Unit) {
        val data = PeopleStore.load(this)
        val people = mutableListOf<ContactPerson>()
        people.addAll(data.people)
        data.groups.forEach { group ->
            group.people.forEach { person ->
                if (people.none { personKey(it) == personKey(person) }) people.add(person)
            }
        }
        if (people.isEmpty()) {
            Toast.makeText(this, "Ainda não existem pessoas. Adiciona-as primeiro em Configurações.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = people.map { if (it.phone.isNullOrBlank()) it.name else "${it.name}\n${it.phone}" }.toTypedArray()
        val checked = people.map { personKey(it) in selected }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Pessoas da regra")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                onDone(people.filterIndexed { index, _ -> checked[index] }.map { personKey(it) })
            }
            .show()
    }

    private fun showGroupPicker(selected: MutableList<String>, onDone: (List<String>) -> Unit) {
        val groups = PeopleStore.load(this).groups
        if (groups.isEmpty()) {
            Toast.makeText(this, "Ainda não existem grupos. Cria-os primeiro em Configurações.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = groups.map { group ->
            val count = group.people.size
            if (count == 1) "${group.name}  ·  1 pessoa" else "${group.name}  ·  $count pessoas"
        }.toTypedArray()
        val checked = groups.map { it.name in selected }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle("Grupos da regra")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                onDone(groups.filterIndexed { index, _ -> checked[index] }.map { it.name })
            }
            .show()
    }

    private class InstanceSpinnerAdapter(context: android.content.Context, private val instances: List<String>) : BaseAdapter() {
        private data class Row(val label: String, val instance: String?, val header: Boolean)
        private val rows = buildList {
            add(Row("WhatsApp", null, true)); add(Row("WhatsApp", "WhatsApp", false)); add(Row("WhatsApp Clonado", "WhatsApp Clonado", false)); add(Row("WhatsApp Trabalho", "WhatsApp Trabalho", false))
            add(Row("WhatsApp Business", null, true)); add(Row("WhatsApp Business", "WhatsApp Business", false)); add(Row("WhatsApp Business Clonado", "WhatsApp Business Clonado", false)); add(Row("WhatsApp Business Trabalho", "WhatsApp Business Trabalho", false))
            add(Row("Telegram", null, true)); add(Row("Telegram", "Telegram", false)); add(Row("Telegram Clonado", "Telegram Clonado", false)); add(Row("Telegram Trabalho", "Telegram Trabalho", false))
            add(Row("iMe", null, true)); add(Row("iMe", "iMe", false)); add(Row("iMe Trabalho", "iMe Trabalho", false))
            add(Row("Nicegram", null, true)); add(Row("Nicegram", "Nicegram", false)); add(Row("Nicegram Trabalho", "Nicegram Trabalho", false))
            add(Row("Signal", null, true)); add(Row("Signal", "Signal", false)); add(Row("Signal Clonado", "Signal Clonado", false)); add(Row("Signal Trabalho", "Signal Trabalho", false))
            add(Row("SMS", null, true)); add(Row("SMS", "SMS", false))
        }
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any? = rows[position].instance
        override fun getItemId(position: Int): Long = position.toLong()
        override fun isEnabled(position: Int): Boolean = !rows[position].header
        fun instanceAt(position: Int): String? = rows.getOrNull(position)?.instance
        fun positionOf(instance: String): Int { val p = rows.indexOfFirst { it.instance == instance }; return if (p >= 0) p else rows.indexOfFirst { !it.header } }
        private fun iconFor(instance: String): Int = when (instance) {
            "WhatsApp Clonado" -> R.drawable.ic_whatsapp_clone
            "WhatsApp Trabalho" -> R.drawable.ic_whatsapp_work
            "WhatsApp Business Clonado" -> R.drawable.ic_whatsapp_business_clone
            "WhatsApp Business Trabalho" -> R.drawable.ic_whatsapp_business_work
            "WhatsApp Business" -> R.drawable.ic_whatsapp_business
            "WhatsApp" -> R.drawable.ic_whatsapp
            "Telegram Clonado" -> R.drawable.ic_telegram_clone
            "Telegram Trabalho" -> R.drawable.ic_telegram_work
            "Telegram" -> R.drawable.ic_telegram
            "Signal Clonado" -> R.drawable.ic_signal_clone
            "Signal Trabalho" -> R.drawable.ic_signal_work
            "Signal" -> R.drawable.ic_signal
            "iMe Trabalho" -> R.drawable.ic_ime_work
            "iMe" -> R.drawable.ic_ime
            "Nicegram Trabalho" -> R.drawable.ic_nicegram_work
            "Nicegram" -> R.drawable.ic_nicegram
            "SMS" -> R.drawable.ic_sms
            else -> R.drawable.ic_app
        }

        private fun textView(parent: android.view.ViewGroup): TextView = TextView(parent.context).apply {
            setPadding(18, 12, 18, 12)
            textSize = 16f
            setTextColor(parent.context.getColor(R.color.am_text))
        }

        private fun instanceRow(parent: android.view.ViewGroup, row: Row, dropDown: Boolean): View {
            if (row.header) {
                return textView(parent).apply {
                    text = row.label.uppercase()
                    textSize = 15f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(parent.context.getColor(R.color.am_blue))
                    setPadding(18, 16, 18, 8)
                    setBackgroundColor(parent.context.getColor(R.color.am_bg))
                }
            }
            val box = android.widget.LinearLayout(parent.context).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(if (dropDown) 22 else 4, 4, 8, 4)
            }
            val icon = ImageView(parent.context).apply {
                setImageResource(iconFor(row.label))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                layoutParams = android.widget.LinearLayout.LayoutParams(40, 40).apply { marginEnd = 10 }
            }
            val label = TextView(parent.context).apply {
                text = row.label
                textSize = 18f
                setTextColor(parent.context.getColor(R.color.am_text))
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            box.addView(icon)
            box.addView(label)
            return box
        }

        override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
            instanceRow(parent, rows[position], false)

        override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
            instanceRow(parent, rows[position], true)
    }
    private fun dp(value: Int): Int = kotlin.math.round(value * resources.displayMetrics.density).toInt()

}
