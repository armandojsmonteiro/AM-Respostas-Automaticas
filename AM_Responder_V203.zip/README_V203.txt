AM Respostas Automáticas — V203

Base exclusiva: V201. A V202 foi descartada e não foi usada como base.

Alterações desta versão:
- Mantida a funcionalidade da V201 como base.
- Renderização faseada dos contactos dentro de organizações grandes: 25 contactos de cada vez, com intervalo de 5 segundos entre lotes, sem spinner nem alteração visual durante a atualização.
- Os primeiros 25 contactos são apresentados imediatamente; os restantes são acrescentados em segundo plano por lotes, evitando que a interface fique bloqueada ao abrir/fechar grupos ou mudar de menu.
- Eliminada uma causa importante de processamento excessivo: cada linha de contacto já não volta a carregar/parsing toda a base de dados para determinar o estado Incluída/Excluída.
- Reforçado o scroll interno das organizações para que o gesto dentro dos cinco contactos seja entregue ao scroll interno e não ao scroll principal de Configurações.
- Botões “Atualizar” e “＋ Pessoa” das organizações ficam compactos, lado a lado, com o mesmo estilo arredondado dos restantes botões e sem largura vazia desnecessária.
- Botões “＋ Pessoa” e “＋ Organização” do menu de Pessoas e grupos mantêm o mesmo princípio de largura justa ao texto.
- Confirmado/forçado o painel dos botões dos diálogos de confirmação para que “Cancelar” e “Apagar” apareçam dentro dos respetivos balões arredondados.
- Nenhuma rodinha/spinner ou indicação visual foi adicionada à atualização dos contactos.
