package pt.am.respostasautomaticas

import android.content.Context
import android.graphics.Color
import android.net.Uri
import kotlin.math.roundToInt

object ThemeStore {
    const val DEFAULT_BLUE_INTENSITY = 58
    data class Palette(
        val background: Int, val surface: Int, val surfaceAlt: Int, val text: Int,
        val muted: Int, val accent: Int, val line: Int, val card: Int
    )

    fun getBlueIntensity(context: Context): Int = context.getSharedPreferences("am_theme", Context.MODE_PRIVATE)
        .getInt("blue_intensity", DEFAULT_BLUE_INTENSITY).coerceIn(0, 100)

    fun setBlueIntensity(context: Context, value: Int) {
        context.getSharedPreferences("am_theme", Context.MODE_PRIVATE).edit().putInt("blue_intensity", value.coerceIn(0, 100)).apply()
    }

    fun palette(context: Context): Palette {
        val t = getBlueIntensity(context) / 100f
        val accent = blend(Color.rgb(82, 145, 226), Color.rgb(25, 104, 210), t)
        val background = blend(Color.rgb(245, 247, 250), Color.rgb(174, 218, 246), t)
        val surfaceAlt = blend(Color.rgb(240, 243, 247), Color.rgb(210, 235, 253), t)
        val line = blend(Color.rgb(225, 230, 236), Color.rgb(190, 218, 241), t)
        return Palette(background, Color.WHITE, surfaceAlt, Color.rgb(24, 48, 79), Color.rgb(97, 117, 141), accent, line, Color.WHITE)
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        fun c(x: Int, y: Int) = (x + (y - x) * t).roundToInt()
        return Color.rgb(c(Color.red(a), Color.red(b)), c(Color.green(a), Color.green(b)), c(Color.blue(a), Color.blue(b)))
    }


    /** Applies the current blue-intensity accent to blue controls without touching
     * state colours such as the green/red inclusion buttons. */
    fun applyBlueTheme(view: android.view.View, context: Context) {
        val accent = palette(context).accent
        val defaultBlue = Color.rgb(43, 124, 235)
        fun walk(v: android.view.View) {
            when (v) {
                is com.google.android.material.materialswitch.MaterialSwitch -> {
                    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf(-android.R.attr.state_checked))
                    v.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(Color.WHITE, Color.rgb(210, 214, 220)))
                    v.trackTintList = android.content.res.ColorStateList(states, intArrayOf(accent, Color.rgb(180, 186, 194)))
                }
                is com.google.android.material.button.MaterialButton -> {
                    val current = v.backgroundTintList
                    val currentColor = current?.getColorForState(intArrayOf(), Color.TRANSPARENT) ?: Color.TRANSPARENT
                    if (current == null || currentColor == defaultBlue) {
                        v.backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
                    }
                }
                is android.widget.SeekBar -> {
                    v.progressTintList = android.content.res.ColorStateList.valueOf(accent)
                    v.thumbTintList = android.content.res.ColorStateList.valueOf(accent)
                }
            }
            if (v is android.view.ViewGroup) {
                for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
        }
        walk(view)
    }

    fun setBackgroundUri(context: Context, uri: Uri?) {
        context.getSharedPreferences("am_theme", Context.MODE_PRIVATE).edit().putString("background_uri", uri?.toString()).apply()
    }

    fun getBackgroundUri(context: Context): Uri? = context.getSharedPreferences("am_theme", Context.MODE_PRIVATE)
        .getString("background_uri", null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

    fun setMenuTransparency(context: Context, transparency: Int) {
        context.getSharedPreferences("am_theme", Context.MODE_PRIVATE).edit().putInt("menu_transparency", transparency.coerceIn(0, 100)).apply()
    }

    fun getMenuTransparency(context: Context): Int = context.getSharedPreferences("am_theme", Context.MODE_PRIVATE)
        .getInt("menu_transparency", 28).coerceIn(0, 100)
}
