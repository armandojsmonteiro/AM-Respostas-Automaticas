AM Respostas Automáticas — V238
Base exclusiva: V237 aprovada e funcional.
Alteração: ajuste da tonalidade do gradiente do modo noturno, mantendo o centro do gradiente no centro do ecrã e sem alterar a fotografia ou os menus.
