AM Respostas Automáticas — V76

Base exclusiva: V70 aprovada.

Alterações desta versão:
- Texto da regra começa alinhado abaixo da zona do ícone da aplicação e ocupa o espaço até à direita, sem ficar centrado.
- Botões + Pessoas / + Grupos ficam com o conteúdo efetivamente centrado, sem alterar as dimensões dos botões.
- Ícones das aplicações ficam garantidos nas regras e aparecem também na seleção de Aplicação / Instância (WhatsApp, WhatsApp Business, Telegram, Signal, iMe, Nicegram e SMS).
- Nenhuma alteração à lógica de gravação, reposição de cópia de segurança ou restantes menus.


Alteração V76:
- Mantido exatamente o alinhamento horizontal da mensagem da V75 e subida apenas da mensagem no cartão, para ficar mais próxima da linha da aplicação, sem alterar os restantes elementos.
