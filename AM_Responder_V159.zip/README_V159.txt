AM Responder Automáticas — V159

Base obrigatória: V156 (última versão aprovada). V157 e V158 descartadas por erro de compilação.

Alteração: identificação configurável das aplicações/instâncias. Permite verificar IDs observados, preencher automaticamente os campos e guardar IDs manualmente. Os IDs configurados são usados pelo motor de correspondência e incluídos no backup/restauro.

Versão do ficheiro: 159
versionCode: 159
versionName: 159
