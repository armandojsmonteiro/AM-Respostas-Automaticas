# AM Respostas Automáticas — Android V50

Projeto Android nativo correspondente à V50.

As alterações desta versão estão descritas em `V50_ALTERACOES.txt`.


## V58 — Aplicação suportada
- imo (`com.imo.android.imoim`)
