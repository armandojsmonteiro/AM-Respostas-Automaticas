AM Respostas Automáticas — AndroidBuild V133

Base exclusiva: V132.

Alteração V133: corrigida exclusivamente a apresentação dos ícones fornecidos de Telegram e iMe, removendo o halo/contorno escuro que aparecia à volta da imagem. O desenho, cores e proporções dos símbolos foram preservados. Os ícones de WhatsApp não foram alterados. O Signal também não foi alterado.

VersionCode/versionName: 133.
