AM Respostas Automáticas — AndroidBuild V140

Base exclusiva: V136.

Alteração V140: correções exclusivamente nos ícones solicitados.
- WhatsApp Clonado: removido o fundo/aro branco exterior indevido, mantendo o símbolo e o distintivo 2.
- Nicegram: removido o halo/aro azul-cinzento exterior e melhorada a definição do ícone.
- Nicegram Trabalho: removido o halo/aro azul-cinzento exterior e melhorada a definição do ícone, mantendo o distintivo de trabalho.
- Nenhuma outra regra, ecrã, comportamento ou configuração foi alterada.

VersionCode/versionName: 140.
