AM Respostas Automáticas — V249

Base: V248.

Alteração única:
- Criado um espaçamento de 8dp entre o título "Pessoas e grupos" e o primeiro cartão de organização.
- Corrigido o espaçamento vertical entre os cartões de organizações e o balão dos botões "+ Pessoa" / "+ Organização", removendo o espaço adicional que fazia esse último ficar mais afastado.
- Mantidos todos os restantes elementos, estilos, lógica e comportamentos da V248.
