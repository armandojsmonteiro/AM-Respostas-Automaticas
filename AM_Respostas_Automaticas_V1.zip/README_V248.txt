AM Respostas Automáticas — V248

Base exclusiva: V247.

Alteração V248: ajuste visual mínimo no menu Configurações.
- Aumentado o espaçamento acima de Pessoas e grupos para manter a separação visual das secções.
- Criado um único balão/superfície para os botões + Pessoa e + Organização, mantendo os dois juntos visualmente.
- Nenhuma outra área, lógica ou comportamento foi alterado.
