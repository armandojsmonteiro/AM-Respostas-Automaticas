AM Respostas Automáticas — Versão 1

Primeira versão oficial da aplicação, baseada na V249 de desenvolvimento.

Version Name: 1
Version Code: 1

O APK gerado pelo GitHub Actions é disponibilizado como:
AM_Respostas_Automaticas_v1.apk
