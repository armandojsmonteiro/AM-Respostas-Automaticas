AM Respostas Automáticas — AndroidBuild V117

Base: V116.

Alteração visual V117: os botões + Pessoa e + Grupo mantêm exatamente as dimensões da V116 e passam a ficar alinhados pela mesma margem esquerda dos restantes botões.

Atualizações Android: o projeto passa a usar uma assinatura estável própria e versionCode 117. A V117 pode exigir uma única desinstalação se a instalação atual tiver sido assinada por uma chave diferente (por exemplo, a chave debug temporária do GitHub Actions). Depois da instalação da V117, as versões seguintes devem manter a mesma chave e incrementar o versionCode, permitindo atualizar a aplicação sem desinstalar.

O GitHub Actions deve executar diretamente `gradle :app:assembleDebug --no-daemon` a partir da raiz.
