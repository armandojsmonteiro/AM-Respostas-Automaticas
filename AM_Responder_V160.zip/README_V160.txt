AM Responder Automáticas — V160

Base: V156 funcional.

Versão interna: 160
VersionCode: 160
versionName: 160

Nota: As versões intermédias que falharam não foram usadas como base. Esta versão mantém a V156 como base e apenas alinha a identificação da versão para 160.
