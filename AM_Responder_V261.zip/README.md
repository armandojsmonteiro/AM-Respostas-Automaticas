AM Respostas Automáticas — V261

Fallback de receção ativa do NotificationListenerService e diagnóstico real da entrega de notificações.
