AM Respostas Automáticas — V261

Base: V259.

Correção do ciclo de vida do NotificationListenerService após reinício.
- A atualização/instalação nunca desativa o componente do listener.
- MY_PACKAGE_REPLACED não executa qualquer ciclo destrutivo.
- Após BOOT_COMPLETED/USER_UNLOCKED, se a autorização continuar ativa, executa-se um ciclo seguro desativar → ativar do componente e depois requestRebind().
- O componente é sempre reativado imediatamente, com DONT_KILL_APP; em caso de erro existe tentativa de restauração.
- Mantidos os três estados de diagnóstico: autorização, ligação efetiva e receção real.
- Mantidas datas e horas, UserHandle 0/128/10, regras, respostas, histórico e ícone.

VersionCode: 261
VersionName: 261
