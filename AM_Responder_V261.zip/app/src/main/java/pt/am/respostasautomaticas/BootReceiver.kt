package pt.am.respostasautomaticas

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return

        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_USER_UNLOCKED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val appContext = context.applicationContext

        if (action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "Arranque protegido detetado; recuperação adiada até o desbloqueio do utilizador."
                )
            }
            return
        }

        // Installing/updating the APK must never disable the notification-listener
        // component or alter the user's Notification Access grant.
        if (action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val authorised = isListenerAuthorised(appContext)
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "Aplicação instalada/atualizada; autorização do listener=${if (authorised) "ATIVA" else "INATIVA"}. Sem ciclo destrutivo."
                )
            }
            if (authorised) {
                runCatching { NotificationDiagnosticService.requestRebind(appContext) }
            }
            return
        }

        runCatching { DiagnosticsStore.markListenerUnconfirmedAfterBoot(appContext) }
        val authorised = isListenerAuthorised(appContext)

        if (!authorised) {
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "Arranque/desbloqueio detetado (${action}); acesso ao listener não autorizado."
                )
            }
            return
        }

        runCatching {
            DiagnosticsStore.appendTechnical(
                appContext,
                "BOOT",
                "Arranque/desbloqueio detetado (${action}); recuperação do listener agendada."
            )
        }

        val prefs = appContext.getSharedPreferences("listener_recovery", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastRecovery = prefs.getLong("last_recovery", 0L)
        if (now - lastRecovery < 120_000L) {
            runCatching {
                DiagnosticsStore.appendTechnical(
                    appContext,
                    "BOOT",
                    "Recuperação ignorada: já executada há menos de 120 segundos."
                )
            }
            return
        }
        prefs.edit().putLong("last_recovery", now).apply()

        val pending = goAsync()
        Thread {
            try {
                Thread.sleep(if (action == Intent.ACTION_USER_UNLOCKED) 3_000L else 10_000L)

                if (!isListenerAuthorised(appContext)) {
                    DiagnosticsStore.appendTechnical(
                        appContext,
                        "RECOVERY",
                        "Acesso ao listener deixou de estar autorizado antes da recuperação; operação cancelada."
                    )
                    return@Thread
                }

                // Recreate the service component without changing Notification Access.
                // V260 disabled the component and forgot to enable it again; V261
                // performs both operations immediately and requests a rebind after.
                NotificationDiagnosticService.forceComponentCycle(appContext)
                Thread.sleep(1_000L)
                NotificationDiagnosticService.requestRebind(appContext)
                Thread.sleep(3_000L)
                NotificationDiagnosticService.requestRebind(appContext)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun isListenerAuthorised(context: Context): Boolean = runCatching {
        val raw = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ).orEmpty()
        val component = ComponentName(
            context,
            NotificationDiagnosticService::class.java
        ).flattenToString()
        raw.split(":").any { it.equals(component, ignoreCase = true) }
    }.getOrDefault(false)
}
