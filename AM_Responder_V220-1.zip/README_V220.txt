AM Respostas Automáticas — V220

Base: V219 (approved working state).

Single requested change:
- In the Apagar regra? dialog, center only the title.
- Keep the message left-aligned.
- Keep the blue buttons on the right with their existing size/spacing.
- No other UI, logic, menus, or functionality changed.

V218 was discarded due to compilation errors; V219 was the corrected base.
