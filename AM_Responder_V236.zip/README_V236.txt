AM Respostas Automáticas — V236

Base: V235.

Correção da embalagem do projeto Android:
- O conteúdo do projeto Gradle passa a ficar diretamente na raiz do ZIP.
- settings.gradle.kts, build.gradle.kts e app/ ficam na raiz, conforme o workflow de compilação.
- Mantidas integralmente as alterações funcionais e visuais da V235.
- VersionCode e VersionName alinhados em 236.
