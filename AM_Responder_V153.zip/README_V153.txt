AM Responder Automáticas — V153

Base: V152.
Alteração única desta versão: aumento efetivo do ícone WhatsApp Business normal, mantendo o desenho original e removendo apenas a margem transparente exterior que fazia o símbolo parecer menor.

Não foram alterados menus, regras, lógica de respostas ou restantes ícones.
VersionName: 153
VersionCode: 147
