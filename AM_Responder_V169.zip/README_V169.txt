AM Responder — V169

Base exclusiva: V168.

Alterações:
- Diálogo Limpar fotografia de fundo com cantos arredondados, mantendo o mesmo aspeto visual do diálogo de Identificação das aplicações.
- Diálogo Limpar dados da aplicação com cantos arredondados.
- Aumentado de forma equilibrada o espaço entre o fim do texto e os botões.
- Aumentado o espaço inferior após os botões, evitando que fiquem colados ao limite do diálogo.
- Mantido o formato azul dos botões Cancelar/Limpar.
- Nenhuma alteração à lógica, regras, IDs, deteção ou restantes ecrãs.

Versão Android:
- versionCode = 169
- versionName = "169"
