# AM Responder — Android V71

Base exclusiva: V70 (última versão aprovada pelo utilizador).

## V71 — correções de posicionamento e símbolos
- Mantida a base visual da V70 sem alterar o que já foi aprovado.
- Interruptor, editar e apagar ficam numa coluna vertical única, alinhada ao extremo direito.
- Mensagem da regra começa alinhada imediatamente abaixo do símbolo da aplicação e estende-se para a direita, eliminando o espaço vazio acima da mensagem.
- Botões + Pessoa / + Grupo ficam centrados como conjunto na área de Configurações, com largura equilibrada e sem insets internos.
- Símbolos de WhatsApp, WhatsApp Business, Telegram, Signal, iMe, Nicegram e SMS continuam individualizados; os ícones dedicados foram atualizados e, para WhatsApp, WhatsApp Business, Telegram e Signal instalados no dispositivo, a aplicação tenta usar o ícone real da aplicação, mantendo fallback dedicado para variantes/clones.
- Corrigido o problema de gravação/edição: a lista usada pelo RulesAdapter deixa de ser substituída ao regressar ao ecrã, evitando que alterações guardadas desapareçam visualmente.
- Corrigido o mesmo problema após sincronização de contactos.
- Cópia de segurança atualizada para formato 3 e importação reforçada para reaplicar regras, pessoas/grupos, estado Ativo, intensidade de azul, transparência e fotografia de fundo.
- Mantida a lista de 16 Aplicações / Instâncias e toda a lógica funcional existente.

- V71 não altera a lógica de guardar/repor da V70, que fica preservada como base aprovada.
