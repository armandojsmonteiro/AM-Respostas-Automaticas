# AM Responder — Android V72

Base exclusiva: V70. A V71 foi descartada e não é usada como base.

## V72 — alinhamento do texto, mensagens e símbolos das aplicações
- Mantida integralmente a base funcional da V70, incluindo gravação/edição e guardar/repor cópia de segurança.
- Os botões + Pessoas / + Grupos ficam apenas com o conteúdo explicitamente centrado; largura e altura permanecem iguais.
- O mesmo alinhamento é reforçado nos botões Pessoas / Grupo das Configurações e no botão de adicionar pessoa dentro de grupos.
- A mensagem da regra começa alinhada pela zona esquerda do símbolo da aplicação (logo abaixo do ícone), mantendo a largura até ao extremo direito do cartão, inclusive sob a coluna dos botões.
- Mantida a identificação individual das 16 instâncias e o mapeamento de cada uma para o respetivo símbolo.
- Reforçados os símbolos específicos de WhatsApp, WhatsApp Business, Telegram, Signal, iMe e Nicegram; SMS mantém símbolo de mensagem por não ser uma marca de aplicação específica.
- Nenhuma alteração às dimensões gerais dos cartões, botões ou menus fora do solicitado.
