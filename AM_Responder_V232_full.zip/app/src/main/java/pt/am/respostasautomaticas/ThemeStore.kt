package pt.am.respostasautomaticas

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.TextView
import android.net.Uri
import kotlin.math.roundToInt

object ThemeStore {
    const val DEFAULT_BLUE_INTENSITY = 58
    private const val PREFS = "am_theme"
    data class Palette(
        val background: Int, val surface: Int, val surfaceAlt: Int, val text: Int,
        val muted: Int, val accent: Int, val line: Int, val card: Int
    )

    fun getBlueIntensity(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getInt("blue_intensity", DEFAULT_BLUE_INTENSITY).coerceIn(0, 100)

    fun setBlueIntensity(context: Context, value: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("blue_intensity", value.coerceIn(0, 100)).apply()
    }


    fun isNightMode(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getBoolean("night_mode", false)

    fun setNightMode(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("night_mode", enabled).apply()
    }

    fun applyNightBackground(view: android.view.View, context: Context) {
        if (!isNightMode(context)) {
            view.background = null
            return
        }
        // Night background: radial gradient with the lighter blue centered on the screen,
        // matching the visual direction of the AM website instead of pushing the highlight
        // towards a corner/bottom edge.
        view.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(24, 76, 155), Color.rgb(10, 34, 82), Color.rgb(3, 9, 27)
        )).apply {
            cornerRadius = 0f
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientCenterX = 0.5f
            gradientCenterY = 0.5f
            gradientRadius = 0.78f
        }
    }

    fun applyDynamicTheme(view: android.view.View, context: Context) {
        val night = isNightMode(context)
        val p = palette(context)
        fun walk(v: android.view.View) {
            if (v !is com.google.android.material.button.MaterialButton &&
                v !is com.google.android.material.materialswitch.MaterialSwitch &&
                v !is android.widget.SeekBar) {
                if (v is TextView) {
                    if (v.tag != "stateColor") v.setTextColor(p.text)
                }
                if (v is ViewGroup && (v.background is android.graphics.drawable.GradientDrawable || v.background is android.graphics.drawable.StateListDrawable)) {
                    v.background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 18f * context.resources.displayMetrics.density
                        setColor(if (night) Color.argb(150, 8, 19, 46) else p.surface)
                        if (night) setStroke((1f * context.resources.displayMetrics.density).toInt(), Color.argb(90, 92, 151, 235))
                    }
                }
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(view)
    }

    fun palette(context: Context): Palette {
        if (isNightMode(context)) {
            val t = getBlueIntensity(context) / 100f
            val accent = blend(Color.rgb(65, 130, 225), Color.rgb(40, 122, 255), t)
            return Palette(
                Color.rgb(4, 10, 30), Color.argb(190, 5, 14, 36), Color.argb(205, 8, 24, 57),
                Color.rgb(235, 243, 255), Color.rgb(165, 190, 225), accent, Color.rgb(35, 66, 112), Color.argb(175, 7, 19, 46)
            )
        }
        val t = getBlueIntensity(context) / 100f
        val accent = blend(Color.rgb(82, 145, 226), Color.rgb(25, 104, 210), t)
        val background = blend(Color.rgb(245, 247, 250), Color.rgb(174, 218, 246), t)
        val surfaceAlt = blend(Color.rgb(240, 243, 247), Color.rgb(210, 235, 253), t)
        val line = blend(Color.rgb(225, 230, 236), Color.rgb(190, 218, 241), t)
        return Palette(background, Color.WHITE, surfaceAlt, Color.rgb(24, 48, 79), Color.rgb(97, 117, 141), accent, line, Color.WHITE)
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        fun c(x: Int, y: Int) = (x + (y - x) * t).roundToInt()
        return Color.rgb(c(Color.red(a), Color.red(b)), c(Color.green(a), Color.green(b)), c(Color.blue(a), Color.blue(b)))
    }


    /** Applies the current blue-intensity accent to blue controls without touching
     * state colours such as the green/red inclusion buttons. */
    fun applyBlueTheme(view: android.view.View, context: Context) {
        val accent = palette(context).accent
        fun walk(v: android.view.View) {
            when (v) {
                is com.google.android.material.materialswitch.MaterialSwitch -> {
                    val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf(-android.R.attr.state_checked))
                    v.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(Color.WHITE, Color.rgb(210, 214, 220)))
                    v.trackTintList = android.content.res.ColorStateList(states, intArrayOf(accent, Color.rgb(180, 186, 194)))
                }
                is com.google.android.material.button.MaterialButton -> {
                    // All normal application buttons follow the blue-intensity slider.
                    // Green/red state buttons opt out with the explicit stateColor tag.
                    if (v.tag != "stateColor") {
                        v.backgroundTintList = android.content.res.ColorStateList.valueOf(accent)
                    }
                }
                is android.widget.SeekBar -> {
                    v.progressTintList = android.content.res.ColorStateList.valueOf(accent)
                    v.thumbTintList = android.content.res.ColorStateList.valueOf(accent)
                }
            }
            if (v is android.view.ViewGroup) {
                for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
        }
        walk(view)
    }

    fun setBackgroundUri(context: Context, uri: Uri?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("background_uri", uri?.toString()).apply()
    }

    fun getBackgroundUri(context: Context): Uri? = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString("background_uri", null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

    fun setMenuTransparency(context: Context, transparency: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("menu_transparency", transparency.coerceIn(0, 100)).apply()
    }

    fun getMenuTransparency(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getInt("menu_transparency", 28).coerceIn(0, 100)
}
