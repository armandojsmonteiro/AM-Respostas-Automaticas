AM Respostas Automáticas — V204

Base obrigatória: V201.
V202 e V203 ficam descartadas.

Alterações desta versão:
- Renderização dos contactos de organizações em lotes de 25, com 5 segundos entre lotes.
- O processamento visual dos contactos deixa de criar centenas de linhas de uma só vez no UI thread.
- Cada novo refresh cancela o render faseado anterior para evitar misturas/duplicações.
- Estado Incluída/Excluída é calculado uma vez por lote e passado à linha, evitando recarregar PeopleStore para cada contacto.
- Mantido o scroll interno de 5 contactos da V201.
- Botões Atualizar e + Pessoa compactos, lado a lado e com o mesmo estilo visual.
- Ajuste dos botões dos diálogos de confirmação para garantir o painel e os balões dos botões.
- Nenhuma alteração à lógica de funcionamento das regras, grupos ou background.
