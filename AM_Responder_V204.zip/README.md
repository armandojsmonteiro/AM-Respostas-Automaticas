AM Respostas Automáticas — V198

Base exclusiva: V197.

V198 é uma correção de compilação da V197. Foi corrigida a referência inválida a ScrollView.LayoutParams em ThemesActivity.kt, usando ViewGroup.LayoutParams para o contentor interno dos contactos. Todas as funcionalidades da V197 permanecem inalteradas.
