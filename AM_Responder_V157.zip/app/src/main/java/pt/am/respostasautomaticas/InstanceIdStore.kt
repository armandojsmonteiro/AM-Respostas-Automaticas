package pt.am.respostasautomaticas

import android.content.Context

/** Stores the Android UserHandle/profile ID used by each application instance. */
object InstanceIdStore {
    private const val PREFS = "am_instance_ids"
    private const val PREFIX = "id_"

    private val defaults = linkedMapOf(
        "WhatsApp" to 0,
        "WhatsApp Clonado" to 128,
        "WhatsApp Trabalho" to 10,
        "WhatsApp Business" to 0,
        "WhatsApp Business Clonado" to 128,
        "WhatsApp Business Trabalho" to 10,
        "Telegram" to 0,
        "Telegram Clonado" to 128,
        "Telegram Trabalho" to 10,
        "Signal" to 0,
        "Signal Clonado" to 128,
        "Signal Trabalho" to 10,
        "iMe" to 0,
        "iMe Trabalho" to 10,
        "Nicegram" to 0,
        "Nicegram Trabalho" to 10,
        "SMS" to 0
    )

    fun get(context: Context, instance: String): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(PREFIX + instance, defaults[instance] ?: 0)

    fun set(context: Context, instance: String, value: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(PREFIX + instance, value).apply()
    }

    fun defaults(): Map<String, Int> = defaults.toMap()

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun recordObservation(context: Context, packageName: String, userId: Int) {
        if (userId < 0) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet("observed_$packageName", observed(context, packageName) + userId.toString()).apply()
    }

    fun observed(context: Context, packageName: String): Set<Int> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet("observed_$packageName", emptySet())
            ?.mapNotNull { it.toIntOrNull() }
            ?.toSet() ?: emptySet()

    fun allObserved(context: Context): Map<String, Set<Int>> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.all.keys.filter { it.startsWith("observed_") }.associate { key ->
            key.removePrefix("observed_") to (prefs.getStringSet(key, emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()
        }
    }
}
