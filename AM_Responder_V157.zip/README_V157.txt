AM Responder Automáticas — V157

Base: V156 (versão definitiva aprovada pelo utilizador).
Alteração única: primeira implementação da Identificação das aplicações/IDs. Foi criada uma área em Configurações para configurar manualmente o UserHandle ID de cada instância, com Verificar para usar IDs observados nas notificações atuais e observações anteriores. Os IDs configurados passam a ser usados pelo motor de correspondência das regras. Os IDs também entram no backup/restauro.
Versão interna: 157
