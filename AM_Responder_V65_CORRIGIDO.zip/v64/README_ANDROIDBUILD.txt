AM Respostas Automáticas — AndroidBuild V50

Base: versão Android V49 que estava funcional.

V50 acrescenta apenas os ajustes pedidos:
- cabeçalho e navegação inferior mais compactos;
- ícones inferiores mantêm o tamanho e ficam mais próximos dos textos;
- cópia de segurança em dois botões verticais;
- pessoas escolhidas diretamente dos Contactos do Android;
- grupos com pessoas apresentadas dentro do próprio grupo;
- editar/apagar pessoas, membros e grupos;
- campos dos diálogos com margens internas corretas;
- compatibilidade com dados/backup anteriores que guardavam apenas nomes;
- barra inferior mantida em Configurações.

Para abrir no Android Studio: importar a pasta deste projeto como projeto Gradle.
