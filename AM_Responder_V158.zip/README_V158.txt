AM Responder Automáticas — V158

Base: V156 (versão definitiva aprovada). A V157 foi descartada por erro de compilação.
Alteração: Identificação das aplicações/IDs, implementada de forma isolada. Permite configurar manualmente os UserHandle IDs de cada instância, verificar IDs observados e usar os IDs configurados no motor de correspondência. Os IDs entram no backup/restauro.
Versão do ficheiro: 158
versionCode: 158
versionName: 158
