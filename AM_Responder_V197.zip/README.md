AM Respostas Automáticas — V197

Base exclusiva: V196.

Alterações desta versão:
- Diálogo de apagar regra: substituído o diálogo padrão por um diálogo compacto, centrado, com cantos arredondados e os botões Cancelar e Apagar em azul, seguindo o estilo visual da aplicação.
- Regras: todas começam fechadas. Ao tocar no nome da regra, a mensagem expande; ao tocar novamente, volta a fechar. Mensagens longas deixam de ocupar o ecrã quando a regra está fechada.
- Organizações: todas começam fechadas. Ao tocar no nome da organização, abre apenas a área dos contactos. A área tem uma janela fixa para cinco pessoas e scroll interno, mesmo que a organização tenha centenas de contactos.
- Contactos das organizações: mantida a ordenação alfabética por nome, ignorando maiúsculas/minúsculas e acentos, com telefone como critério secundário. A ordenação é aplicada também ao carregar/sincronizar os dados.
- Organizações: adicionados os três tracinhos de reordenação no cabeçalho. É possível arrastar uma organização para outra posição e a ordem fica guardada.
- Nenhuma outra área funcional foi alterada.
