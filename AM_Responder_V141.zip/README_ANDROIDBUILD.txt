AM Respostas Automáticas — AndroidBuild V141

Base exclusiva: V140.

Alteração V141: substituição dos cinco ícones que ainda apresentavam baixa definição, usando os símbolos de maior resolução fornecidos nas imagens de referência.
- Nicegram: novo símbolo em maior definição.
- Nicegram Trabalho: novo símbolo em maior definição, mantendo o distintivo de trabalho.
- Signal Clonado: novo símbolo em maior definição, mantendo o distintivo 2.
- Signal Trabalho: novo símbolo em maior definição, mantendo o distintivo de trabalho.
- SMS: novo símbolo em maior definição.
- Nenhuma outra regra, ecrã, comportamento ou configuração foi alterada.

VersionCode/versionName: 141.
