AM Respostas Automáticas — V177

Base: V176

Ponto 3 — Organizações/contactos: refinamento de inclusão/exclusão
- Contactos passam a mostrar o nome numa linha e o telefone na linha seguinte, sem separador com ponto.
- A organização passa a ter estado próprio Incluída/Excluída, com botão verde/vermelho.
- Ao criar uma organização, a aplicação pergunta se deve ficar Incluída ou Excluída.
- Organização excluída considera todos os seus contactos excluídos sem necessidade de alterar pessoa a pessoa.
- Ao reativar a organização, voltam a aplicar-se as exceções individuais guardadas.
- Mantidos os estados individuais Incluída/Excluída para exceções dentro de uma organização incluída.
- Botões editar/apagar passaram a usar os ícones vetoriais da aplicação.
- Diálogos de organização passam a usar cantos arredondados e botões azuis consistentes com o restante visual.
- O estado da organização é preservado no armazenamento e no backup.
- versionCode: 177
- versionName: 177
