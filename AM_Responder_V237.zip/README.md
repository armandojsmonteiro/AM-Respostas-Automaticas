AM Respostas Automáticas — V237
Base: V235. V236 corrigida e renomeada para V237.
