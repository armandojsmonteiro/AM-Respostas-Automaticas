# AM Responder — Android V65

Base exclusiva: V63.

Correção desta versão: a lista intocável de 16 Aplicações / Instâncias fica efetivamente refletida no seletor do diálogo Adicionar regra, incluindo iMe, iMe Trabalho, Nicegram e Nicegram Trabalho, na ordem definida. Nenhuma das outras opções foi removida ou reordenada.

Lista intocável:
1. WhatsApp
2. WhatsApp Clonado
3. WhatsApp Trabalho
4. WhatsApp Business
5. WhatsApp Business Clonado
6. Telegram
7. Telegram Clonado
8. Telegram Trabalho
9. iMe
10. iMe Trabalho
11. Nicegram
12. Nicegram Trabalho
13. Signal
14. Signal Clonado
15. Signal Trabalho
16. SMS

Inclui também a reordenação das regras por arrastar no botão ☰ e workflow GitHub Actions para gerar o APK.
