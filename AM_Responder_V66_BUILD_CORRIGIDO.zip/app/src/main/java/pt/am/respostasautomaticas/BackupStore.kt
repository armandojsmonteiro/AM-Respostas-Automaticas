package pt.am.respostasautomaticas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object BackupStore {
    fun export(context: Context): String {
        val root = JSONObject()
        root.put("format", "AM_RESPOSTAS_AUTOMATICAS_BACKUP_1")
        root.put("masterEnabled", RuleStore(context).isMasterEnabled())
        val rules = JSONArray()
        RuleStore(context).loadRules().forEach { r ->
            rules.put(JSONObject().apply {
                put("id", r.id); put("name", r.name); put("instance", r.instance); put("message", r.message)
                put("enabled", r.enabled); put("scheduleMode", r.scheduleMode); put("startTime", r.startTime); put("endTime", r.endTime)
            })
        }
        root.put("rules", rules)
        root.put("blueIntensity", ThemeStore.getBlueIntensity(context))
        root.put("menuTransparency", ThemeStore.getMenuTransparency(context))
        val peopleData = PeopleStore.load(context)
        root.put("people", peopleArray(peopleData.people))
        root.put("peopleGroups", JSONArray().apply {
            peopleData.groups.forEach { g ->
                put(JSONObject().apply { put("name", g.name); put("people", peopleArray(g.people)) })
            }
        })
        return root.toString(2)
    }

    private fun peopleArray(people: List<ContactPerson>) = JSONArray().apply {
        people.forEach { person ->
            put(JSONObject().apply {
                put("name", person.name)
                person.contactId?.let { put("contactId", it) }
                person.lookupKey?.let { put("lookupKey", it) }
                person.phone?.let { put("phone", it) }
            })
        }
    }

    private fun parsePerson(value: Any): ContactPerson {
        return if (value is JSONObject) {
            ContactPerson(
                value.optString("name"),
                value.optString("contactId").ifBlank { null },
                value.optString("lookupKey").ifBlank { null },
                value.optString("phone").ifBlank { null }
            )
        } else ContactPerson(value.toString())
    }

    fun import(context: Context, raw: String) {
        val root = JSONObject(raw)
        require(root.optString("format") == "AM_RESPOSTAS_AUTOMATICAS_BACKUP_1") { "Ficheiro de backup inválido." }

        val rules = mutableListOf<Rule>()
        val arr = root.optJSONArray("rules") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            rules += Rule(o.getLong("id"), o.getString("name"), o.getString("instance"), o.getString("message"),
                o.optBoolean("enabled", true), o.optString("scheduleMode", "always"), o.optString("startTime", "18:00"), o.optString("endTime", "08:00"))
        }
        val ruleStore = RuleStore(context)
        ruleStore.saveRules(rules)
        ruleStore.setMasterEnabled(root.optBoolean("masterEnabled", true))

        ThemeStore.setBlueIntensity(context, root.optInt("blueIntensity", ThemeStore.DEFAULT_BLUE_INTENSITY))
        ThemeStore.setMenuTransparency(context, root.optInt("menuTransparency", 28))

        val people = mutableListOf<ContactPerson>()
        val peopleArr = root.optJSONArray("people") ?: JSONArray()
        for (i in 0 until peopleArr.length()) people += parsePerson(peopleArr.get(i))
        val groups = mutableListOf<ContactGroup>()
        val groupArr = root.optJSONArray("peopleGroups") ?: JSONArray()
        for (i in 0 until groupArr.length()) {
            val o = groupArr.getJSONObject(i)
            val members = o.optJSONArray("people") ?: JSONArray()
            groups += ContactGroup(o.optString("name"), MutableList(members.length()) { j -> parsePerson(members.get(j)) })
        }
        PeopleStore.save(context, PeopleData(people, groups))
    }
}
