AM Respostas Automáticas — V224

Base obrigatória: V221. As tentativas V222 e V223 foram descartadas após testes.

Alterações:
- VersionCode = 224; versionName = "224".
- Mantida a lógica comprovada de resposta da V221, incluindo a deteção pessoa-a-pessoa que já permitia responder.
- Histórico separado do diagnóstico técnico.
- Grupos, canais e comunidades são filtrados antes de serem escritos no Histórico ou no Diagnóstico.
- Histórico contém apenas interações pessoa-a-pessoa relevantes para a aplicação.
- Diagnóstico detalha a cadeia: receção, identificação, motor, regras, horário, contacto, regra, ação de resposta, início/fim do envio e tempos.
- Cada interação recebe um Event ID e timestamps com milissegundos no diagnóstico.
- Separadores Histórico/Diagnóstico mantidos e o estilo é reaplicado depois do tema para evitar que ambos fiquem azuis.
