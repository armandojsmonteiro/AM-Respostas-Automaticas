package pt.am.respostasautomaticas

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * V224: separa o Histórico legível do Diagnóstico técnico.
 * O Histórico só recebe interações pessoa-a-pessoa depois da mesma validação
 * que protege o motor de respostas contra grupos/canais/comunidades.
 */
object DiagnosticsStore {
    private const val PREFS = "am_diagnostics"
    private const val HISTORY_KEY = "history_v224"
    private const val TECH_KEY = "technical_v224"
    private const val MAX_HISTORY = 30000
    private const val MAX_TECH = 50000

    private fun stamp(millis: Long = System.currentTimeMillis(), withMillis: Boolean = false): String {
        val pattern = if (withMillis) "HH:mm:ss.SSS" else "HH:mm:ss"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
    }

    private fun save(context: Context, key: String, text: String, max: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(key, text.take(max)).apply()
    }

    private fun prepend(context: Context, key: String, entry: String, max: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(key, "") ?: ""
        save(context, key, entry + current, max)
    }

    fun appendHistory(
        context: Context,
        appName: String,
        contact: String,
        receivedText: String,
        outcome: String,
        responseText: String? = null,
        elapsedMs: Long? = null
    ) {
        val elapsed = elapsedMs?.let { "\nTempo de processamento: ${it} ms" } ?: ""
        val entry = buildString {
            append("[${stamp()}] $appName — ${clean(contact).ifBlank { "Contacto desconhecido" }}\n")
            append("Recebida: ${clean(receivedText).ifBlank { "(sem texto)" }}\n")
            append("Resultado: $outcome")
            responseText?.takeIf { it.isNotBlank() }?.let {
                append("\nEnviada: ${clean(it)}")
            }
            append(elapsed)
            append("\n------------------------------\n")
        }
        prepend(context, HISTORY_KEY, entry, MAX_HISTORY)
    }

    fun appendTechnical(context: Context, eventId: String, message: String) {
        val entry = "[${stamp(withMillis = true)}] [$eventId] $message\n"
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(TECH_KEY, "") ?: ""
        save(context, TECH_KEY, (current + entry).takeLast(MAX_TECH), MAX_TECH)
    }

    fun get(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(HISTORY_KEY, "Ainda não existem registos no histórico.")
            ?: "Ainda não existem registos no histórico."

    fun getTechnical(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(TECH_KEY, "Ainda não existem registos de diagnóstico.")
            ?: "Ainda não existem registos de diagnóstico."

    fun clearHistory(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(HISTORY_KEY).apply()
    }

    fun clearTechnical(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(TECH_KEY).apply()
    }

    // Compatibility helper for existing callers.
    fun appendResult(context: Context, message: String) {
        appendTechnical(context, "SISTEMA", message)
    }

    private fun clean(value: String): String =
        value.replace(Regex("\\s+"), " ").trim()
}
