AM Respostas Automáticas — AndroidBuild V136

Base exclusiva: V133.

Alteração V136: corrigidos exclusivamente os fundos indevidos nos ícones de WhatsApp e WhatsApp Trabalho. No WhatsApp normal foi removido o fundo preto exterior; no WhatsApp Trabalho foi removida apenas a faixa/fundo branco exterior. O desenho, cores, proporções e dimensões dos símbolos foram preservados. Os restantes ícones não foram alterados.

VersionCode/versionName: 136.
