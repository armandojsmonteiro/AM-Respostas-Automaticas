AM Respostas Automáticas — V215

Base exclusiva: V210-1 enviado para esta correção.

Alteração única:
- Corrigido o diálogo “Apagar regra?” para garantir que os botões azuis “Cancelar” e “Apagar” sejam visíveis.
- Mantida a posição dos botões no fundo do cartão, com espaço branco inferior equivalente ao dos restantes diálogos.
- Nenhuma outra função, regra, contacto, menu, configuração ou layout foi alterado.
