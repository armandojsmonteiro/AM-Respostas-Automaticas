AM Respostas Automáticas — V215

Base exclusiva: V210-1 enviado pelo utilizador.

Correção única: garantir a apresentação dos botões “Cancelar” e “Apagar” no diálogo “Apagar regra?”, mantendo o espaçamento inferior pedido e sem alterar o restante da aplicação.
