package pt.am.respostasautomaticas

data class Rule(
    val id: Long,
    var name: String,
    var instance: String,
    var message: String,
    var enabled: Boolean = true,
    var scheduleMode: String = "always",
    var startTime: String = "18:00",
    var endTime: String = "08:00",
    var targetPeople: MutableList<String> = mutableListOf(),
    var targetGroups: MutableList<String> = mutableListOf(),
    var targetMode: String = "allow"
)
