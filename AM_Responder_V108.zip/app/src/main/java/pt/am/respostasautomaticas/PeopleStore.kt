package pt.am.respostasautomaticas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ContactPerson(
    var name: String,
    var contactId: String? = null,
    var lookupKey: String? = null,
    var phone: String? = null
)

data class ContactGroup(
    var name: String,
    val people: MutableList<ContactPerson> = mutableListOf()
)

data class PeopleData(
    val people: MutableList<ContactPerson> = mutableListOf(),
    val groups: MutableList<ContactGroup> = mutableListOf()
)

object PeopleStore {
    private const val PREFS = "am_people"
    private const val KEY = "data"

    fun load(context: Context): PeopleData {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return PeopleData()
        return runCatching {
            val root = JSONObject(raw)
            val peopleArr = root.optJSONArray("people") ?: JSONArray()
            val groupsArr = root.optJSONArray("groups") ?: JSONArray()
            val people = MutableList(peopleArr.length()) { i -> parsePerson(peopleArr.get(i)) }
            val groups = MutableList(groupsArr.length()) { i ->
                val o = groupsArr.getJSONObject(i)
                val members = o.optJSONArray("people") ?: JSONArray()
                ContactGroup(o.optString("name"), MutableList(members.length()) { j -> parsePerson(members.get(j)) })
            }
            PeopleData(people, groups)
        }.getOrElse { PeopleData() }
    }

    private fun parsePerson(value: Any): ContactPerson {
        return if (value is JSONObject) {
            ContactPerson(
                name = value.optString("name"),
                contactId = value.optString("contactId").ifBlank { null },
                lookupKey = value.optString("lookupKey").ifBlank { null },
                phone = value.optString("phone").ifBlank { null }
            )
        } else {
            // Compatibilidade com versões anteriores que guardavam apenas o nome.
            ContactPerson(value.toString())
        }
    }

    fun save(context: Context, data: PeopleData) {
        val root = JSONObject().apply {
            put("people", JSONArray().apply { data.people.forEach { put(personJson(it)) } })
            put("groups", JSONArray().apply {
                data.groups.forEach { g ->
                    put(JSONObject().apply {
                        put("name", g.name)
                        put("people", JSONArray().apply { g.people.forEach { put(personJson(it)) } })
                    })
                }
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, root.toString()).apply()
    }

    private fun personJson(person: ContactPerson): JSONObject = JSONObject().apply {
        put("name", person.name)
        person.contactId?.let { put("contactId", it) }
        person.lookupKey?.let { put("lookupKey", it) }
        person.phone?.let { put("phone", it) }
    }
}
