package pt.am.respostasautomaticas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class RuleStore(context: Context) {
    private val prefs = context.getSharedPreferences("am_reply", Context.MODE_PRIVATE)

    fun isMasterEnabled(): Boolean = prefs.getBoolean("master_enabled", true)

    fun setMasterEnabled(value: Boolean) {
        prefs.edit().putBoolean("master_enabled", value).apply()
    }

    fun loadRules(): MutableList<Rule> {
        val raw = prefs.getString("rules", null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val list = mutableListOf<Rule>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += Rule(
                o.getLong("id"),
                o.getString("name"),
                o.getString("instance"),
                o.getString("message"),
                o.optBoolean("enabled", true),
                o.optString("scheduleMode", "always"),
                o.optString("startTime", "18:00"),
                o.optString("endTime", "08:00"),
                mutableListOf<String>().apply {
                    val a = o.optJSONArray("targetPeople") ?: JSONArray()
                    for (j in 0 until a.length()) add(a.optString(j))
                },
                mutableListOf<String>().apply {
                    val a = o.optJSONArray("targetGroups") ?: JSONArray()
                    for (j in 0 until a.length()) add(a.optString(j))
                },
                o.optString("targetMode", "allow")
            )
        }
        return list
    }

    fun saveRules(rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("name", r.name)
                put("instance", r.instance)
                put("message", r.message)
                put("enabled", r.enabled)
                put("scheduleMode", r.scheduleMode)
                put("startTime", r.startTime)
                put("endTime", r.endTime)
                put("targetPeople", JSONArray(r.targetPeople))
                put("targetGroups", JSONArray(r.targetGroups))
                put("targetMode", r.targetMode)
            })
        }
        prefs.edit().putString("rules", arr.toString()).apply()
    }
}
