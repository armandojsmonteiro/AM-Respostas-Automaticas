package pt.am.respostasautomaticas

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

/** Keeps the app's selected people linked to the Android Contacts database. */
object ContactSync {
    private const val PREFS = "am_contact_sync"
    private const val KEY_LAST_SYNC = "last_sync"
    private const val INTERVAL_MS = 60_000L
    private val running = AtomicBoolean(false)

    /**
     * Runs contact synchronization away from the Android UI thread so opening
     * Rules/Settings never blocks while the phone's contacts are being read.
     */
    fun syncAsync(context: Context, force: Boolean = false, onComplete: (Int) -> Unit = {}) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            onComplete(0)
            return
        }
        if (!running.compareAndSet(false, true)) return

        val appContext = context.applicationContext
        Thread {
            val removed = runCatching { sync(appContext, force) }.getOrElse { 0 }
            running.set(false)
            Handler(Looper.getMainLooper()).post { onComplete(removed) }
        }.start()
    }

    fun sync(context: Context, force: Boolean = false): Int {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return 0
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (!force && now - prefs.getLong(KEY_LAST_SYNC, 0L) < INTERVAL_MS) return 0

        return runCatching {
            val contacts = loadContacts(context)
            val validIds = contacts.keys
            val data = PeopleStore.load(context)
            var removed = 0

            data.people.removeAll { person ->
                if (person.contactId == null) false
                else if (person.contactId !in validIds) { removed++; true }
                else { updatePerson(person, contacts[person.contactId]); false }
            }

            data.groups.forEach { group ->
                group.people.removeAll { person ->
                    if (person.contactId == null) false
                    else if (person.contactId !in validIds) { removed++; true }
                    else { updatePerson(person, contacts[person.contactId]); false }
                }
            }

            val validKeys = data.people.mapNotNull { it.contactId?.let { id -> "id:$id" } }.toMutableSet()
            data.groups.forEach { group -> group.people.forEach { it.contactId?.let { id -> validKeys += "id:$id" } } }
            val store = RuleStore(context)
            val rules = store.loadRules()
            var rulesChanged = false
            rules.forEach { rule ->
                val beforePeople = rule.targetPeople.size
                rule.targetPeople.removeAll { it.startsWith("id:") && it !in validKeys }
                if (beforePeople != rule.targetPeople.size) rulesChanged = true
            }
            if (rulesChanged) store.saveRules(rules)

            // Persist refreshed names/numbers even when no contact was removed.
            PeopleStore.save(context, data)
            prefs.edit().putLong(KEY_LAST_SYNC, now).apply()
            removed
        }.getOrElse { 0 }
    }

    private fun loadContacts(context: Context): Map<String, ContactSnapshot> {
        val result = linkedMapOf<String, ContactSnapshot>()

        // One query for contacts (instead of one phone query per contact).
        context.contentResolver.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Contacts.LOOKUP_KEY
            ),
            null, null, null
        )?.use { c ->
            val idIndex = c.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
            val nameIndex = c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)
            val lookupIndex = c.getColumnIndexOrThrow(ContactsContract.Contacts.LOOKUP_KEY)
            while (c.moveToNext()) {
                val id = c.getString(idIndex)
                val name = c.getString(nameIndex).orEmpty().ifBlank { "Contacto" }
                val lookup = c.getString(lookupIndex)
                result[id] = ContactSnapshot(name, lookup, null)
            }
        }

        // One query for all phone numbers, retaining the first number per contact.
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            val idIndex = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val numberIndex = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val id = c.getString(idIndex)
                val number = c.getString(numberIndex)
                val existing = result[id]
                if (existing != null && existing.phone == null) {
                    result[id] = existing.copy(phone = number)
                }
            }
        }
        return result
    }

    private fun updatePerson(person: ContactPerson, snapshot: ContactSnapshot?) {
        if (snapshot == null) return
        person.name = snapshot.name
        person.lookupKey = snapshot.lookupKey
        person.phone = snapshot.phone
    }

    private data class ContactSnapshot(val name: String, val lookupKey: String?, val phone: String?)
}
