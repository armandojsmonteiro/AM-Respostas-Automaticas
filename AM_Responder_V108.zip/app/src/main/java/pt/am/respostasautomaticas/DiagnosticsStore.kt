package pt.am.respostasautomaticas

import android.app.Notification
import android.content.Context
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DiagnosticsStore {
    private const val PREFS = "am_diagnostics"
    private const val KEY = "log"

    fun append(context: Context, packageName: String, userId: String, title: String, text: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(KEY, "") ?: ""
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = buildString {
            append("[$stamp]\n")
            append("Pacote: $packageName\n")
            append("User/Profile ID: $userId\n")
            append("Título: $title\n")
            append("Texto: $text\n")
            append("------------------------------\n")
        }
        val merged = (entry + current).take(30000)
        prefs.edit().putString(KEY, merged).apply()
    }

    fun appendNotificationDetails(context: Context, sbn: StatusBarNotification, notification: Notification) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(KEY, "") ?: ""
        val stamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
        val extras = notification.extras
        val actions = notification.actions.orEmpty()
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()
        val actionLines = if (actions.isEmpty()) "  - nenhuma" else actions.mapIndexed { i, a ->
            val inputs = a.remoteInputs.orEmpty().joinToString { "key=${it.resultKey ?: "?"}, freeForm=${it.allowFreeFormInput}" }
            "  - #$i título=\"${a.title ?: ""}\", semantic=${a.semanticAction}, inputs=[$inputs]"
        }.joinToString("\n")
        val entry = buildString {
            append("[$stamp] DETALHES DA NOTIFICAÇÃO\n")
            append("Chave: ${sbn.key}\n")
            append("ID: ${sbn.id}  Tag: ${sbn.tag ?: "(null)"}  PostTime: ${sbn.postTime}\n")
            append("Categoria: ${notification.category ?: "(sem categoria)"}\n")
            append("GroupKey: ${notification.group ?: "(null)"}\n")
            append("ConversationTitle: ${conversationTitle.ifEmpty { "(ausente)" }}\n")
            append("Flags: ${notification.flags}\n")
            append("Ações: ${actions.size}\n")
            append(actionLines).append("\n")
            append("Extras: ${extras.keySet().sorted().joinToString(", ")}\n")
            append("==============================\n")
        }
        prefs.edit().putString(KEY, (entry + current).take(30000)).apply()
    }

    fun appendResult(context: Context, message: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(KEY, "") ?: ""
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = "[$stamp] $message\n------------------------------\n"
        prefs.edit().putString(KEY, (entry + current).take(30000)).apply()
    }

    fun get(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "Ainda não foi recebida nenhuma notificação.") ?: ""

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }
}
