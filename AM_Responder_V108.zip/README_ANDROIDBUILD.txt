AM Respostas Automáticas — AndroidBuild V67

Base: V65 ESPAÇO E DRAG CORRIGIDO.

Projeto Gradle Android completo na raiz do ZIP. O projeto não fica dentro de uma pasta intermédia.
O GitHub Actions deve executar diretamente `gradle :app:assembleDebug --no-daemon` a partir da raiz.
