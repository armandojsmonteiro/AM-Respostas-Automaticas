AM Responder Automáticas — V154

Base: V153.

Alteração V154: ajustado o ícone do WhatsApp Business normal para um tamanho intermédio, aumentando largura e altura em relação à V152, mas sem o excesso da V153 e sem cortar o fundo do símbolo. Nenhuma outra funcionalidade foi alterada.

VersionName: 154
VersionCode: 148
