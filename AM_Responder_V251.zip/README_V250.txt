AM Respostas Automáticas — V250

Base exclusiva: V249.

Alterações funcionais:
- Diagnóstico técnico passa a registar as notificações suportadas antes dos filtros, incluindo grupo/canal/comunidade, sem as enviar para o Histórico nem para o motor de respostas.
- A deteção de UserHandle observada confirma e grava imediatamente o ID ativo. Mantidos os IDs confirmados: pessoal 0, clonado 128 e trabalho 10.
- O botão Procurar em Identificação das aplicações passa a persistir automaticamente os IDs detetados.
- O motor de regras aceita o ID configurado e, como segurança, também a correspondência dos IDs conhecidos das instâncias.
- Reforçada a deteção de notificações da própria conta no WhatsApp, incluindo casos em que a identidade MessagingStyle está disponível sem android.selfDisplayName.
- O cooldown do WhatsApp só é reservado depois de existir uma ação de resposta válida.
- Falhas do RemoteInput passam a ficar registadas com o tipo de exceção e mensagem técnica.
- Histórico/Diagnóstico visível no ecrã passa a atualizar automaticamente enquanto estiver aberto.
- Package/applicationId, interface, regras e restante estrutura mantidos.

VersionCode: 250
VersionName: 250
