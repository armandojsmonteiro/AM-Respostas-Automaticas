AM Respostas Automáticas — V251

Base: V250

Correções nesta versão:
- Corrigido erro de compilação Kotlin em NotificationDiagnosticService.kt na função detectedInstanceForPackage.
- Mantida a identificação dos perfis Android: 0 pessoal, 128 clonado, 10 trabalho.
- Mantidas as correções de diagnóstico, identificação de instâncias e MessagingStyle introduzidas na V250.
- Novo ícone da aplicação AM Respostas Automáticas aplicado em drawable/ic_app.png.
- applicationId/package mantido: pt.am.respostasautomaticas.
- versionCode: 251
- versionName: 251
