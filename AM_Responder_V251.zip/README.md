AM Respostas Automáticas — V250

Base: V249.

Correções funcionais: diagnóstico em tempo real, confirmação automática dos UserHandles observados, resolução robusta das instâncias 0/128/10, filtragem técnica de grupos/canais sem os processar, proteção reforçada contra respostas às próprias mensagens do WhatsApp e registo detalhado de falhas do RemoteInput.

Version Code: 250
Version Name: 250
