AM Respostas Automáticas — AndroidBuild V250

Base: V249.

Build local/GitHub Actions:
- Projeto Android na raiz, com Gradle 8.9 e Java 17.
- Comando: gradle :app:assembleDebug --no-daemon
- APK esperado: app/build/outputs/apk/debug/app-debug.apk
- Workflow renomeia o APK para AM_Respostas_Automaticas_v250.apk.

VersionCode: 250 · VersionName: 250
