AM Respostas Automáticas — V238

Base exclusiva: V237 aprovada e funcional.

Alteração:
- Ajustado exclusivamente o gradiente de fundo do modo noturno.
- O azul central foi escurecido para aproximar a tonalidade do azul profundo usado no site AM Inovação & Tecnologia.
- Mantido o centro do gradiente no centro do ecrã.
- Mantidos os menus, transparência, fotografia de fundo e restantes comportamentos da V237 sem alterações.
- VersionCode e VersionName alinhados em 238.
