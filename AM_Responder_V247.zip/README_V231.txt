AM Respostas Automáticas — V231

Base: V230

Alterações:
- Implementado Tema noturno com interruptor ON/OFF na secção Temas das Configurações.
- Tema noturno usa fundo azul escuro em gradiente, inspirado na identidade visual azul escura do site de referência.
- Superfícies, cartões, textos, botões, separadores e navegação adaptam-se ao modo noturno.
- O modo noturno é persistente através de SharedPreferences.
- O fundo fotográfico personalizado deixa de ser usado enquanto o tema noturno está ativo; ao desligar, volta a ser respeitado.
- Mantidos monitorização, histórico, filtro pessoa-a-pessoa e restante funcionamento da V230.
- VersionCode e VersionName alinhados em 231.
