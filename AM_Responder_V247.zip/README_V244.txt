AM Respostas Automáticas — V244

Base exclusiva: V243.

Correções de layout, sem alteração de funcionalidades:
- Regras: criado espaço superior no cabeçalho; o primeiro cartão de regra mantém a posição anterior, evitando perder espaço em cima para ganhar em baixo.
- Histórico: o título Histórico passa a ficar na mesma linha do botão Limpar, no topo do conteúdo, recuperando a posição visual pretendida e eliminando o espaço excessivo entre o cabeçalho e os controlos.
- Barra inferior: mantida a mesma estrutura/dimensões dos três itens, sem alteração da lógica de navegação.
- Nenhuma alteração a Configurações, regras, histórico, diagnóstico, gradiente, transparência, fotografia de fundo ou lógica funcional.
- VersionCode e VersionName alinhados em 244.
