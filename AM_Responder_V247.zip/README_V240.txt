AM Respostas Automáticas — V240

Base exclusiva: V238.

Correção:
- Restaurado o gradiente radial real do tema noturno, que tinha deixado de aparecer na V238/V239.
- O azul mais luminoso fica centrado no meio do ecrã, com uma tonalidade azul profunda, aproximada do visual pretendido para o site AM.
- O gradiente é aplicado aos três menus: Regras, Histórico e Configurações.
- A fotografia de fundo continua independente do tema noturno e não é escurecida nem alterada.
- A transparência continua a afetar apenas as superfícies/menus.
- VersionCode e VersionName alinhados em 240.
