AM Respostas Automáticas — V243

Base: versão funcional imediatamente anterior aprovada.

Correção única:
- Barra de navegação inferior do ecrã Configurações alinhada exatamente com Regras e Histórico.
- Itens da barra passam de 64dp para 60dp, igual ao ecrã principal.
- Espaçamento dos ícones ajustado de -5dp para -8dp, igual ao ecrã principal.
- Regras, Histórico e Configurações ficam com a mesma altura, alinhamento e dimensão visual.
- Nenhuma outra funcionalidade, menu, configuração, fundo, gradiente, transparência ou lógica foi alterada.
- VersionCode e VersionName alinhados em 243.
