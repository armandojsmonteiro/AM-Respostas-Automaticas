AM Respostas Automáticas — V232

Base: V231.

Alterações:
- Tema noturno aplicado também ao ecrã principal, incluindo Regras e Histórico.
- Gradiente noturno alterado para radial, com o azul mais luminoso centrado no meio do ecrã.
- Mantida a navegação, monitorização, histórico e filtro de grupos da V231.
- VersionCode e VersionName alinhados em 232.
