AM Respostas Automáticas — V245

Base exclusiva: V244.

Correção mínima e isolada da barra inferior do menu Configurações:
- A barra inferior de Configurações passa a usar exatamente a mesma geometria da barra inferior de Regras/Histórico.
- Mesma altura (62dp), padding horizontal (7dp), itens com largura ponderada, altura (60dp), padding zero, alinhamento e fundo transparente.
- O objetivo é manter Regras, Histórico e Configurações exatamente nas mesmas posições e impedir o afastamento lateral observado apenas em Configurações.
- Nenhuma outra área, funcionalidade, cor, gradiente, regras, histórico, diagnóstico ou conteúdo foi alterada.
- VersionCode e VersionName: 245.
