AM Respostas Automáticas — V229

Base: V228

Alterações:
- Botão Limpar histórico/diagnóstico movido para a linha superior, alinhado à direita e com a mesma largura visual do botão Diagnóstico.
- Mantida a navegação e o visual aprovados da V228.
- Melhorada a extração do texto das notificações: além de EXTRA_TEXT, a aplicação tenta EXTRA_BIG_TEXT, EXTRA_TEXT_LINES e a última mensagem de MessagingStyle.
- Esta melhoria permite recuperar o texto real em instâncias/clones de WhatsApp que não disponibilizam EXTRA_TEXT.
- Mantida a separação entre mensagens recebidas e enviadas.
- VersionCode e VersionName alinhados em 229.
