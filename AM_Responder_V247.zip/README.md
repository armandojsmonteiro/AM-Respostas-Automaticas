AM Respostas Automáticas — V240

Versão 240: correção definitiva do fundo gradiente do modo noturno.
