AM Respostas Automáticas — V235

Base: V234.

Alterações:
- Corrigida a aplicação do tema noturno para não substituir o gradiente centrado do fundo.
- O gradiente azul noturno fica centrado no meio do ecrã nos menus principais e em Configurações quando não existe fotografia.
- A fotografia de fundo fica intacta no modo noturno: sem camada preta/escurecimento sobre a imagem.
- A transparência dos menus passa a controlar também os cartões/caixas de Configurações, mantendo o fundo independente desse ajuste.
- A transparência das superfícies é aplicada de forma consistente ao tema claro e ao tema noturno.
- Mantida a funcionalidade existente da V234.
- VersionCode e VersionName alinhados em 235.
