AM Respostas Automáticas — V230

Base: V229

Alterações:
- Botão de limpeza passa a apresentar apenas "Limpar", evitando quebra de linha e mantendo o botão compacto/alinhado.
- Mantida a confirmação contextual: histórico ou diagnóstico conforme o separador ativo.
- Filtragem reforçada de grupos/canais/comunidades antes de qualquer registo técnico.
- Usa o indicador Android EXTRA_IS_GROUP_CONVERSATION quando disponível.
- Usa também EXTRA_CONVERSATION_TITLE e, em MessagingStyle, a identidade do remetente para detetar grupos quando algumas instâncias do WhatsApp não fornecem o indicador explícito.
- Conversas pessoa-a-pessoa continuam a ser processadas normalmente.
- Histórico permanece exclusivamente pessoa-a-pessoa.
- VersionCode e VersionName alinhados em 230.
