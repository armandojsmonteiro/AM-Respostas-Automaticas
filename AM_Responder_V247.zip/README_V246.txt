AM Respostas Automáticas — V246

Base: V245.
Alteração única: no modo diurno, a faixa de fundo do cabeçalho da secção (Regras) passa a ser transparente, ficando visualmente consistente com o modo noturno. Nenhuma outra área foi alterada.
