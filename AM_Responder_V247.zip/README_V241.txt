AM Respostas Automáticas — V241

Base exclusiva: V240.

Correção:
- Mantido todo o funcionamento da V240.
- Ajustada apenas a tonalidade do gradiente radial do tema noturno.
- O gradiente passa a usar um azul profundo e discreto, alinhado visualmente com o azul escuro do site AM Inovação & Tecnologia.
- Removido o azul demasiado claro/vivo que estava a dominar o centro do fundo.
- Mantida a fotografia de fundo independente do tema noturno, sem aplicação de camada escura sobre a fotografia.
- Mantida a transparência dos menus/cartões.
- VersionCode e VersionName alinhados em 241.
