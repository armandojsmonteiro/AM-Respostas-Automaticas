AM Respostas Automáticas — V247

Base exclusiva: V246.

Correção única e isolada em Configurações:
- Ao clicar em Atualizar numa Organização, o cartão da organização mantém a superfície translúcida sobre a fotografia de fundo.
- O refresh da lista reaplica o tema visual aos elementos criados dinamicamente, sem alterar a fotografia, posições, menus, regras, histórico ou diagnóstico.
- A lógica de pesquisa da organização e os dados encontrados/adicionados não foram alterados.

VersionCode e VersionName: 247.
