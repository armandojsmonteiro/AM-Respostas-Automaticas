package pt.am.respostasautomaticas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_USER_UNLOCKED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val appContext = context.applicationContext

        // Never carry the pre-reboot green state into the new boot session.
        // The listener must prove its connection again through onListenerConnected().
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_USER_UNLOCKED) {
            runCatching { DiagnosticsStore.markListenerUnconfirmedAfterBoot(appContext) }
        }

        runCatching {
            DiagnosticsStore.appendTechnical(
                appContext,
                "BOOT",
                "Arranque/desbloqueio detetado (${action}); a forçar recuperação do listener."
            )
        }

        // The previous implementation called requestRebind() directly. Android's
        // official recovery path is unbind -> rebind. V259 uses that sequence and
        // repeats the rebind shortly after boot/unlock to handle HONOR/MagicOS
        // restoring the component without restoring notification delivery.
        NotificationDiagnosticService.recoverBinding(appContext)

        val pending = goAsync()
        Thread {
            try {
                val delays = longArrayOf(8_000L, 15_000L, 30_000L)
                for (delay in delays) {
                    Thread.sleep(delay)
                    NotificationDiagnosticService.requestRebind(appContext)
                    runCatching {
                        DiagnosticsStore.appendTechnical(
                            appContext,
                            "BOOT",
                            "Tentativa adicional de reconexão (${delay / 1000}s após o evento de arranque)."
                        )
                    }
                }
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                pending.finish()
            }
        }.start()
    }
}
