AM Respostas Automáticas V252

Base: V251.
Alteração desta versão: novo ícone AM Respostas Automáticas, alinhado visualmente com o ecossistema AM.
UserHandles mantidos: 0 pessoal, 128 clonado, 10 trabalho.
ApplicationId mantido: pt.am.respostasautomaticas.
