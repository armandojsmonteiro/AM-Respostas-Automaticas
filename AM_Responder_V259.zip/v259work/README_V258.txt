AM Respostas Automáticas — V258

Base: V255/V257 recovery line, preserving existing responder behavior.

Alterações desta versão:
- Correção do estado do NotificationListenerService: serviço só fica ATIVO após onListenerConnected().
- Heartbeat interno a cada 30 segundos para distinguir autorização de serviço realmente vivo.
- Rebind reforçado após BOOT_COMPLETED, USER_UNLOCKED e MY_PACKAGE_REPLACED, com novas tentativas após o arranque.
- onListenerDisconnected() regista a desconexão e pede reconexão.
- Diagnóstico e estado do serviço usam data/hora/segundos, sem milissegundos.
- Diagnóstico mostra a última notificação recebida.
- Mantidos UserHandle 0, 128 e 10.
- Mantidas as respostas automáticas e a gravação manual dos IDs.
- Mantido o ícone atual.

VersionCode: 258
VersionName: 258
