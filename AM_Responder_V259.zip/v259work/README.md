AM Respostas Automáticas — V259

Fallback de receção ativa do NotificationListenerService e diagnóstico real da entrega de notificações.
