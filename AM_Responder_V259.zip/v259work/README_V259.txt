AM Respostas Automáticas — V259

Base: V258.

Objetivo desta versão: corrigir a recuperação do NotificationListenerService após reinício do telefone, sem alterar o motor das respostas automáticas.

Alterações:
- O estado do listener deixa de usar o heartbeat interno como prova de funcionamento.
- Autorização, ligação ao Notification Manager e receção efetiva de notificações passam a ser estados distintos no diagnóstico.
- O heartbeat só é atualizado quando existe uma notificação efetivamente entregue ao onNotificationPosted().
- O estado é reiniciado para NÃO confirmado no arranque, evitando o falso verde herdado antes do reboot.
- Recuperação de binding reforçada após BOOT_COMPLETED, LOCKED_BOOT_COMPLETED, USER_UNLOCKED e MY_PACKAGE_REPLACED.
- Em Android 14+ é usado requestUnbind() seguido de requestRebind(), respeitando o mecanismo oficial de recuperação do NotificationListenerService.
- A recuperação também pode ser acionada quando a aplicação volta a abrir e o listener ainda não está confirmado.
- onNotificationPosted() fica protegido contra exceções inesperadas, para evitar que um erro numa notificação interrompa o processamento do listener.
- Diagnóstico mantém data, hora e segundos, sem milissegundos.
- Mantidas as regras, respostas, UserHandle 0/128/10 e comportamento existente.

VersionCode: 259
VersionName: 259
