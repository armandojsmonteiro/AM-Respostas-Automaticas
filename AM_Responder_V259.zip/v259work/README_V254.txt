AM Respostas Automáticas — V254

Base: V253.
Alteração desta versão: substituição do ícone da aplicação pelo novo ícone AM com aro luminoso e brilho de cantos mais discreto, mantendo o restante do projeto inalterado.

applicationId: pt.am.respostasautomaticas
versionCode: 254
versionName: 254
