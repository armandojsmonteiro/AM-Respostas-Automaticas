AM Respostas Automáticas — V256

Objetivo: corrigir a recuperação do NotificationListenerService após reinício do Android e tornar o diagnóstico inequívoco.

Alterações:
- Mantida a lógica existente de respostas, IDs 0/128/10, leitura/gravação manual e histórico.
- Adicionado BootReceiver para pedir rebind do NotificationListenerService após BOOT_COMPLETED e MY_PACKAGE_REPLACED.
- Mantido requestRebind quando o sistema chama onListenerDisconnected().
- Registado o estado real do serviço através de onCreate/onListenerConnected/onListenerDisconnected/onDestroy.
- Diagnóstico separa autorização do listener e serviço efetivamente ligado.
- Registos passam a incluir data, hora e milissegundos.
- Mostra o último estado conhecido do serviço.
- Não altera a lógica de resposta automática.

Nota: o projeto foi preparado para o workflow GitHub Actions existente. O ambiente de análise não possui Gradle/Android SDK instalado, portanto o APK deve ser validado pelo workflow de build do projeto.
