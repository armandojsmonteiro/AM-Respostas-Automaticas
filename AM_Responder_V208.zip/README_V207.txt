V207 — correções visuais finais

Base: V206.

Alterações:
- Alinhados os botões "Atualizar" e "+ Pessoa" das organizações com o alinhamento dos restantes botões do menu Configurações.
- Corrigido o diálogo "Apagar regra?" para garantir que os botões "Cancelar" e "Apagar" ficam visíveis e apresentados como botões azuis arredondados.
- Não foi alterada a lógica da atualização de contactos nem qualquer outra funcionalidade.
