AM Respostas Automáticas — V208

Base: V207 (V206 permanece a versão funcional aprovada para a lógica de atualização de contactos).

Alteração desta versão:
- Corrigido apenas o alinhamento horizontal dos botões "Atualizar" e "+ Pessoa" dentro da organização, removendo o deslocamento lateral adicional de 12dp.
- Mantida toda a lógica de atualização de contactos, incluindo a atualização faseada.
- Mantidos os diálogos de confirmação/apagar já corrigidos na V207.
- Nenhuma outra área da aplicação foi alterada.
