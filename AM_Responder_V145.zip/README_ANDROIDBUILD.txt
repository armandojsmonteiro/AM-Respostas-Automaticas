AM Respostas Automáticas — AndroidBuild V144

Base exclusiva: V141.

Alteração V144: correções visuais mínimas nos ícones das regras, sem alterar outras regras, ecrãs, comportamentos ou configurações.
- Nicegram normal: aumentado muito ligeiramente.
- Signal Clonado: ligeiramente alargado na horizontal e deslocado um pouco para a direita.
- Signal Trabalho: ligeiramente alargado na horizontal e deslocado um pouco para a direita.
- O ajuste anterior do iMe permanece inalterado.

VersionCode/versionName: 142.
