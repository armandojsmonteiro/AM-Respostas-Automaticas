# AM Responder — Android V112

Base exclusiva: V69 (última versão visualmente aprovada pelo utilizador).

## V70 — correções finais de visualização e persistência
- Nome da aplicação/instância ligeiramente aumentado.
- Interruptor, editar e apagar ficam numa coluna vertical única, alinhada ao extremo direito.
- Mensagem da regra sai da coluna central e passa a ocupar toda a largura abaixo da linha superior, começando imediatamente sob a zona do ícone.
- Botões + Pessoa / + Grupo ficam com texto explicitamente centrado, incluindo remoção dos insets internos do MaterialButton.
- Símbolos de WhatsApp, WhatsApp Business, Telegram, Signal, iMe, Nicegram e SMS mantêm recursos individuais; o Signal foi redesenhado para corresponder ao símbolo de balão oficial e as restantes variantes continuam separadas por aplicação.
- Corrigido o problema de gravação/edição: a lista usada pelo RulesAdapter deixa de ser substituída ao regressar ao ecrã, evitando que alterações guardadas desapareçam visualmente.
- Corrigido o mesmo problema após sincronização de contactos.
- Cópia de segurança atualizada para formato 3 e importação reforçada para reaplicar regras, pessoas/grupos, estado Ativo, intensidade de azul, transparência e fotografia de fundo.
- Mantida a lista de 16 Aplicações / Instâncias e toda a lógica funcional existente.


V102: baseada exclusivamente na V101. Única alteração: limitar a largura horizontal de tvMessage para que o texto termine antes dos botões, mantendo a posição vertical e a posição à esquerda da V101.


V104: baseada exclusivamente na V103. Única alteração: aproximar a quebra automática de linha da direita, reduzindo a margem direita de tvMessage, sem alterar a posição vertical nem a posição à esquerda do texto.


V106: baseada exclusivamente na V105. Duas microcorreções visuais na mensagem: aumentar ligeiramente a margem direita para garantir que nenhuma letra toque nos botões e reduzir o espaço vazio inferior da mensagem, sem alterar a posição esquerda, a posição vertical, o tamanho do texto ou os botões.


V108: baseada exclusivamente na V107. Única alteração: aumentar apenas mais 4dp a margem direita de tvMessage, fazendo a quebra de linha terminar ligeiramente mais à esquerda para manter o texto afastado dos botões. Nenhuma posição, tamanho, botão ou outro elemento foi alterado.

V111: baseada exclusivamente na V110. Única alteração: deslocar ligeiramente para a esquerda apenas o texto interno dos botões + Pessoa e + Grupo no menu Configurações, mantendo os botões exatamente na mesma posição, tamanho e alinhamento. Nenhum outro elemento foi alterado.


V112: baseada exclusivamente na V111. Nova opção em Configurações > Base de dados: “Limpar dados da aplicação”. Pede confirmação e limpa regras, pessoas/grupos, configurações visuais, fotografia de fundo, diagnóstico/sincronização e ficheiros privados da aplicação, deixando os dados como numa instalação nova. Cópias de segurança guardadas fora da aplicação não são apagadas.

V113: baseada exclusivamente na V112. Ajuste visual apenas em Configurações: os botões Pessoas/Grupos, Escolher imagem/Limpar e Base de dados passam a ficar alinhados à esquerda e com largura determinada pelo conteúdo, evitando blocos azuis desnecessariamente largos. O botão Limpar da fotografia de fundo passa a pedir confirmação. As confirmações de Limpar fotografia de fundo e Limpar dados da aplicação passam a apresentar claramente os botões Cancelar e a ação, em botões azuis arredondados com texto branco. Nenhuma outra área ou funcionalidade foi alterada.


V114: ajuste exclusivo das margens laterais da área Pessoas e grupos. Base: V113.
