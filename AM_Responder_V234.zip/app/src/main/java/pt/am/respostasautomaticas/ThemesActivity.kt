package pt.am.respostasautomaticas

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class ThemesActivity : AppCompatActivity() {
    private lateinit var preview: ImageView
    private lateinit var background: ImageView
    private lateinit var backgroundTint: View
    private lateinit var root: View
    private lateinit var header: View
    private lateinit var bottomNav: View
    private lateinit var blueSeek: SeekBar
    private lateinit var transparencySeek: SeekBar
    private lateinit var blueValue: TextView
    private lateinit var transparencyValue: TextView
    private lateinit var peopleList: LinearLayout

    private var pendingGroupName: String? = null
    private var pendingContactRequest = false
    private val expandedGroups = mutableSetOf<String>()
    private var draggingGroupName: String? = null
    private var draggingGroupStartRawY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_themes)
        root = findViewById(R.id.settingsContentRoot)
        header = findViewById(R.id.settingsHeader)
        bottomNav = findViewById(R.id.settingsBottomNav)
        preview = findViewById(R.id.imgPreviewBackground)
        background = findViewById(R.id.settingsBackground)
        backgroundTint = findViewById(R.id.settingsBackgroundTint)
        blueSeek = findViewById(R.id.seekBlue)
        transparencySeek = findViewById(R.id.seekTransparency)
        blueValue = findViewById(R.id.tvBlueValue)
        transparencyValue = findViewById(R.id.tvTransparencyValue)
        peopleList = findViewById(R.id.peopleList)

        val nightSwitch = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.switchNightMode)
        nightSwitch.isChecked = ThemeStore.isNightMode(this)
        nightSwitch.setOnCheckedChangeListener { _, checked ->
            ThemeStore.setNightMode(this, checked)
            refreshVisuals()
        }

        val master = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.settingsMaster)
        val status = findViewById<TextView>(R.id.settingsStatus)
        setupApplicationIdsButton()
        val ruleStore = RuleStore(this)
        ThemeStore.applyBlueTheme(master, this)
        master.isChecked = ruleStore.isMasterEnabled()
        status.text = if (master.isChecked) "Ativo" else "Desativado"
        master.setOnCheckedChangeListener { _, checked -> ruleStore.setMasterEnabled(checked); status.text = if (checked) "Ativo" else "Desativado" }

        blueSeek.max = 100
        blueSeek.progress = ThemeStore.getBlueIntensity(this)
        transparencySeek.max = 100
        transparencySeek.progress = ThemeStore.getMenuTransparency(this)

        blueSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                ThemeStore.setBlueIntensity(this@ThemesActivity, progress)
                blueValue.text = "$progress%"
                refreshVisuals()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        transparencySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                ThemeStore.setMenuTransparency(this@ThemesActivity, progress)
                transparencyValue.text = "$progress%"
                refreshVisuals()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        findViewById<MaterialButton>(R.id.btnChooseBackground).setOnClickListener { chooseBackground() }
        findViewById<MaterialButton>(R.id.btnClearBackground).setOnClickListener { confirmClearBackground() }
        findViewById<MaterialButton>(R.id.btnAddPerson).setOnClickListener { startContactSelection(null) }
        findViewById<MaterialButton>(R.id.btnAddGroup).setOnClickListener { addGroup() }
        findViewById<MaterialButton>(R.id.btnBackup).setOnClickListener { backup() }
        findViewById<MaterialButton>(R.id.btnRestore).setOnClickListener { restore() }
        findViewById<MaterialButton>(R.id.btnClearAppData).setOnClickListener { confirmClearAppData() }
        findViewById<MaterialButton>(R.id.btnNotificationAccess).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }

        findViewById<TextView>(R.id.navRulesSettings).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("screen", "rules"))
            overridePendingTransition(0, 0)
            finish()
            overridePendingTransition(0, 0)
        }
        findViewById<TextView>(R.id.navHistorySettings).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("screen", "history"))
            overridePendingTransition(0, 0)
            finish()
            overridePendingTransition(0, 0)
        }
        findViewById<TextView>(R.id.navSettingsSettings).setOnClickListener {
            setSettingsNavSelected(R.id.navSettingsSettings)
        }

        syncContactsAndRefresh(refreshList = true)
        refreshVisuals()
        setSettingsNavSelected(R.id.navSettingsSettings)
    }

    override fun onResume() {
        super.onResume()
        // Do not rebuild the whole people view merely because the Activity resumed.
        // ContactSync runs in the background and only asks for a redraw when data changed.
        syncContactsAndRefresh(refreshList = false)
        refreshVisuals()
    }

    private fun setupApplicationIdsButton() {
        val settingsRoot = findViewById<LinearLayout>(R.id.themesRoot)
        if (settingsRoot.findViewWithTag<View>("application_ids_button") != null) return
        val button = MaterialButton(this)
        button.tag = "application_ids_button"
        button.text = "Identificação das aplicações / IDs"
        button.setAllCaps(false)
        button.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dp(46)
        ).apply { topMargin = dp(8) }
        button.setPadding(dp(18), 0, dp(18), 0)
        button.minWidth = 0
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(ThemeStore.palette(this).accent)
        button.cornerRadius = dp(14)
        button.setOnClickListener { showApplicationIdsDialog() }
        settingsRoot.addView(button, 1)
    }

    private fun showApplicationIdsDialog() {
        val palette = ThemeStore.palette(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
        }
        val fields = linkedMapOf<String, EditText>()
        val initialValues = linkedMapOf<String, Int>()

        fun idCircleBackground(color: Int): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(color)
            }

        fun applyIdStyle(edit: EditText, color: Int) {
            edit.background = idCircleBackground(color)
            edit.setTextColor(Color.WHITE)
            edit.textSize = 16f
            edit.gravity = Gravity.CENTER
            edit.setPadding(0, 0, 0, 0)
        }

        AppIdsStore.instances.forEach { name ->
            val current = AppIdsStore.get(this, name)
            initialValues[name] = current

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(palette.text)
                setPadding(dp(2), 0, dp(8), 0)
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(56), 1f))

            val edit = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(current.toString())
                setSelectAllOnFocus(true)
                setSingleLine(true)
                gravity = Gravity.CENTER
                background = idCircleBackground(palette.accent)
                setTextColor(Color.WHITE)
                textSize = 16f
                setPadding(0, 0, 0, 0)
            }
            row.addView(edit, LinearLayout.LayoutParams(dp(52), dp(52)).apply {
                marginStart = dp(8)
                marginEnd = dp(2)
            })
            container.addView(row)
            fields[name] = edit
        }

        val scroll = ScrollView(this).apply {
            addView(container)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(360)
            )
        }

        val status = TextView(this).apply {
            text = "IDs encontrados: 0"
            textSize = 14f
            setTextColor(palette.muted)
            setPadding(dp(18), dp(8), dp(18), dp(4))
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(18))
        }

        fun dialogButton(text: String): MaterialButton = MaterialButton(this).apply {
            this.text = text
            setAllCaps(false)
            minWidth = 0
            minimumWidth = 0
            minHeight = dp(42)
            minimumHeight = dp(42)
            cornerRadius = dp(14)
            setPadding(dp(8), 0, dp(8), 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(palette.accent)
            setTextColor(Color.WHITE)
            textSize = 14f
        }

        val cancelButton = dialogButton("Cancelar")
        // Keep the middle button on one line by using the shorter label requested.
        val searchButton = dialogButton("Procurar")
        val saveButton = dialogButton("Guardar")
        buttons.addView(cancelButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(2); marginEnd = dp(3)
        })
        buttons.addView(searchButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(3); marginEnd = dp(3)
        })
        buttons.addView(saveButton, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(3); marginEnd = dp(2)
        })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(scroll)
            addView(status)
            addView(buttons)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Identificação das aplicações")
            .setMessage("Confirma os IDs detetados automaticamente ou altera-os manualmente. Usa Procurar para fazer uma nova deteção.")
            .setView(content)
            .create()

        cancelButton.setOnClickListener { dialog.dismiss() }
        searchButton.setOnClickListener {
            status.text = "A procurar nas notificações ativas…"
            NotificationDiagnosticService.scanCurrentNotifications()
            window.decorView.postDelayed({
                val found = mutableListOf<String>()
                fields.forEach { (name, edit) ->
                    AppIdsStore.observed(this, name)?.let { observedId ->
                        val oldValue = initialValues[name] ?: AppIdsStore.get(this, name)
                        edit.setText(observedId.toString())
                        // Green means an ID is confirmed by an observed notification.
                        // Blue means the search found a new/different ID for this app.
                        val color = if (observedId != oldValue) palette.accent else Color.rgb(22, 163, 74)
                        applyIdStyle(edit, color)
                        found.add("$name = $observedId")
                    }
                }
                status.text = if (found.isNotEmpty()) {
                    "Encontrados: ${found.joinToString(" • ")}"
                } else {
                    "IDs encontrados: 0 — abre as aplicações e deixa uma notificação visível, depois procura novamente."
                }
            }, 350)
        }
        saveButton.setOnClickListener {
            fields.forEach { (name, edit) ->
                edit.text.toString().toIntOrNull()?.let { if (it >= 0) AppIdsStore.set(this, name, it) }
            }
            dialog.dismiss()
            Toast.makeText(this, "IDs das aplicações guardados.", Toast.LENGTH_SHORT).show()
        }

        dialog.setOnShowListener {
            dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.let { title ->
                title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f)
                title.setTypeface(null, android.graphics.Typeface.BOLD)
                title.maxLines = 1
                title.setSingleLine(true)
                title.ellipsize = null
                title.gravity = Gravity.CENTER_VERTICAL
                title.setPadding(dp(14), dp(12), dp(14), dp(6))
            }
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.94f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            dialog.window?.decorView?.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                setColor(Color.WHITE)
                cornerRadius = dp(22).toFloat()
            }
            styleDialogTitleAndSpacing(dialog)
        }
        dialog.show()
    }

    private fun syncContactsAndRefresh(refreshList: Boolean) {
        if (refreshList) refreshPeople()
        ContactSync.syncAsync(this, force = false) { result ->
            if (!isFinishing && !isDestroyed && result.changed > 0) {
                refreshPeople()
                if (result.removed > 0) {
                    Toast.makeText(this, "${result.removed} contacto(s) removido(s) porque já não existem nos Contactos.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun refreshVisuals() {
        val p = ThemeStore.palette(this)
        ThemeStore.applyBlueTheme(root, this)
        ThemeStore.applyDynamicTheme(root, this)
        val alpha = (255f * (1f - ThemeStore.getMenuTransparency(this) / 100f)).toInt().coerceIn(0, 255)
        root.setBackgroundColor(Color.argb(alpha, Color.red(p.surface), Color.green(p.surface), Color.blue(p.surface)))
        ThemeStore.applyDynamicTheme(root, this)
        if (ThemeStore.isNightMode(this) && ThemeStore.getBackgroundUri(this) == null) ThemeStore.applyNightBackground(root, this)
        header.setBackgroundColor(Color.TRANSPARENT)
        bottomNav.setBackgroundColor(if (ThemeStore.isNightMode(this)) Color.argb(205, 3, 10, 28) else Color.argb((alpha + 255) / 2, 255, 255, 255))
        findViewById<TextView>(R.id.tvSettingsTitle).setTextColor(p.text)
        blueValue.setTextColor(p.accent); transparencyValue.setTextColor(p.accent)
        blueValue.text = "${ThemeStore.getBlueIntensity(this)}%"
        transparencyValue.text = "${ThemeStore.getMenuTransparency(this)}%"
        val uri = ThemeStore.getBackgroundUri(this)
        if (uri != null) {
            runCatching {
                background.setImageURI(uri); background.visibility = View.VISIBLE
                preview.setImageURI(uri); preview.visibility = View.VISIBLE
            }.onFailure {
                ThemeStore.setBackgroundUri(this, null); background.visibility = View.GONE; preview.setImageDrawable(null)
            }
        } else {
            background.visibility = View.GONE; preview.setImageDrawable(null); preview.setBackgroundColor(p.surfaceAlt)
        }
        if (ThemeStore.isNightMode(this) && uri != null) {
            backgroundTint.setBackgroundColor(Color.argb(105, 0, 0, 0))
            backgroundTint.alpha = 1f
            backgroundTint.visibility = View.VISIBLE
        } else {
            backgroundTint.visibility = View.GONE
        }
        window.statusBarColor = if (ThemeStore.isNightMode(this)) Color.rgb(4, 10, 30) else Color.argb(alpha, 255, 255, 255)
        window.navigationBarColor = if (ThemeStore.isNightMode(this)) Color.rgb(3, 8, 24) else p.background
        window.decorView.systemUiVisibility = if (ThemeStore.isNightMode(this)) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        findViewById<TextView>(R.id.tvNightModeDescription).setTextColor(p.muted)
        setSettingsNavSelected(R.id.navSettingsSettings)
    }

    private fun setSettingsNavSelected(selected: Int) {
        val p = ThemeStore.palette(this)
        val ids = listOf(R.id.navRulesSettings, R.id.navHistorySettings, R.id.navSettingsSettings)
        ids.forEach { id ->
            val v = findViewById<TextView>(id)
            val active = id == selected
            val color = if (active) p.accent else p.muted
            v.isSelected = active
            v.setTextColor(color)
            v.compoundDrawableTintList = android.content.res.ColorStateList.valueOf(color)
        }
    }

    private fun chooseBackground() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 2001)
    }

    private fun backup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "AM_Respostas_Automaticas_backup.json")
        }
        startActivityForResult(intent, 3001)
    }

    private fun restore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
        startActivityForResult(intent, 3002)
    }

    private fun confirmClearBackground() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Limpar fotografia de fundo?")
            .setMessage("A fotografia de fundo será removida e a aplicação voltará a usar o fundo padrão. As restantes configurações, regras, pessoas e grupos não serão alteradas.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar") { _, _ ->
                ThemeStore.setBackgroundUri(this, null)
                refreshVisuals()
            }
            .create()

        dialog.show()
        styleDialogButtons(dialog)
        styleDialogCard(dialog)
        styleDialogTitleAndSpacing(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.let { title ->
            title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f)
            title.setTypeface(null, android.graphics.Typeface.BOLD)
            title.maxLines = 2
            title.ellipsize = null
        }
    }

    private fun confirmClearAppData() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Limpar dados da aplicação?")
            .setMessage("Esta ação vai apagar todas as regras, pessoas e grupos, histórico/diagnóstico, configurações visuais e a fotografia de fundo. A aplicação ficará como uma instalação nova. As cópias de segurança guardadas fora da aplicação não serão apagadas.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Limpar dados") { _, _ -> clearAppData() }
            .create()

        dialog.show()
        styleDialogButtons(dialog)
        styleDialogCard(dialog)
        styleDialogTitleAndSpacing(dialog)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        forceSingleLineDialogTitle(dialog)
    }

    private fun forceSingleLineDialogTitle(dialog: AlertDialog) {
        dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.let { title ->
            title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f)
            title.setTypeface(null, android.graphics.Typeface.BOLD)
            title.setTextColor(ThemeStore.palette(this).text)
            title.maxLines = 1
            title.setSingleLine(true)
            title.ellipsize = null
            title.gravity = Gravity.CENTER_VERTICAL
            title.setPadding(dp(14), dp(18), dp(14), dp(8))
            title.layoutParams = title.layoutParams.apply { width = WindowManager.LayoutParams.MATCH_PARENT }
            title.requestLayout()
        }
    }

    private fun styleDialogCard(dialog: AlertDialog) {
        val palette = ThemeStore.palette(this)
        dialog.window?.decorView?.background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(22).toFloat()
            setColor(palette.surface)
        }

        dialog.findViewById<TextView>(android.R.id.message)?.let { message ->
            message.setPadding(dp(22), dp(8), dp(22), dp(16))
        }
    }

    private fun styleDialogButtons(dialog: AlertDialog) {
        val blue = ThemeStore.palette(this).accent
        listOf(AlertDialog.BUTTON_NEGATIVE, AlertDialog.BUTTON_POSITIVE).forEach { which ->
            dialog.getButton(which)?.let { button ->
                button.setTextColor(Color.WHITE)
                button.backgroundTintList = null
                button.background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(blue)
                }
                button.minWidth = 0
                button.minimumWidth = 0
                button.minHeight = dp(40)
                button.minimumHeight = dp(40)
                button.setPadding(dp(12), 0, dp(12), 0)
                (button.layoutParams as? android.widget.LinearLayout.LayoutParams)?.let { lp ->
                    lp.width = android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
                    lp.weight = 0f
                    lp.marginStart = dp(4)
                    lp.marginEnd = dp(4)
                    button.layoutParams = lp
                }
            }
        }
    }

    private fun styleDialogTitleAndSpacing(dialog: AlertDialog) {
        val titleId = androidx.appcompat.R.id.alertTitle
        dialog.findViewById<TextView>(titleId)?.let { title ->
            title.textSize = 18f
            title.setTypeface(null, android.graphics.Typeface.BOLD)
            title.setTextColor(ThemeStore.palette(this).text)
            title.setPadding(dp(14), dp(18), dp(14), dp(8))
        }

        dialog.findViewById<TextView>(android.R.id.message)?.let { message ->
            message.setPadding(dp(22), dp(4), dp(22), dp(20))
        }

        val buttonPanelId = androidx.appcompat.R.id.buttonPanel
        dialog.findViewById<View>(buttonPanelId)?.let { panel ->
            panel.setPadding(panel.paddingLeft, panel.paddingTop, panel.paddingRight, dp(16))
        }
    }

    private fun showStyledDialog(dialog: AlertDialog) {
        dialog.show()
        styleDialogButtons(dialog)
        styleDialogCard(dialog)
        styleDialogTitleAndSpacing(dialog)
    }

    private fun clearAppData() {
        // Clear every preference store used by the application.
        listOf("am_reply", "am_people", "am_theme", "am_diagnostics", "am_contact_sync", "whatsapp_reply_gate")
            .forEach { name -> getSharedPreferences(name, MODE_PRIVATE).edit().clear().commit() }

        // Remove application-private files, including the saved wallpaper copy.
        filesDir.listFiles()?.forEach { file -> file.deleteRecursively() }
        cacheDir.listFiles()?.forEach { file -> file.deleteRecursively() }

        Toast.makeText(this, "Dados da aplicação limpos.", Toast.LENGTH_SHORT).show()
        recreate()
    }

    private fun startContactSelection(groupName: String?) {
        pendingGroupName = groupName
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingContactRequest = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 4001)
            return
        }
        pendingContactRequest = false
        val intent = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI).apply {
            type = ContactsContract.Contacts.CONTENT_TYPE
        }
        startActivityForResult(intent, 4002)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 4001) return
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        if (granted && pendingContactRequest) {
            pendingContactRequest = false
            startContactSelection(pendingGroupName)
        } else if (granted) {
            pendingGroupName?.let { organization ->
                pendingGroupName = null
                searchOrganizationContacts(organization)
            }
        } else {
            Toast.makeText(this, "É necessário permitir o acesso aos contactos para procurar ou escolher pessoas.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            2001 -> {
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                ThemeStore.setBackgroundUri(this, uri); refreshVisuals(); Toast.makeText(this, "Fundo atualizado.", Toast.LENGTH_SHORT).show()
            }
            3001 -> runCatching {
                contentResolver.openOutputStream(uri)?.use { it.write(BackupStore.export(this).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "Cópia de segurança guardada.", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this, "Não foi possível guardar a cópia de segurança.", Toast.LENGTH_SHORT).show() }
            3002 -> runCatching {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Ficheiro vazio")
                BackupStore.import(this, raw)
                // Reload every restored setting from the stores instead of trusting the
                // previous widget state. This makes rules, people/groups, master state,
                // colours, transparency and background all come back together.
                blueSeek.progress = ThemeStore.getBlueIntensity(this)
                transparencySeek.progress = ThemeStore.getMenuTransparency(this)
                val restoredMaster = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.settingsMaster)
                val restoredStatus = findViewById<TextView>(R.id.settingsStatus)
                restoredMaster.setOnCheckedChangeListener(null)
                restoredMaster.isChecked = RuleStore(this).isMasterEnabled()
                restoredStatus.text = if (restoredMaster.isChecked) "Ativo" else "Desativado"
                restoredMaster.setOnCheckedChangeListener { _, checked ->
                    RuleStore(this).setMasterEnabled(checked)
                    restoredStatus.text = if (checked) "Ativo" else "Desativado"
                }
                refreshPeople(); refreshVisuals()
                Toast.makeText(this, "Cópia de segurança reposta.", Toast.LENGTH_SHORT).show()
            }.onFailure { Toast.makeText(this, "Cópia de segurança inválida ou impossível de ler.", Toast.LENGTH_SHORT).show() }
            4002 -> handleContactPicked(uri)
        }
    }

    private fun handleContactPicked(uri: Uri) {
        runCatching {
            contentResolver.query(uri, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.LOOKUP_KEY), null, null, null)?.use { c ->
                if (!c.moveToFirst()) error("Contacto não encontrado")
                val id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID))
                val name = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)).orEmpty().ifBlank { "Contacto" }
                val lookup = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.LOOKUP_KEY))
                val phone = queryFirstPhone(id)
                saveSelectedContact(ContactPerson(name, id, lookup, phone), pendingGroupName)
            } ?: error("Não foi possível ler o contacto")
        }.onFailure { Toast.makeText(this, "Não foi possível adicionar o contacto.", Toast.LENGTH_SHORT).show() }
    }

    private fun queryFirstPhone(contactId: String): String? {
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?",
            arrayOf(contactId), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun saveSelectedContact(person: ContactPerson, groupName: String?) {
        val data = PeopleStore.load(this)
        if (groupName == null) {
            val exists = data.people.any { it.contactId != null && it.contactId == person.contactId }
            if (!exists) data.people.add(person)
        } else {
            val group = data.groups.firstOrNull { it.name == groupName } ?: return
            val exists = group.people.any { it.contactId != null && it.contactId == person.contactId }
            if (!exists) group.people.add(person)
        }
        PeopleStore.save(this, data); refreshPeople()
    }

    private fun refreshPeople() {
        peopleList.removeAllViews()
        val data = PeopleStore.load(this)
        val p = ThemeStore.palette(this)
        val groupCards = mutableListOf<Pair<String, View>>()

        data.people.forEach { person ->
            peopleList.addView(personRow(person, null), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        data.groups.forEach { group ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(12), dp(8), dp(10))
                background = getDrawable(R.drawable.bg_nav_item)
            }
            groupCards.add(group.name to card)

            val headerRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val drag = ImageButton(this).apply {
                setImageResource(R.drawable.ic_drag)
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                imageTintList = android.content.res.ColorStateList.valueOf(p.muted)
                alpha = 0.72f
                contentDescription = "Reordenar organização"
                setPadding(dp(3), dp(3), dp(3), dp(3))
                setOnTouchListener { v, event ->
                    when (event.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> {
                            // Capture the gesture on the drag handle so the parent
                            // settings ScrollView cannot start scrolling while the
                            // organization is being moved.
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                            draggingGroupName = group.name
                            draggingGroupStartRawY = event.rawY
                            card.bringToFront()
                            card.animate().cancel()
                            card.scaleX = 1.025f
                            card.scaleY = 1.025f
                            card.alpha = 0.96f
                            card.elevation = dp(10).toFloat()
                            true
                        }
                        android.view.MotionEvent.ACTION_MOVE -> {
                            if (draggingGroupName == group.name) {
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                                card.translationY = event.rawY - draggingGroupStartRawY
                            }
                            true
                        }
                        android.view.MotionEvent.ACTION_UP -> {
                            val dropY = event.rawY
                            if (draggingGroupName == group.name) {
                                val target = groupCards
                                    .asSequence()
                                    .filter { it.first != group.name }
                                    .minByOrNull {
                                        val loc = IntArray(2)
                                        it.second.getLocationOnScreen(loc)
                                        kotlin.math.abs(dropY - (loc[1] + it.second.height / 2f))
                                    }
                                if (target != null) {
                                    val currentData = PeopleStore.load(this@ThemesActivity)
                                    val from = currentData.groups.indexOfFirst { it.name == group.name }
                                    val to = currentData.groups.indexOfFirst { it.name == target.first }
                                    if (from >= 0 && to >= 0 && from != to) {
                                        val moved = currentData.groups.removeAt(from)
                                        currentData.groups.add(to, moved)
                                        PeopleStore.save(this@ThemesActivity, currentData)
                                    }
                                }
                            }
                            card.translationY = 0f
                            card.scaleX = 1f
                            card.scaleY = 1f
                            card.alpha = 1f
                            card.elevation = dp(1).toFloat()
                            draggingGroupName = null
                            v.parent?.requestDisallowInterceptTouchEvent(false)
                            refreshPeople()
                            true
                        }
                        android.view.MotionEvent.ACTION_CANCEL -> {
                            card.translationY = 0f
                            card.scaleX = 1f
                            card.scaleY = 1f
                            card.alpha = 1f
                            card.elevation = dp(1).toFloat()
                            draggingGroupName = null
                            v.parent?.requestDisallowInterceptTouchEvent(false)
                            true
                        }
                        else -> true
                    }
                }
            }
            headerRow.addView(drag, LinearLayout.LayoutParams(dp(30), dp(38)).apply { marginEnd = dp(2) })

            val title = TextView(this).apply {
                text = "Organização\n${group.name}"
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(p.text)
                isClickable = true
                isFocusable = true
                includeFontPadding = false
                setLineSpacing(0f, 1.0f)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
                setOnClickListener {
                    if (!expandedGroups.add(group.name)) expandedGroups.remove(group.name)
                    refreshPeople()
                }
            }
            headerRow.addView(title)

            val groupStatus = MaterialButton(this).apply {
                tag = "stateColor"
                text = if (group.included) "Incluída" else "Excluída"
                isAllCaps = false
                textSize = 11f
                minWidth = 0
                minHeight = dp(34)
                setPadding(dp(8), 0, dp(8), 0)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (group.included) Color.rgb(22, 163, 74) else Color.rgb(220, 70, 70)
                )
                setTextColor(Color.WHITE)
                setOnClickListener { toggleGroupInclusion(group.name) }
            }
            headerRow.addView(groupStatus, LinearLayout.LayoutParams(dp(70), dp(34)).apply {
                marginStart = dp(2); marginEnd = dp(1)
            })
            val editButton = iconButton("✎") { editGroup(group.name) }
            headerRow.addView(editButton, LinearLayout.LayoutParams(dp(32), dp(40)).apply {
                marginStart = dp(1); marginEnd = dp(0)
            })
            val deleteButton = iconButton("⌫") { deleteGroup(group.name) }
            headerRow.addView(deleteButton, LinearLayout.LayoutParams(dp(32), dp(40)).apply {
                marginStart = dp(0); marginEnd = dp(0)
            })
            card.addView(headerRow)

            val membersTitle = TextView(this).apply {
                text = "Pessoas no grupo"
                textSize = 13f
                setTextColor(p.muted)
                setPadding(0, dp(5), 0, dp(3))
            }
            card.addView(membersTitle)

            if (group.people.isEmpty()) {
                card.addView(TextView(this).apply {
                    text = "Sem pessoas adicionadas"
                    textSize = 13f
                    setTextColor(p.muted)
                    setPadding(0, 0, 0, dp(6))
                })
            } else if (expandedGroups.contains(group.name)) {
                // Expanded organizations show a fixed five-contact viewport.
                // Scrolling happens inside this area, so large organizations never
                // push the whole Configurações page down by hundreds of rows.
                val included = if (!group.included) 0 else group.people.count { person -> !isExcluded(group, person) }
                val excluded = group.people.size - included
                card.addView(TextView(this).apply {
                    text = "Incluídas: $included  ·  Excluídas: $excluded"
                    textSize = 13f
                    setTextColor(p.muted)
                    setPadding(0, 0, 0, dp(5))
                })

                // RecyclerView creates only the rows that are actually visible instead
                // of constructing hundreds of Android Views when a large organization opens.
                // This keeps opening/closing an organization responsive even with 500+ people.
                val memberRecycler = androidx.recyclerview.widget.RecyclerView(this).apply {
                    layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this@ThemesActivity)
                    overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                    adapter = OrganizationPeopleAdapter(group.name, group.people.toList())
                    setOnTouchListener { view, event ->
                        when (event.actionMasked) {
                            android.view.MotionEvent.ACTION_DOWN,
                            android.view.MotionEvent.ACTION_MOVE -> view.parent?.requestDisallowInterceptTouchEvent(true)
                            android.view.MotionEvent.ACTION_UP,
                            android.view.MotionEvent.ACTION_CANCEL -> view.parent?.requestDisallowInterceptTouchEvent(false)
                        }
                        false
                    }
                }
                card.addView(memberRecycler, LinearLayout.LayoutParams(-1, dp(5 * 58)).apply { topMargin = dp(1) })
            }

            val groupActions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.START
                // Align the organization action buttons with the main + Pessoa / + Organização row below.
                setPadding(dp(6), 0, 0, 0)
            }
            fun groupActionButton(label: String, action: () -> Unit): MaterialButton = MaterialButton(this).apply {
                text = label
                backgroundTintList = android.content.res.ColorStateList.valueOf(p.accent)
                isAllCaps = false
                minWidth = 0
                minimumWidth = 0
                minHeight = dp(44)
                minimumHeight = dp(44)
                setPadding(dp(14), 0, dp(14), 0)
                cornerRadius = dp(14)
                setOnClickListener { action() }
            }
            val search = groupActionButton("Atualizar") { searchOrganizationContacts(group.name) }
            groupActions.addView(search, LinearLayout.LayoutParams(-2, dp(44)).apply {
                topMargin = dp(7)
                marginEnd = dp(8)
            })

            val add = groupActionButton("＋ Pessoa") { startContactSelection(group.name) }
            groupActions.addView(add, LinearLayout.LayoutParams(-2, dp(44)).apply {
                topMargin = dp(7)
            })
            card.addView(groupActions)
            peopleList.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        if (data.people.isEmpty() && data.groups.isEmpty()) {
            peopleList.addView(TextView(this).apply {
                text = "Ainda não existem pessoas ou grupos."
                textSize = 14f
                setTextColor(p.muted)
                setPadding(dp(4), dp(8), dp(4), dp(8))
            })
        }
    }

    private fun personRow(person: ContactPerson, group: String?, nested: Boolean = false): View {
        val p = ThemeStore.palette(this)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(if (nested) dp(8) else dp(14), dp(7), dp(4), dp(7))
        }
        val label = TextView(this).apply {
            text = if (person.phone.isNullOrBlank()) person.name else "${person.name}\n${person.phone}"
            textSize = if (nested) 14f else 14f
            setTextColor(p.text)
            includeFontPadding = false
            maxLines = 2
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        row.addView(label)
        if (group != null) {
            val data = PeopleStore.load(this)
            val contactGroup = data.groups.firstOrNull { it.name == group }
            val excluded = contactGroup?.let { groupState ->
                !groupState.included || isExcluded(groupState, person)
            } == true
            val status = MaterialButton(this).apply {
                tag = "stateColor"
                text = if (excluded) "Excluída" else "Incluída"
                isAllCaps = false
                textSize = 11f
                minWidth = 0
                minHeight = dp(34)
                setPadding(dp(8), 0, dp(8), 0)
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    if (excluded) Color.rgb(220, 70, 70) else Color.rgb(22, 163, 74)
                )
                setTextColor(Color.WHITE)
                setOnClickListener { togglePersonInclusion(group, person) }
            }
            row.addView(status, LinearLayout.LayoutParams(dp(70), dp(34)).apply {
                leftMargin = dp(3); rightMargin = dp(1)
            })
        }
        row.addView(iconButton("✎") { editPerson(person, group) }, LinearLayout.LayoutParams(dp(32), dp(40)))
        row.addView(iconButton("⌫") { deletePerson(person, group) }, LinearLayout.LayoutParams(dp(32), dp(40)).apply { marginStart = dp(1) })
        return row
    }

    private inner class OrganizationPeopleAdapter(
        private val groupName: String,
        private val people: List<ContactPerson>
    ) : androidx.recyclerview.widget.RecyclerView.Adapter<OrganizationPeopleAdapter.Holder>() {
        inner class Holder(val container: FrameLayout) : androidx.recyclerview.widget.RecyclerView.ViewHolder(container)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val container = FrameLayout(this@ThemesActivity).apply {
                layoutParams = androidx.recyclerview.widget.RecyclerView.LayoutParams(-1, dp(58))
            }
            return Holder(container)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            holder.container.removeAllViews()
            holder.container.addView(personRow(people[position], groupName, true), FrameLayout.LayoutParams(-1, -1))
        }

        override fun getItemCount(): Int = people.size
    }

    private fun iconButton(symbol: String, action: () -> Unit): View {
        val button = ImageButton(this)
        button.layoutParams = LinearLayout.LayoutParams(dp(32), dp(40))
        button.setPadding(dp(3), dp(7), dp(3), dp(7))
        button.background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        button.backgroundTintList = null
        button.scaleType = ImageView.ScaleType.CENTER_INSIDE
        button.imageTintList = android.content.res.ColorStateList.valueOf(ThemeStore.palette(this).muted)
        if (symbol == "✎") {
            button.setImageResource(R.drawable.ic_edit)
            button.contentDescription = "Editar"
        } else {
            button.setImageResource(R.drawable.ic_delete)
            button.contentDescription = "Apagar"
        }
        button.setOnClickListener { action() }
        return button
    }

    private fun isExcluded(group: ContactGroup, person: ContactPerson): Boolean {
        val id = person.contactId ?: return false
        return id in group.excludedContactIds
    }

    private fun togglePersonInclusion(groupName: String, person: ContactPerson) {
        val data = PeopleStore.load(this)
        val group = data.groups.firstOrNull { it.name == groupName } ?: return
        val id = person.contactId
        if (id == null) {
            Toast.makeText(this, "Este contacto não tem um ID válido para guardar a exceção.", Toast.LENGTH_SHORT).show()
            return
        }
        if (id in group.excludedContactIds) {
            group.excludedContactIds.remove(id)
        } else {
            group.excludedContactIds.add(id)
        }
        PeopleStore.save(this, data)
        refreshPeople()
    }

    private fun toggleGroupInclusion(groupName: String) {
        val data = PeopleStore.load(this)
        val group = data.groups.firstOrNull { it.name == groupName } ?: return
        group.included = !group.included
        PeopleStore.save(this, data)
        refreshPeople()
    }

    private fun editPerson(person: ContactPerson, groupName: String?) {
        val input = EditText(this).apply {
            setText(person.name)
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            hint = "Nome da pessoa"
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(8), 0, dp(8), 0)
            addView(input, LinearLayout.LayoutParams(-1, dp(58)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Editar pessoa")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isBlank()) return@setPositiveButton
                val data = PeopleStore.load(this)
                val target = if (groupName == null) data.people else data.groups.firstOrNull { it.name == groupName }?.people
                target?.firstOrNull { samePerson(it, person) }?.name = newName
                PeopleStore.save(this, data)
                refreshPeople()
            }
            .create()
        showStyledDialog(dialog)
    }

    private fun deletePerson(person: ContactPerson, groupName: String?) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Apagar pessoa?")
            .setMessage("A pessoa \"${person.name}\" será removida desta lista. O contacto do telemóvel não será apagado.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar") { _, _ ->
                val data = PeopleStore.load(this)
                val target = if (groupName == null) data.people else data.groups.firstOrNull { it.name == groupName }?.people
                val key = personKey(person)
                target?.removeAll { samePerson(it, person) }
                if (groupName != null) {
                    data.groups.firstOrNull { it.name == groupName }?.excludedContactIds?.remove(person.contactId)
                }
                PeopleStore.save(this, data)
                val ruleStore = RuleStore(this)
                val rules = ruleStore.loadRules()
                rules.forEach { it.targetPeople.removeAll { selected -> selected == key } }
                ruleStore.saveRules(rules)
                refreshPeople()
            }
            .create()
        showStyledDialog(dialog)
    }

    private fun personKey(person: ContactPerson): String =
        person.contactId?.let { "id:$it" } ?: "name:${person.name}"

    private fun samePerson(a: ContactPerson, b: ContactPerson): Boolean {
        return if (a.contactId != null && b.contactId != null) a.contactId == b.contactId else a === b || (a.contactId == null && b.contactId == null && a.name == b.name)
    }

    /** Finds Android contacts whose Organization/Company field matches the organization name. */
    private fun searchOrganizationContacts(organizationName: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "É necessário permitir o acesso aos contactos para procurar por organização.", Toast.LENGTH_LONG).show()
            pendingGroupName = organizationName
            pendingContactRequest = false
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 4001)
            return
        }

        Thread {
            val found = runCatching { findContactsByOrganization(organizationName) }.getOrElse { emptyList() }
            runOnUiThread {
                val data = PeopleStore.load(this)
                val group = data.groups.firstOrNull { it.name.equals(organizationName, true) }
                if (group == null) return@runOnUiThread

                var added = 0
                found.forEach { person ->
                    val contactId = person.contactId
                    val exists = group.people.any { samePerson(it, person) || (it.contactId != null && it.contactId == contactId) }
                    if (!exists && (contactId == null || contactId !in group.excludedContactIds)) {
                        group.people.add(person)
                        added++
                    }
                }
                // After importing an organization, keep all its contacts alphabetically
                // ordered by name. The comparison ignores accents/case so names such as
                // "Cláudia" are placed together with the other contacts beginning with C.
                val nameCollator = java.text.Collator.getInstance(java.util.Locale("pt", "PT")).apply {
                    strength = java.text.Collator.PRIMARY
                    decomposition = java.text.Collator.CANONICAL_DECOMPOSITION
                }
                group.people.sortWith(Comparator { a, b ->
                    val byName = nameCollator.compare(a.name.trim(), b.name.trim())
                    if (byName != 0) byName else (a.phone.orEmpty()).compareTo(b.phone.orEmpty(), ignoreCase = true)
                })

                PeopleStore.save(this, data)
                refreshPeople()
                Toast.makeText(
                    this,
                    if (found.isEmpty()) "Não foram encontrados contactos com Organização: $organizationName."
                    else "Encontrados: ${found.size} · adicionados: $added · organizados por nome",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun findContactsByOrganization(organizationName: String): List<ContactPerson> {
        val ids = linkedSetOf<String>()
        contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data.CONTACT_ID, ContactsContract.CommonDataKinds.Organization.COMPANY),
            "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.CommonDataKinds.Organization.COMPANY} IS NOT NULL",
            arrayOf(ContactsContract.CommonDataKinds.Organization.CONTENT_ITEM_TYPE),
            null
        )?.use { c ->
            val idIndex = c.getColumnIndexOrThrow(ContactsContract.Data.CONTACT_ID)
            val companyIndex = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Organization.COMPANY)
            while (c.moveToNext()) {
                val company = c.getString(companyIndex).orEmpty().trim()
                if (company.equals(organizationName.trim(), ignoreCase = true)) {
                    ids += c.getString(idIndex)
                }
            }
        }

        return ids.mapNotNull { contactId ->
            runCatching {
                contentResolver.query(
                    ContactsContract.Contacts.CONTENT_URI,
                    arrayOf(
                        ContactsContract.Contacts._ID,
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.Contacts.LOOKUP_KEY
                    ),
                    "${ContactsContract.Contacts._ID}=?",
                    arrayOf(contactId),
                    null
                )?.use { c ->
                    if (!c.moveToFirst()) return@runCatching null
                    val name = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME)).orEmpty().ifBlank { "Contacto" }
                    val lookup = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.LOOKUP_KEY))
                    ContactPerson(name, contactId, lookup, queryFirstPhone(contactId))
                }
            }.getOrNull()
        }
    }

    private fun addGroup() {
        val input = EditText(this).apply {
            hint = "Nome da organização"
            setSingleLine(true)
            setPadding(0, 0, 0, 0)
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(18), 0, dp(18), 0)
            addView(input, LinearLayout.LayoutParams(-1, dp(58)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Adicionar organização")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Criar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                val data = PeopleStore.load(this)
                if (data.groups.any { it.name.equals(name, true) }) {
                    Toast.makeText(this, "Essa organização já existe.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                showGroupInclusionDialog(name)
            }
            .create()
        showStyledDialog(dialog)
        dialog.findViewById<TextView>(androidx.appcompat.R.id.alertTitle)?.let { title ->
            title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f)
            title.setTypeface(null, android.graphics.Typeface.BOLD)
            title.gravity = Gravity.CENTER
            title.textAlignment = View.TEXT_ALIGNMENT_CENTER
            title.maxLines = 1
            title.setSingleLine(true)
        }
        input.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        input.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    private fun showGroupInclusionDialog(name: String) {
        val palette = ThemeStore.palette(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(4), dp(22), dp(8))
        }
        content.addView(TextView(this).apply {
            text = "Como queres tratar esta organização?"
            textSize = 16f
            setTextColor(palette.text)
            setPadding(0, 0, 0, dp(12))
        })
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun choiceButton(label: String, color: Int): MaterialButton = MaterialButton(this).apply {
            text = label
            isAllCaps = false
            minWidth = 0
            minHeight = dp(42)
            cornerRadius = dp(14)
            setPadding(dp(10), 0, dp(10), 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(color)
            setTextColor(Color.WHITE)
        }
        val included = choiceButton("Incluída", Color.rgb(22, 163, 74))
        val excluded = choiceButton("Excluída", Color.rgb(220, 70, 70))
        buttons.addView(included, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        buttons.addView(excluded, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        content.addView(buttons)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Estado da organização")
            .setView(content)
            .setNegativeButton("Cancelar", null)
            .create()
        included.setOnClickListener {
            createGroupWithState(name, true)
            dialog.dismiss()
        }
        excluded.setOnClickListener {
            createGroupWithState(name, false)
            dialog.dismiss()
        }
        showStyledDialog(dialog)
    }

    private fun createGroupWithState(name: String, included: Boolean) {
        val data = PeopleStore.load(this)
        if (data.groups.any { it.name.equals(name, true) }) return
        data.groups.add(ContactGroup(name, included = included))
        PeopleStore.save(this, data)
        refreshPeople()
        searchOrganizationContacts(name)
    }

    private fun editGroup(oldName: String) {
        val input = EditText(this).apply {
            setText(oldName)
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            hint = "Nome da organização"
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(8), 0, dp(8), 0)
            addView(input, LinearLayout.LayoutParams(-1, dp(58)))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Editar organização")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                val data = PeopleStore.load(this)
                data.groups.firstOrNull { it.name == oldName }?.name = name
                PeopleStore.save(this, data)
                val ruleStore = RuleStore(this)
                val rules = ruleStore.loadRules()
                rules.forEach { rule ->
                    for (i in rule.targetGroups.indices) {
                        if (rule.targetGroups[i] == oldName) rule.targetGroups[i] = name
                    }
                }
                ruleStore.saveRules(rules)
                refreshPeople()
            }
            .create()
        showStyledDialog(dialog)
    }

    private fun deleteGroup(name: String) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Apagar organização?")
            .setMessage("A organização \"$name\" e as pessoas que estão dentro dela serão removidas desta aplicação. Os contactos do telemóvel não serão apagados.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar") { _, _ ->
                val data = PeopleStore.load(this)
                data.groups.removeAll { it.name == name }
                PeopleStore.save(this, data)
                val ruleStore = RuleStore(this)
                val rules = ruleStore.loadRules()
                rules.forEach { it.targetGroups.removeAll { selected -> selected == name } }
                ruleStore.saveRules(rules)
                refreshPeople()
            }
            .create()
        showStyledDialog(dialog)
    }

    private fun dp(value: Int): Int = kotlin.math.round(value * resources.displayMetrics.density).toInt()

}
