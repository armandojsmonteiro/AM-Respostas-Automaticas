# AM Responder — projeto novo

Projeto reconstruído a partir da V57 funcional, sem usar as versões V58–V61 como base.

Lista intocável:
1. WhatsApp
2. WhatsApp Clonado
3. WhatsApp Trabalho
4. WhatsApp Business
5. WhatsApp Business Clonado
6. Telegram
7. Telegram Clonado
8. Telegram Trabalho
9. iMe
10. iMe Trabalho
11. Nicegram
12. Nicegram Trabalho
13. Signal
14. Signal Clonado
15. Signal Trabalho
16. SMS

Inclui reordenação das regras por arrastar no botão ☰ e workflow GitHub Actions para gerar o APK.
