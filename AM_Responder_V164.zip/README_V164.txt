AM Respostas Automáticas — V164

Versão 164.
- Corrigido o diálogo de Identificação das aplicações / IDs para manter Cancelar e Guardar visíveis.
- Adicionado botão Procurar IDs para nova deteção dos IDs através das notificações atualmente ativas.
- Mantidos os IDs detetados manualmente e os dados da versão anterior.
- versionCode = 164; versionName = 164.
