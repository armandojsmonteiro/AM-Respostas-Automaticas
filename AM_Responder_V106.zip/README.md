# AM Responder — Android V70

Base exclusiva: V69 (última versão visualmente aprovada pelo utilizador).

## V70 — correções finais de visualização e persistência
- Nome da aplicação/instância ligeiramente aumentado.
- Interruptor, editar e apagar ficam numa coluna vertical única, alinhada ao extremo direito.
- Mensagem da regra sai da coluna central e passa a ocupar toda a largura abaixo da linha superior, começando imediatamente sob a zona do ícone.
- Botões + Pessoa / + Grupo ficam com texto explicitamente centrado, incluindo remoção dos insets internos do MaterialButton.
- Símbolos de WhatsApp, WhatsApp Business, Telegram, Signal, iMe, Nicegram e SMS mantêm recursos individuais; o Signal foi redesenhado para corresponder ao símbolo de balão oficial e as restantes variantes continuam separadas por aplicação.
- Corrigido o problema de gravação/edição: a lista usada pelo RulesAdapter deixa de ser substituída ao regressar ao ecrã, evitando que alterações guardadas desapareçam visualmente.
- Corrigido o mesmo problema após sincronização de contactos.
- Cópia de segurança atualizada para formato 3 e importação reforçada para reaplicar regras, pessoas/grupos, estado Ativo, intensidade de azul, transparência e fotografia de fundo.
- Mantida a lista de 16 Aplicações / Instâncias e toda a lógica funcional existente.


V102: baseada exclusivamente na V101. Única alteração: limitar a largura horizontal de tvMessage para que o texto termine antes dos botões, mantendo a posição vertical e a posição à esquerda da V101.


V104: baseada exclusivamente na V103. Única alteração: aproximar a quebra automática de linha da direita, reduzindo a margem direita de tvMessage, sem alterar a posição vertical nem a posição à esquerda do texto.


V106: baseada exclusivamente na V105. Duas microcorreções visuais na mensagem: aumentar ligeiramente a margem direita para garantir que nenhuma letra toque nos botões e reduzir o espaço vazio inferior da mensagem, sem alterar a posição esquerda, a posição vertical, o tamanho do texto ou os botões.
