AM Respostas Automáticas — V189

Base exclusiva: V188.

Alterações desta versão:
- Primeira página: os ícones de editar e apagar ficam sem qualquer fundo/quadrado, apenas o desenho do ícone.
- Azul: o controlo Azul passa a aplicar a cor escolhida imediatamente a todos os MaterialButtons azuis, incluindo Repor cópia de segurança e os restantes botões, sem alterar estados verdes/vermelhos.
- Azul: interruptores e barras continuam a acompanhar a alteração em tempo real.
- Navegação inferior: cada menu passa a destacar corretamente o seu próprio ícone e texto; em Configurações, o destaque fica na roda dentada.
- Adicionar organização: campo Nome da organização fica corretamente dentro da área útil do diálogo, com margem interna adequada e sem corte à esquerda.

Nenhuma outra alteração funcional foi introduzida.
