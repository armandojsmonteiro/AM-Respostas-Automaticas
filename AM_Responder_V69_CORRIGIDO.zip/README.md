# AM Responder — Android V69

Base exclusiva: V63.

Correção desta versão: a lista intocável de 16 Aplicações / Instâncias fica efetivamente refletida no seletor do diálogo Adicionar regra, incluindo iMe, iMe Trabalho, Nicegram e Nicegram Trabalho, na ordem definida. Nenhuma das outras opções foi removida ou reordenada.

Lista intocável:
1. WhatsApp
2. WhatsApp Clonado
3. WhatsApp Trabalho
4. WhatsApp Business
5. WhatsApp Business Clonado
6. Telegram
7. Telegram Clonado
8. Telegram Trabalho
9. iMe
10. iMe Trabalho
11. Nicegram
12. Nicegram Trabalho
13. Signal
14. Signal Clonado
15. Signal Trabalho
16. SMS

Inclui também a reordenação das regras por arrastar no botão ☰ e workflow GitHub Actions para gerar o APK.


## V68 — layout, icons e alinhamento
- Botão/interruptor da regra no topo direito, lápis no meio e apagar no fim, todos em coluna vertical.
- Área central da regra fica livre para nome, aplicação e mensagem.
- Botões Pessoas/Grupos centrados no ecrã de configurações e no diálogo de regra.
- Ícones das aplicações normalizados; WhatsApp Business e iMe têm recursos próprios e as variantes Clonado/Trabalho usam o ícone da respetiva aplicação.
- A importação de cópia de segurança mantém a reposição das regras, pessoas/grupos e definições visuais.


## V69 — ajustes finais de layout e cópia de segurança
- Nome da aplicação/instância aumentado na ficha da regra.
- Mensagem passa a começar imediatamente abaixo da aplicação, dentro da coluna central, sem o espaço vazio provocado pelos controlos laterais.
- Interruptor, lápis e apagar ficam alinhados numa coluna vertical encostada à direita.
- Botões + Pessoa / + Grupo ficam com alinhamento de texto efetivamente centrado.
- Adicionado ícone próprio para Nicegram e mantido o mapeamento individual das aplicações.
- Importação recarrega as regras e o estado principal ao regressar ao ecrã Regras.
- A cópia de segurança passa a incluir a fotografia de fundo e restaura-a juntamente com as restantes definições visuais.
