# AM Respostas Automáticas — Android v1 de diagnóstico

Esta é a primeira versão nativa Android do projeto.

## O que já faz
- Interface com o nome aprovado: **AM Respostas Automáticas**
- Interruptor geral ON/OFF
- Criar, editar, apagar e ligar/desligar regras individualmente
- 7 instâncias disponíveis:
  - WhatsApp
  - WhatsApp Clonado
  - WhatsApp Business
  - WhatsApp Trabalho
  - Telegram
  - Telegram Clonado
  - Telegram Trabalho
- Guarda as regras localmente no telemóvel
- Serviço de diagnóstico de notificações
- Mostra o pacote da app e o User/Profile ID de cada notificação recebida

## Objetivo desta versão
Ainda **não responde automaticamente**. Primeiro temos de descobrir, no Honor Magic V3, como cada uma das 7 instâncias aparece ao sistema.

## Teste
1. Compilar e instalar a app.
2. Abrir **Diagnóstico**.
3. Carregar em **Dar acesso às notificações** e autorizar a AM Respostas Automáticas.
4. Enviar uma mensagem para cada WhatsApp e Telegram.
5. Voltar ao Diagnóstico e copiar/fotografar os registos.
6. Com esses identificadores, a próxima versão fará o mapeamento real de cada instância e avançará para a resposta automática.
