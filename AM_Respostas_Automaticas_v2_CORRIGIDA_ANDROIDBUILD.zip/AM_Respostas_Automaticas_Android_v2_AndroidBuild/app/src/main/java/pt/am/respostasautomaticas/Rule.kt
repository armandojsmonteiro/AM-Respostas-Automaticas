package pt.am.respostasautomaticas

data class Rule(
    val id: Long,
    var name: String,
    var instance: String,
    var message: String,
    var enabled: Boolean = true
)
