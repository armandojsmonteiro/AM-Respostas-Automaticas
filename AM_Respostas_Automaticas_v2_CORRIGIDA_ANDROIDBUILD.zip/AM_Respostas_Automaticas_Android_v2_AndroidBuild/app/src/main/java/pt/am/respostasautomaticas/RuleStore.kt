package pt.am.respostasautomaticas

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class RuleStore(context: Context) {
    private val prefs = context.getSharedPreferences("am_reply", Context.MODE_PRIVATE)

    fun isMasterEnabled(): Boolean = prefs.getBoolean("master_enabled", true)

    fun setMasterEnabled(value: Boolean) {
        prefs.edit().putBoolean("master_enabled", value).apply()
    }

    fun loadRules(): MutableList<Rule> {
        val raw = prefs.getString("rules", null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val list = mutableListOf<Rule>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += Rule(
                o.getLong("id"),
                o.getString("name"),
                o.getString("instance"),
                o.getString("message"),
                o.optBoolean("enabled", true)
            )
        }
        return list
    }

    fun saveRules(rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("name", r.name)
                put("instance", r.instance)
                put("message", r.message)
                put("enabled", r.enabled)
            })
        }
        prefs.edit().putString("rules", arr.toString()).apply()
    }
}
