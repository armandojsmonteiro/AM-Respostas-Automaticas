package pt.am.respostasautomaticas

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationDiagnosticService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        DiagnosticsStore.append(
            applicationContext,
            sbn.packageName,
            sbn.user.identifier,
            title,
            text
        )
    }
}
