package pt.am.respostasautomaticas

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DiagnosticsActivity : AppCompatActivity() {
    private lateinit var tvPermission: TextView
    private lateinit var tvLog: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostics)

        tvPermission = findViewById(R.id.tvPermission)
        tvLog = findViewById(R.id.tvLog)

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            DiagnosticsStore.clear(this)
            refresh()
        }
        findViewById<Button>(R.id.btnOpenNotificationSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val enabled = isNotificationListenerEnabled()
        tvPermission.text = if (enabled)
            "✓ Acesso às notificações ativo. Agora envia uma mensagem para cada WhatsApp/Telegram e vê os identificadores abaixo."
        else
            "⚠ Acesso às notificações ainda não está ativo. Carrega no botão abaixo e autoriza a AM Respostas Automáticas."

        tvLog.text = DiagnosticsStore.get(this)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?: return false
        val expected = ComponentName(this, NotificationDiagnosticService::class.java).flattenToString()
        return flat.split(":").any { it == expected }
    }
}
