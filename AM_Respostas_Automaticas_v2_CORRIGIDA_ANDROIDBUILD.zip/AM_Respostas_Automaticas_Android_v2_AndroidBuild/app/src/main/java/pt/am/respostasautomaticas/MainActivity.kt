package pt.am.respostasautomaticas

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {
    private lateinit var store: RuleStore
    private lateinit var rules: MutableList<Rule>
    private lateinit var adapter: RulesAdapter
    private lateinit var master: MaterialSwitch
    private lateinit var status: TextView

    private val instances = listOf(
        "WhatsApp",
        "WhatsApp Clonado",
        "WhatsApp Business",
        "WhatsApp Trabalho",
        "Telegram",
        "Telegram Clonado",
        "Telegram Trabalho"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = RuleStore(this)
        rules = store.loadRules()
        master = findViewById(R.id.switchMaster)
        status = findViewById(R.id.tvStatus)

        master.isChecked = store.isMasterEnabled()
        updateMasterStatus(master.isChecked)
        master.setOnCheckedChangeListener { _, checked ->
            store.setMasterEnabled(checked)
            updateMasterStatus(checked)
        }

        adapter = RulesAdapter(
            rules,
            onToggle = { store.saveRules(rules) },
            onEdit = { showRuleDialog(it) },
            onDelete = { rule ->
                AlertDialog.Builder(this)
                    .setMessage("Apagar a regra \"${rule.name}\"?")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Apagar") { _, _ ->
                        rules.remove(rule)
                        store.saveRules(rules)
                        adapter.notifyDataSetChanged()
                    }.show()
            }
        )

        findViewById<RecyclerView>(R.id.recyclerRules).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<Button>(R.id.btnAdd).setOnClickListener { showRuleDialog(null) }
        findViewById<Button>(R.id.btnDiagnostics).setOnClickListener {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }
    }

    private fun updateMasterStatus(enabled: Boolean) {
        status.text = if (enabled) "Ativo" else "Desativado"
    }

    private fun showRuleDialog(existing: Rule?) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_rule, null)
        val title = view.findViewById<TextView>(R.id.tvDialogTitle)
        val name = view.findViewById<EditText>(R.id.etName)
        val spinner = view.findViewById<Spinner>(R.id.spinnerInstance)
        val message = view.findViewById<EditText>(R.id.etMessage)

        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, instances)

        if (existing != null) {
            title.text = "Editar regra"
            name.setText(existing.name)
            spinner.setSelection(instances.indexOf(existing.instance).coerceAtLeast(0))
            message.setText(existing.message)
        }

        AlertDialog.Builder(this)
            .setView(view)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
            .apply {
                setOnShowListener {
                    getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val ruleName = name.text.toString().trim()
                        val reply = message.text.toString().trim()
                        if (ruleName.isEmpty() || reply.isEmpty()) {
                            Toast.makeText(this@MainActivity, "Preenche o nome e a resposta.", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        if (existing == null) {
                            rules.add(Rule(System.currentTimeMillis(), ruleName, spinner.selectedItem.toString(), reply, true))
                        } else {
                            existing.name = ruleName
                            existing.instance = spinner.selectedItem.toString()
                            existing.message = reply
                        }
                        store.saveRules(rules)
                        adapter.notifyDataSetChanged()
                        dismiss()
                    }
                }
            }.show()
    }
}
