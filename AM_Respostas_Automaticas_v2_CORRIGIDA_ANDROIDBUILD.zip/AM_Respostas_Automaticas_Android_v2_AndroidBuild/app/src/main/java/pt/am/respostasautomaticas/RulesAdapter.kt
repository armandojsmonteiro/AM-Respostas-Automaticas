package pt.am.respostasautomaticas

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

class RulesAdapter(
    private val rules: MutableList<Rule>,
    private val onToggle: (Rule) -> Unit,
    private val onEdit: (Rule) -> Unit,
    private val onDelete: (Rule) -> Unit
) : RecyclerView.Adapter<RulesAdapter.Holder>() {

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvRuleName)
        val instance: TextView = v.findViewById(R.id.tvInstance)
        val message: TextView = v.findViewById(R.id.tvMessage)
        val toggle: MaterialSwitch = v.findViewById(R.id.switchRule)
        val edit: ImageButton = v.findViewById(R.id.btnEdit)
        val delete: ImageButton = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_rule, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val rule = rules[position]
        holder.name.text = rule.name
        holder.instance.text = rule.instance
        holder.message.text = rule.message

        holder.toggle.setOnCheckedChangeListener(null)
        holder.toggle.isChecked = rule.enabled
        holder.toggle.setOnCheckedChangeListener { _, checked ->
            rule.enabled = checked
            onToggle(rule)
        }
        holder.edit.setOnClickListener { onEdit(rule) }
        holder.delete.setOnClickListener { onDelete(rule) }
        holder.itemView.alpha = if (rule.enabled) 1f else 0.58f
    }

    override fun getItemCount(): Int = rules.size
}
