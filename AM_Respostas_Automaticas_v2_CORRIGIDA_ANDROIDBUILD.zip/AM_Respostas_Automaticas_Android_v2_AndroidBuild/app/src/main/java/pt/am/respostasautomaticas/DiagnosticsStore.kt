package pt.am.respostasautomaticas

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DiagnosticsStore {
    private const val PREFS = "am_diagnostics"
    private const val KEY = "log"

    fun append(context: Context, packageName: String, userId: Int, title: String, text: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(KEY, "") ?: ""
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = buildString {
            append("[$stamp]\n")
            append("Pacote: $packageName\n")
            append("User/Profile ID: $userId\n")
            append("Título: $title\n")
            append("Texto: $text\n")
            append("------------------------------\n")
        }
        val merged = (entry + current).take(30000)
        prefs.edit().putString(KEY, merged).apply()
    }

    fun get(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "Ainda não foi recebida nenhuma notificação.") ?: ""

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }
}
