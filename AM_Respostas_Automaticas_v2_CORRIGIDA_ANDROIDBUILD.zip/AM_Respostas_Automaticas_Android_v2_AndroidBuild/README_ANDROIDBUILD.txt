VERSÃO CORRIGIDA PARA ANDROIDBUILD

O problema anterior era a combinação de um Gradle Wrapper incompleto com uma configuração que não estava alinhada com o Gradle 8.4 selecionado no AndroidBuild.

Esta versão:
- não inclui um Gradle Wrapper incompleto;
- usa o Gradle do próprio AndroidBuild;
- está alinhada com Gradle 8.4;
- usa Android Gradle Plugin 8.3.2;
- usa Kotlin 1.9.22;
- usa Java 17;
- compileSdk e targetSdk 34;
- mantém o código e as funcionalidades de diagnóstico e regras.

NO ANDROIDBUILD ESCOLHE:
Platform: Android native
Target SDK: API 34
Minimum SDK: API 21 ou superior (a app pede 26)
Build type: Debug
Gradle: 8.4

Depois carrega em Analyser mon projet e, se estiver tudo bem, Compilar em APK.
