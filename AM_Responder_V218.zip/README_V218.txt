AM Respostas Automáticas — V218

Base obrigatória: V217.

Única alteração desta versão:
- Corrigido o diálogo “Apagar regra?” para usar exatamente o mesmo sistema de botões, dimensões, alinhamento e espaçamento inferior dos restantes diálogos de confirmação da aplicação.
- O texto da mensagem fica alinhado à esquerda.
- Os botões “Cancelar” e “Apagar” ficam à direita, com o mesmo tamanho e estilo dos restantes menus de confirmação.
- Mantido o espaço inferior branco dentro do balão.
- Não foram alterados menus, regras, contactos, configurações ou outras funcionalidades.
