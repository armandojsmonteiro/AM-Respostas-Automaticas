AM Respostas Automáticas — V218

Base: V217.
Alteração única: uniformização do diálogo “Apagar regra?” com os restantes diálogos de confirmação, mantendo mensagem à esquerda, botões à direita e dimensões/espacamentos consistentes.
