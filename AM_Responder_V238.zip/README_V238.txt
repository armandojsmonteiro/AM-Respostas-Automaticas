AM Respostas Automáticas — V238

Base exclusiva: V237 (versão funcional aprovada).

Correção:
- Corrigido o fundo gradiente do tema noturno.
- O gradiente passa a ser desenhado por um Drawable radial próprio, garantindo que o azul mais claro fica centrado no meio do ecrã e que o gradiente aparece de forma consistente nos menus Regras, Histórico e Configurações.
- Mantida a fotografia de fundo independente do tema noturno e sem aplicação de escurecimento sobre a fotografia.
- Mantida a transparência dos menus e restantes funcionalidades da V237.
- VersionCode e VersionName alinhados em 238.
