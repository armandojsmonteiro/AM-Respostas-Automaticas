AM Respostas Automáticas — V237

Base exclusiva: V235 (a tentativa V235 é a base aprovada; esta correção não parte de V236 nem de qualquer tentativa posterior).

Correção:
- Corrigida a falha de compilação Kotlin em ThemesActivity.kt causada por uma declaração duplicada de `uri` dentro de refreshVisuals().
- Mantida integralmente a lógica funcional e visual da V235.
- Não foram alterados menus, regras, configurações, tema, fotografia ou comportamentos além da correção necessária para compilar.
- VersionCode e VersionName alinhados em 237.
