AM Respostas Automáticas — V238
Base: V235. V237 é a base aprovada para esta alteração.
