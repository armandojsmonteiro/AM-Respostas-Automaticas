package pt.am.respostasautomaticas

import android.app.Notification
import android.content.Context
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * V225: separates the human-readable History from technical Diagnostics.
 * Only direct person-to-person events are written by the notification service.
 */
object DiagnosticsStore {
    private const val PREFS = "am_diagnostics"
    private const val HISTORY_KEY = "history_v225"
    private const val TECH_KEY = "technical_v225"
    private const val MAX_HISTORY = 30000
    private const val MAX_TECH = 50000

    private fun stamp(millis: Long = System.currentTimeMillis(), withMillis: Boolean = false): String {
        val pattern = if (withMillis) "HH:mm:ss.SSS" else "HH:mm:ss"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
    }

    private fun prepend(context: Context, key: String, entry: String, max: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(key, "") ?: ""
        prefs.edit().putString(key, (entry + current).take(max)).apply()
    }

    fun appendHistory(
        context: Context, appName: String, contact: String, receivedText: String,
        outcome: String, responseText: String? = null, elapsedMs: Long? = null
    ) {
        val elapsed = elapsedMs?.let { "\nTempo de processamento: ${it} ms" } ?: ""
        val entry = buildString {
            append("[${stamp()}] $appName — ${clean(contact).ifBlank { "Contacto desconhecido" }}\n")
            append("Recebida: ${clean(receivedText).ifBlank { "(sem texto)" }}\n")
            append("Resultado: $outcome")
            responseText?.takeIf { it.isNotBlank() }?.let { append("\nEnviada: ${clean(it)}") }
            append(elapsed)
            append("\n------------------------------\n")
        }
        prepend(context, HISTORY_KEY, entry, MAX_HISTORY)
    }

    fun appendTechnical(context: Context, eventId: String, message: String) {
        val entry = "[${stamp(withMillis = true)}] [$eventId] $message\n"
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(TECH_KEY, "") ?: ""
        // Keep newest diagnostic entries.
        prefs.edit().putString(TECH_KEY, (current + entry).takeLast(MAX_TECH)).apply()
    }

    // Legacy compatibility methods are diagnostic-only and deliberately do not
    // write to the user-facing History. This prevents old callers from polluting it.
    fun append(context: Context, packageName: String, userId: String, title: String, text: String) {
        runCatching { appendTechnical(context, "LEGACY", "Notificação | pacote=$packageName | UserHandle=$userId | título=$title | texto=$text") }
    }

    fun appendNotificationDetails(context: Context, sbn: StatusBarNotification, notification: Notification) {
        runCatching {
            val extras = notification.extras
            val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()
            val actions = notification.actions.orEmpty()
            appendTechnical(context, "LEGACY", "Detalhes | key=${sbn.key} | categoria=${notification.category ?: "(sem categoria)"} | conversationTitle=${conversationTitle.ifEmpty { "(ausente)" }} | ações=${actions.size}")
        }
    }

    fun appendResult(context: Context, message: String) {
        runCatching { appendTechnical(context, "LEGACY", message) }
    }

    fun get(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(HISTORY_KEY, "Ainda não existem registos no histórico.")
        ?: "Ainda não existem registos no histórico."

    fun getTechnical(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(TECH_KEY, "Ainda não existem registos de diagnóstico.")
        ?: "Ainda não existem registos de diagnóstico."

    fun clearHistory(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(HISTORY_KEY).apply() }
    fun clearTechnical(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(TECH_KEY).apply() }

    private fun clean(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
