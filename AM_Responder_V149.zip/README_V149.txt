AM Respostas Automáticas — V149

Base: V148.

Alterações: corrigido o ícone da aplicação para usar efetivamente o PNG fornecido pelo utilizador, removendo apenas o fundo exterior preto e preservando o desenho original. Substituídos os três ícones WhatsApp Business (normal, Clonado e Trabalho) por versões derivadas diretamente do PNG fornecido, em alta resolução e com fundo exterior transparente; mantidos os distintivos 2 e Trabalho.

A instância WhatsApp Business Trabalho continua disponível na seleção de regras e mantém o mesmo tratamento de perfil Trabalho das restantes aplicações. Não foram alterados menus, regras, lógica de respostas, histórico ou configurações.

VersionCode: 143 · versionName: 149.
