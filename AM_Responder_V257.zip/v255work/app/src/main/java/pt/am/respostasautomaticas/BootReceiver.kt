package pt.am.respostasautomaticas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        DiagnosticsStore.appendTechnical(
            context.applicationContext,
            "BOOT",
            "Arranque do Android/aplicação detetado; a pedir reconexão do listener."
        )
        NotificationDiagnosticService.requestRebind(context.applicationContext)
    }
}
