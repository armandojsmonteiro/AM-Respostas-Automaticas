package pt.am.respostasautomaticas

import android.app.Notification
import android.content.Context
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DiagnosticsStore {
    private const val PREFS = "am_diagnostics"
    private const val HISTORY_KEY = "history_v226"
    private const val TECH_KEY = "technical_v226"
    private const val MAX_HISTORY = 30000
    private const val MAX_TECH = 50000
    private const val LISTENER_CONNECTED_KEY = "listener_connected"
    private const val LAST_EVENT_KEY = "last_listener_event"
    private const val LAST_NOTIFICATION_KEY = "last_notification_event"
    private const val HEARTBEAT_KEY = "listener_heartbeat"

    private fun stamp(millis: Long = System.currentTimeMillis(), withMillis: Boolean = false): String {
        // Human-facing diagnostics deliberately use date + time only. Milliseconds
        // were useful while debugging but made the log harder to read.
        val pattern = "dd/MM/yyyy HH:mm:ss"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
    }

    private fun prepend(context: Context, key: String, entry: String, max: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(key, "") ?: ""
        prefs.edit().putString(key, (entry + current).take(max)).apply()
    }

    fun appendHistory(
        context: Context, appName: String, contact: String, messageText: String,
        direction: String, outcome: String, responseText: String? = null, elapsedMs: Long? = null
    ) {
        val elapsed = elapsedMs?.let { "\nTempo de processamento: ${it} ms" } ?: ""
        val arrow = if (direction == "sent") "→" else "←"
        val label = if (direction == "sent") "Enviada" else "Recebida"
        val entry = buildString {
            append("[${stamp()}] ${clean(appName)} $arrow ${clean(contact).ifBlank { "Contacto desconhecido" }}\n")
            append("$label: ${clean(messageText).ifBlank { "(sem texto)" }}\n")
            append("Resultado: $outcome")
            responseText?.takeIf { it.isNotBlank() }?.let { append("\nResposta automática: ${clean(it)}") }
            append(elapsed)
            append("\n------------------------------\n")
        }
        prepend(context, HISTORY_KEY, entry, MAX_HISTORY)
    }

    fun appendTechnical(context: Context, eventId: String, message: String) {
        val entry = "[${stamp()}] [$eventId] $message\n"
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = prefs.getString(TECH_KEY, "") ?: ""
        prefs.edit().putString(TECH_KEY, (current + entry).takeLast(MAX_TECH)).apply()
    }

    fun append(context: Context, packageName: String, userId: String, title: String, text: String) {
        runCatching { appendTechnical(context, "LEGACY", "Notificação | pacote=$packageName | UserHandle=$userId | título=$title | texto=$text") }
    }

    fun appendNotificationDetails(context: Context, sbn: StatusBarNotification, notification: Notification) {
        runCatching {
            val extras = notification.extras
            val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()
            val actions = notification.actions.orEmpty()
            appendTechnical(context, "LEGACY", "Detalhes | key=${sbn.key} | categoria=${notification.category ?: "(sem categoria)"} | conversationTitle=${conversationTitle.ifEmpty { "(ausente)" }} | ações=${actions.size}")
        }
    }


    fun setListenerServiceState(context: Context, connected: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(LISTENER_CONNECTED_KEY, connected)
            .putString(LAST_EVENT_KEY, stamp())
            .apply()
    }

    fun heartbeatListenerService(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(HEARTBEAT_KEY, System.currentTimeMillis())
            .apply()
    }

    fun isListenerServiceConnected(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(LISTENER_CONNECTED_KEY, false)

    fun isListenerServiceHealthy(context: Context, staleAfterMs: Long = 90_000L): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val connected = prefs.getBoolean(LISTENER_CONNECTED_KEY, false)
        val heartbeat = prefs.getLong(HEARTBEAT_KEY, 0L)
        return connected && heartbeat > 0L && System.currentTimeMillis() - heartbeat <= staleAfterMs
    }

    fun recordNotificationReceived(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(LAST_NOTIFICATION_KEY, stamp())
            .apply()
    }

    fun getLastNotificationReceived(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(LAST_NOTIFICATION_KEY, "Nunca") ?: "Nunca"

    fun getLastListenerEvent(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(LAST_EVENT_KEY, "Nunca") ?: "Nunca"

    fun appendResult(context: Context, message: String) {
        runCatching { appendTechnical(context, "EVENT", message) }
    }

    fun get(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(HISTORY_KEY, "Ainda não existem registos no histórico.")
        ?: "Ainda não existem registos no histórico."

    fun getTechnical(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(TECH_KEY, "Ainda não existem registos de diagnóstico.")
        ?: "Ainda não existem registos de diagnóstico."

    fun clearHistory(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(HISTORY_KEY).apply() }
    fun clearTechnical(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(TECH_KEY).apply() }

    private fun clean(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
