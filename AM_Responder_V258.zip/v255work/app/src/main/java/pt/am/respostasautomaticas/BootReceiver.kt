package pt.am.respostasautomaticas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_USER_UNLOCKED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val appContext = context.applicationContext
        DiagnosticsStore.appendTechnical(
            appContext,
            "BOOT",
            "Arranque/desbloqueio da sessão detetado; a pedir reconexão do listener."
        )

        // The notification listener may not be rebound immediately after reboot.
        // Ask Android more than once, including after the user has unlocked the device.
        NotificationDiagnosticService.requestRebind(appContext)

        val pending = goAsync()
        Thread {
            try {
                val delays = longArrayOf(1000L, 2500L, 5000L)
                for (delay in delays) {
                    Thread.sleep(delay)
                    NotificationDiagnosticService.requestRebind(appContext)
                    DiagnosticsStore.appendTechnical(
                        appContext,
                        "BOOT",
                        "Nova tentativa de reconexão do listener (${delay} ms após o broadcast)."
                    )
                }
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            } finally {
                pending.finish()
            }
        }.start()
    }
}
