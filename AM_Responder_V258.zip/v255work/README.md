AM Respostas Automáticas — V258

Base: V255/V257 recovery line, preserving existing responder behavior.

Version Code: 258
Version Name: 258
