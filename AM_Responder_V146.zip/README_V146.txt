AM Respostas Automáticas — V146

Base: V145.

Única alteração desta versão: reduzir o tamanho dos botões azuis de confirmação dos diálogos de limpeza (Cancelar / Limpar e Cancelar / Limpar dados), mantendo-os separados e sem alterar o restante da interface ou comportamento.
