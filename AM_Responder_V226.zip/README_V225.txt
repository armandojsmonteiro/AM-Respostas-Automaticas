AM Respostas Automáticas — V225

Base funcional: V221.
V222/V223/V224 não são bases de desenvolvimento.

V225: corrige a navegação inferior Regras/Histórico/Configurações, mantendo a seleção explícita de ecrã ao voltar de Configurações. Restaura a lógica funcional de resposta da V221 e mantém o diagnóstico separado do Histórico. Grupos/canais/comunidades são descartados antes de qualquer registo. VersionCode/VersionName = 225.
