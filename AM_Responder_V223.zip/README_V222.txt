AM Respostas Automáticas — V222

Base: V221.

Alterações:
- VersionCode e VersionName internos alinhados para 222.
- Histórico separado do diagnóstico técnico.
- Histórico passa a registar apenas interações pessoa-a-pessoa.
- Grupos, canais e comunidades não entram no Histórico.
- Diagnóstico técnico separado, com timestamps ao milissegundo e etapas do processamento.
- Histórico apresenta resultado legível; Diagnóstico permite localizar atrasos e falhas.
- Mantido o motor de respostas existente sem alteração das regras de resposta a grupos.
