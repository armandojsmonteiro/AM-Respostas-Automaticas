AM Respostas Automáticas — V223

Base obrigatória: V222.

Correções desta versão:
- VersionCode e VersionName internos alinhados para 223.
- Corrigida a seleção visual dos separadores Histórico / Diagnóstico: apenas o separador ativo fica azul; o outro permanece com a cor de superfície e texto normal.
- Ao voltar ao Histórico, os conteúdos são atualizados a partir do armazenamento atual.
- Corrigida a deteção de conversas pessoa-a-pessoa: EXTRA_CONVERSATION_TITLE já não é usado isoladamente para classificar uma conversa como grupo, evitando bloquear conversas privadas do Telegram.
- Mantida a regra de não responder nem registar no Histórico grupos, canais e comunidades.
- Mantida a separação entre Histórico legível e Diagnóstico técnico.
